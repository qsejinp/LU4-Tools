﻿# 바탕화면에 "LU4 사용자 현황" 아이콘 만들기
$d = $PSScriptRoot
$ws = New-Object -ComObject WScript.Shell
$desks = @([Environment]::GetFolderPath('Desktop'))
try { $desks += @(Get-ChildItem $env:USERPROFILE -Directory -Recurse -Depth 2 -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'Desktop' -or $_.Name -eq ([string]([char]0xBC14) + [char]0xD0D5 + ' ' + [char]0xD654 + [char]0xBA74) } | Select-Object -Expand FullName) } catch {}
$n = 0
foreach ($dk in ($desks | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique)) {
  try {
    $l = $ws.CreateShortcut((Join-Path $dk 'LU4 사용자 현황.lnk'))
    $l.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
    $l.Arguments = '"' + (Join-Path $d 'LU4_Live_run.vbs') + '"'
    $l.WorkingDirectory = $d
    $l.IconLocation = (Join-Path $d 'LU4_Live_icon.ico') + ',0'
    $l.Save(); $n++
  } catch {}
}
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show($(if ($n) { '바탕화면에 "LU4 사용자 현황" 아이콘을 만들었어요.' } else { '아이콘을 만들지 못했어요. LU4_Live_run.vbs 를 직접 더블클릭해서 켜세요.' }), 'LU4 사용자 현황') | Out-Null
Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $d 'LU4_Live_run.vbs') + '"')
