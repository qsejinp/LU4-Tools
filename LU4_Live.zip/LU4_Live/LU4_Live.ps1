﻿# LU4 사용자 현황 (지금 실행 중인 사람 수) - made by DoZ
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
# 오류가 나면 조용히 꺼지지 않고 알려 줌 (기록: %LOCALAPPDATA%\LU4_Tools\live_viewer_error.log)
trap {
  try { Add-Content -Path (Join-Path $env:LOCALAPPDATA 'LU4_Tools\live_viewer_error.log') -Encoding UTF8 -Value ('[' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '] ' + $_.Exception.Message + ' @ ' + $_.InvocationInfo.PositionMessage) } catch {}
  [System.Windows.Forms.MessageBox]::Show(('사용자 현황 창에 오류가 났어요.`n`n' + $_.Exception.Message), 'LU4 사용자 현황') | Out-Null
  exit
}
$Url = 'https://lu4-live.lsj9351.workers.dev'
$CfgDir = Join-Path $env:LOCALAPPDATA 'LU4_Tools'; if (-not (Test-Path $CfgDir)) { New-Item -ItemType Directory -Path $CfgDir -Force | Out-Null }
$CfgPath = Join-Path $CfgDir 'live_viewer.json'
$cfg = @{ x = 60; y = 60 }
# 캐릭터 이름 목록을 볼 비밀키(이 PC에만 있음: %LOCALAPPDATA%\LU4_Tools\live_key.txt)
$Key = ''; try { foreach ($kf in @((Join-Path $CfgDir 'live_key.txt'), (Join-Path $PSScriptRoot 'live_key.txt'))) { if (Test-Path $kf) { $Key = ([string](Get-Content $kf -TotalCount 1)).Trim(); if ($Key) { break } } } } catch {}   # 비밀키: 내 PC 설정 폴더 또는 이 프로그램 폴더
try { if (Test-Path $CfgPath) { $j = Get-Content $CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json; $cfg.x = [int]$j.x; $cfg.y = [int]$j.y } } catch {}
function F($sz, [switch]$b) { New-Object System.Drawing.Font('Malgun Gothic', $sz, $(if ($b) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular })) }
$cBg = [System.Drawing.Color]::FromArgb(22, 24, 29); $cTx = [System.Drawing.Color]::FromArgb(230, 230, 230)
$cDim = [System.Drawing.Color]::FromArgb(140, 140, 140); $cGreen = [System.Drawing.Color]::FromArgb(111, 211, 111); $cLine = [System.Drawing.Color]::FromArgb(60, 60, 60)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'LU4 사용자 현황 - made by DoZ'; $form.FormBorderStyle = 'None'; $form.TopMost = $true; $form.ShowInTaskbar = $true
$form.BackColor = $cBg; $form.Size = '420,244'; $form.StartPosition = 'Manual'; $form.Opacity = 0.94
$form.Location = New-Object System.Drawing.Point $cfg.x, $cfg.y
# 화면 밖이면 기본 위치로
$on = $false; foreach ($sc in [System.Windows.Forms.Screen]::AllScreens) { if ($sc.WorkingArea.Contains($form.Location)) { $on = $true } }; if (-not $on) { $form.Location = New-Object System.Drawing.Point 60, 60 }
try { $ico = Join-Path $PSScriptRoot 'LU4_Live_icon.ico'; if (Test-Path $ico) { $form.Icon = New-Object System.Drawing.Icon $ico } } catch {}

function L($text, $x, $y, $w, $h, $font, $color, $align = 'MiddleLeft') {
  $l = New-Object System.Windows.Forms.Label; $l.Text = $text; $l.Location = New-Object System.Drawing.Point $x, $y; $l.Size = New-Object System.Drawing.Size $w, $h
  $l.Font = $font; $l.ForeColor = $color; $l.BackColor = [System.Drawing.Color]::Transparent; $l.TextAlign = $align; $form.Controls.Add($l); return $l
}
$lTitle = L '사용자 현황' 10 6 150 22 (F 10 -b) ([System.Drawing.Color]::FromArgb(240, 200, 90))
$lRef = L '새로고침' 292 6 64 22 (F 9) $cDim 'MiddleCenter'; $lRef.Cursor = 'Hand'
$lX = L '✕' 388 4 26 24 (F 11) $cDim 'MiddleCenter'; $lX.Cursor = 'Hand'
$lNowT = L '지금 실행 중' 10 34 120 34 (F 10) $cTx
$lNow = L '-' 130 30 280 40 (F 22 -b) $cGreen 'MiddleRight'
# 열: 지금 / 오늘 / 어제 / 이번 주 / 전체
$ColX = @(118, 176, 234, 292, 350); $ColN = @('지금', '오늘', '어제', '이번 주', '전체')
for ($ci = 0; $ci -lt 5; $ci++) { [void](L $ColN[$ci] $ColX[$ci] 76 50 18 (F 8.5) $cDim 'MiddleCenter') }
$rows = @{}
$yy = 96
foreach ($a in @(@('chat', '채팅번역'), @('meter', '사냥지표'), @('patch', '한글패치'))) {
  $n = L $a[1] 10 $yy 96 26 (F 10) $cTx
  $vs = @(); for ($ci = 0; $ci -lt 5; $ci++) { $vs += (L '-' $ColX[$ci] $yy 50 26 $(if ($ci -eq 0) { F 11 -b } else { F 10 }) $(if ($ci -eq 0) { $cGreen } else { $cTx }) 'MiddleCenter') }
  $rows[$a[0]] = $vs; $yy += 28
}
# 지금 쓰는 사람(캐릭터 이름) 목록
# 게임 버전 / 한글패치가 맞는 버전 (게임이 업데이트되면 빨갛게)
$lGame = L '게임 버전: 확인 전' 10 184 400 20 (F 9) $cDim
# 이름 목록: 왼쪽·오른쪽 두 칸, 10줄까지 보이고 더 있으면 마우스 휠로 내려 봄
$lNames = L '' 10 206 198 20 (F 9.5) $cTx 'TopLeft'
$lNames2 = L '' 212 206 198 20 (F 9.5) $cTx 'TopLeft'
$lNames.Visible = [bool]$Key; $lNames2.Visible = [bool]$Key
$script:NameList = @(); $script:NameOff = 0; $NameRows = 10
$lUpd = L '불러오는 중...' 10 206 200 22 (F 8.5) $cDim
$lWeb = L '웹에서 보기' 330 206 80 22 (F 8.5 ) ([System.Drawing.Color]::FromArgb(110, 170, 240)) 'MiddleRight'; $lWeb.Cursor = 'Hand'
$script:footY = 204
function Show-Names {
  $n = $script:NameList.Count; $R = [int][Math]::Ceiling($n / 2.0); $V = [Math]::Min($NameRows, [Math]::Max(1, $R))
  $mx = [Math]::Max(0, $R - $V); if ($script:NameOff -gt $mx) { $script:NameOff = $mx }; if ($script:NameOff -lt 0) { $script:NameOff = 0 }
  $a = @(); $b = @()
  for ($r = 0; $r -lt $V; $r++) { $ix = ($script:NameOff + $r) * 2; if ($ix -lt $n) { $a += $script:NameList[$ix].t }; if ($ix + 1 -lt $n) { $b += $script:NameList[$ix + 1].t } }
  $h = 19 * $V + 2
  $lNames.Text = ($a -join "`n"); $lNames2.Text = ($b -join "`n"); $lNames.Height = $h; $lNames2.Height = $h
  $script:footY = 206 + $h + 2
  $lUpd.Top = $script:footY + 4; $lWeb.Top = $script:footY + 4
  $script:More = $(if ($mx -gt 0) { ' · 휠로 더 보기 (' + $n + '명)' } else { '' })
  $form.Height = $script:footY + 30; $form.Invalidate()
}
function Set-Names($users, $blocked) {
  if (-not $Key) { return }
  $ls = @(); $seen = @{}
  foreach ($u in @($users)) { if ($u) {
    $ap = @(foreach ($a in @($u.apps)) { if ($a -eq 'chat') { '번역' } elseif ($a -eq 'meter') { '사냥' } elseif ($a -eq 'patch') { '패치' } }) -join '·'
    $ls += @{ t = ($(if ($u.blocked) { '✕ ' } else { '● ' }) + $u.name + $(if ($ap) { ' (' + $ap + ')' } else { '' }) + $(if ($u.blocked) { ' 차단' } else { '' })); id = [string]$u.id; n = [string]$u.name; b = [bool]$u.blocked }
    if ($u.id) { $seen[[string]$u.id] = 1 }
  } }
  # 지금은 안 켜져 있지만 차단해 둔 PC도 목록 끝에 보여 줌(차단 해제할 수 있게)
  foreach ($x in @($blocked)) { if ($x -and -not $seen.ContainsKey([string]$x.id)) { $ls += @{ t = ('✕ ' + $x.name + ' (차단됨)'); id = [string]$x.id; n = [string]$x.name; b = $true } } }
  if (-not $ls.Count) { $ls = @(@{ t = '(지금 쓰는 사람 없음)'; id = ''; n = ''; b = $false }) }
  $script:NameList = $ls; Show-Names
}
# 이름을 오른쪽 클릭 -> 차단 / 차단 해제 (차단된 PC는 한글패치를 새로 받거나 다시 넣지 못함)
$mBlock = New-Object System.Windows.Forms.ContextMenuStrip
$miBlock = $mBlock.Items.Add('차단')
$script:Pick = $null
$miBlock.Add_Click({
  $it = $script:Pick; if (-not $it -or -not $it.id) { return }
  $on = $(if ($it.b) { '0' } else { '1' })
  if (-not $it.b) { if ([System.Windows.Forms.MessageBox]::Show(("'" + $it.n + "' 을(를) 차단할까요?`n`n차단하면 이 PC는 한글패치를 새로 받거나 다시 넣을 수 없어요.`n(이미 받아 간 파일은 그대로 남아요)"), '사용자 현황', 'YesNo', 'Warning') -ne 'Yes') { return } }
  try { $w2 = New-Object System.Net.WebClient; [void]$w2.DownloadString(($Url + '/block?key=' + [Uri]::EscapeDataString($Key) + '&id=' + $it.id + '&on=' + $on + '&t=' + [DateTime]::UtcNow.Ticks)); $w2.Dispose(); Load-Data }
  catch { [System.Windows.Forms.MessageBox]::Show(('실패: ' + $_.Exception.Message), '사용자 현황') | Out-Null }
})
$nameClick = {
  param($sender, $e)
  if ($e.Button -ne 'Right') { return }
  $col = $(if ($sender -eq $lNames2) { 1 } else { 0 })
  $ix = ($script:NameOff + [int][Math]::Floor($e.Y / 19.0)) * 2 + $col
  if ($ix -lt 0 -or $ix -ge $script:NameList.Count) { return }
  $it = $script:NameList[$ix]; if (-not $it.id) { return }
  $script:Pick = $it; $miBlock.Text = $(if ($it.b) { "'" + $it.n + "' 차단 해제" } else { "'" + $it.n + "' 차단" })
  $mBlock.Show($sender, $e.Location)
}
$lNames.Add_MouseUp($nameClick); $lNames2.Add_MouseUp($nameClick)
$script:More = ''
$form.Add_MouseWheel({ $script:NameOff += $(if ($_.Delta -gt 0) { -1 } else { 1 }); Show-Names })
$form.Add_Paint({ $p = New-Object System.Drawing.Pen $cLine; $_.Graphics.DrawLine($p, 10, 30, 410, 30); $_.Graphics.DrawLine($p, 10, 182, 410, 182); if ($Key) { $_.Graphics.DrawLine($p, 10, $script:footY, 410, $script:footY) }; $_.Graphics.DrawRectangle($p, 0, 0, $form.Width - 1, $form.Height - 1); $p.Dispose() })

# 끌어서 옮기기 (창 아무 곳이나)
$script:drag = $null
$down = { if ($_.Button -eq 'Left') { $script:drag = [System.Windows.Forms.Cursor]::Position; $script:orig = $form.Location } }
$move = { if ($script:drag) { $c = [System.Windows.Forms.Cursor]::Position; $form.Location = New-Object System.Drawing.Point ($script:orig.X + $c.X - $script:drag.X), ($script:orig.Y + $c.Y - $script:drag.Y) } }
$up = { if ($script:drag) { $script:drag = $null; try { @{ x = $form.Left; y = $form.Top } | ConvertTo-Json | Set-Content $CfgPath -Encoding UTF8 } catch {} } }
foreach ($c in @($form) + @($form.Controls | Where-Object { $_ -ne $lX -and $_ -ne $lRef -and $_ -ne $lWeb })) { $c.Add_MouseDown($down); $c.Add_MouseMove($move); $c.Add_MouseUp($up) }

# 불러오기 (백그라운드, 창이 멈추지 않게)
$script:busy = $false
function Load-Data {
  if ($script:busy) { return }
  $script:busy = $true; $lRef.ForeColor = [System.Drawing.Color]::FromArgb(90, 90, 90)
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $wc = New-Object System.Net.WebClient; $wc.Encoding = [System.Text.Encoding]::UTF8; $wc.Headers.Add('User-Agent', 'LU4-LiveViewer')
    $wc.Add_DownloadStringCompleted({
      param($s, $e)
      $script:busy = $false; $lRef.ForeColor = $cDim
      try {
        if ($e.Error) { throw $e.Error }
        $d = $e.Result | ConvertFrom-Json
        $lNow.Text = ([string]$d.livePeople + '명')
        foreach ($k in @('chat', 'meter', 'patch')) { $r = $rows[$k]; $o = $d.$k; if ($o -eq $null) { continue }; $vals = @($o.live, $o.today, $o.yday, $o.week, $o.total); for ($ci = 0; $ci -lt 5; $ci++) { $r[$ci].Text = $(if ($vals[$ci] -ne $null) { [string]$vals[$ci] } else { '-' }) } }
        if ($d.game -and $d.game.ver) {
          if ($d.game.updated) { $lGame.Text = ('게임이 업데이트됨!  게임 ' + $d.game.ver + ' / 한글패치는 ' + $d.game.patchFor + '용'); $lGame.ForeColor = [System.Drawing.Color]::FromArgb(255, 110, 95) }
          else { $lGame.Text = ('게임 버전 ' + $d.game.ver + ' · 한글패치 맞음'); $lGame.ForeColor = $cDim }
        }
        Set-Names $d.users $d.blocked
        $lUpd.Text = ((Get-Date).ToString('HH:mm:ss') + ' 기준' + $script:More)
      } catch { $lUpd.Text = '연결 실패 - 잠시 뒤 다시 시도' }
    })
    $script:wc = $wc
    $wc.DownloadStringAsync([Uri]($Url + '/json?t=' + [DateTime]::UtcNow.Ticks + $(if ($Key) { '&key=' + [Uri]::EscapeDataString($Key) } else { '' })))
  } catch { $script:busy = $false; $lUpd.Text = '연결 실패' }
}
$lRef.Add_Click({ Load-Data })
$lX.Add_Click({ $form.Close() })
$lX.Add_MouseEnter({ $lX.ForeColor = [System.Drawing.Color]::IndianRed }); $lX.Add_MouseLeave({ $lX.ForeColor = $cDim })
$lWeb.Add_Click({ try { Start-Process $Url } catch {} })
$tm = New-Object System.Windows.Forms.Timer; $tm.Interval = 30000; $tm.Add_Tick({ Load-Data }); $tm.Start()
$form.Add_Shown({ Load-Data })
[System.Windows.Forms.Application]::Run($form)
