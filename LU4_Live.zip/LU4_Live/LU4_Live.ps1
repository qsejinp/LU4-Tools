﻿# LU4 사용자 현황 (지금 실행 중인 사람 수) - made by DoZ
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
# 오류가 나면 조용히 꺼지지 않고 알려 줌 (기록: %LOCALAPPDATA%\LU4_Tools\live_viewer_error.log)
trap {
  try { Add-Content -Path (Join-Path $env:LOCALAPPDATA 'LU4_Tools\live_viewer_error.log') -Encoding UTF8 -Value ('[' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '] ' + $_.Exception.Message + ' @ ' + $_.InvocationInfo.PositionMessage) } catch {}
  [System.Windows.Forms.MessageBox]::Show(('사용자 현황 창에 오류가 났어요.`n`n' + $_.Exception.Message), 'LU4 사용자 현황') | Out-Null
  exit
}
$Url = 'https://lu4-live.lsj9351.workers.dev'
$CfgDir = Join-Path $env:LOCALAPPDATA 'LU4_Tools'; if (-not (Test-Path $CfgDir)) { New-Item -ItemType Directory -Path $CfgDir -Force | Out-Null }
$CfgPath = Join-Path $CfgDir 'live_viewer.json'
$cfg = @{ x = 60; y = 60 }
# 캐릭터 이름 목록을 볼 비밀키(이 PC에만 있음: %LOCALAPPDATA%\LU4_Tools\live_key.txt)
$Key = ''; try { $kf = Join-Path $CfgDir 'live_key.txt'; if (Test-Path $kf) { $Key = ([string](Get-Content $kf -TotalCount 1)).Trim() } } catch {}
try { if (Test-Path $CfgPath) { $j = Get-Content $CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json; $cfg.x = [int]$j.x; $cfg.y = [int]$j.y } } catch {}
function F($sz, [switch]$b) { New-Object System.Drawing.Font('Malgun Gothic', $sz, $(if ($b) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular })) }
$cBg = [System.Drawing.Color]::FromArgb(22, 24, 29); $cTx = [System.Drawing.Color]::FromArgb(230, 230, 230)
$cDim = [System.Drawing.Color]::FromArgb(140, 140, 140); $cGreen = [System.Drawing.Color]::FromArgb(111, 211, 111); $cLine = [System.Drawing.Color]::FromArgb(60, 60, 60)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'LU4 사용자 현황 - made by DoZ'; $form.FormBorderStyle = 'None'; $form.TopMost = $true; $form.ShowInTaskbar = $true
$form.BackColor = $cBg; $form.Size = '360,244'; $form.StartPosition = 'Manual'; $form.Opacity = 0.94
$form.Location = New-Object System.Drawing.Point $cfg.x, $cfg.y
# 화면 밖이면 기본 위치로
$on = $false; foreach ($sc in [System.Windows.Forms.Screen]::AllScreens) { if ($sc.WorkingArea.Contains($form.Location)) { $on = $true } }; if (-not $on) { $form.Location = New-Object System.Drawing.Point 60, 60 }
try { $ico = Join-Path $PSScriptRoot 'LU4_Live_icon.ico'; if (Test-Path $ico) { $form.Icon = New-Object System.Drawing.Icon $ico } } catch {}

function L($text, $x, $y, $w, $h, $font, $color, $align = 'MiddleLeft') {
  $l = New-Object System.Windows.Forms.Label; $l.Text = $text; $l.Location = New-Object System.Drawing.Point $x, $y; $l.Size = New-Object System.Drawing.Size $w, $h
  $l.Font = $font; $l.ForeColor = $color; $l.BackColor = [System.Drawing.Color]::Transparent; $l.TextAlign = $align; $form.Controls.Add($l); return $l
}
$lTitle = L '사용자 현황' 10 6 150 22 (F 10 -b) ([System.Drawing.Color]::FromArgb(240, 200, 90))
$lRef = L '새로고침' 232 6 64 22 (F 9) $cDim 'MiddleCenter'; $lRef.Cursor = 'Hand'
$lX = L '✕' 328 4 26 24 (F 11) $cDim 'MiddleCenter'; $lX.Cursor = 'Hand'
$lNowT = L '지금 실행 중' 10 34 120 34 (F 10) $cTx
$lNow = L '-' 130 30 220 40 (F 22 -b) $cGreen 'MiddleRight'
# 열: 지금 / 오늘 / 어제 / 이번 주 / 전체
$ColX = @(100, 150, 200, 250, 300); $ColN = @('지금', '오늘', '어제', '이번 주', '전체')
for ($ci = 0; $ci -lt 5; $ci++) { [void](L $ColN[$ci] $ColX[$ci] 76 50 18 (F 8.5) $cDim 'MiddleCenter') }
$rows = @{}
$yy = 96
foreach ($a in @(@('chat', '채팅번역'), @('meter', '사냥지표'), @('patch', '한글패치'))) {
  $n = L $a[1] 10 $yy 96 26 (F 10) $cTx
  $vs = @(); for ($ci = 0; $ci -lt 5; $ci++) { $vs += (L '-' $ColX[$ci] $yy 50 26 $(if ($ci -eq 0) { F 11 -b } else { F 10 }) $(if ($ci -eq 0) { $cGreen } else { $cTx }) 'MiddleCenter') }
  $rows[$a[0]] = $vs; $yy += 28
}
# 지금 쓰는 사람(캐릭터 이름) 목록
# 게임 버전 / 한글패치가 맞는 버전 (게임이 업데이트되면 빨갛게)
$lGame = L '게임 버전: 확인 전' 10 184 340 20 (F 9) $cDim
$lNames = L '' 10 206 340 20 (F 9.5) $cTx 'TopLeft'
$lNames.Visible = [bool]$Key
$lUpd = L '불러오는 중...' 10 206 200 22 (F 8.5) $cDim
$lWeb = L '웹에서 보기' 270 206 80 22 (F 8.5 ) ([System.Drawing.Color]::FromArgb(110, 170, 240)) 'MiddleRight'; $lWeb.Cursor = 'Hand'
$script:footY = 204
function Set-Names($users) {
  if (-not $Key) { return }
  $ls = @(foreach ($u in @($users)) { if ($u) { $ap = @(foreach ($a in @($u.apps)) { if ($a -eq 'chat') { '번역' } elseif ($a -eq 'meter') { '사냥' } elseif ($a -eq 'patch') { '패치' } }) -join '·'; ('● ' + $u.name + $(if ($ap) { '   (' + $ap + ')' } else { '' })) } })
  if (-not $ls.Count) { $ls = @('(지금 쓰는 사람 없음)') }
  $h = 19 * $ls.Count + 2
  $lNames.Text = ($ls -join "`n"); $lNames.Height = $h
  $script:footY = 206 + $h + 2
  $lUpd.Top = $script:footY + 4; $lWeb.Top = $script:footY + 4
  $form.Height = $script:footY + 30; $form.Invalidate()
}
$form.Add_Paint({ $p = New-Object System.Drawing.Pen $cLine; $_.Graphics.DrawLine($p, 10, 30, 350, 30); $_.Graphics.DrawLine($p, 10, 182, 350, 182); if ($Key) { $_.Graphics.DrawLine($p, 10, $script:footY, 350, $script:footY) }; $_.Graphics.DrawRectangle($p, 0, 0, $form.Width - 1, $form.Height - 1); $p.Dispose() })

# 끌어서 옮기기 (창 아무 곳이나)
$script:drag = $null
$down = { if ($_.Button -eq 'Left') { $script:drag = [System.Windows.Forms.Cursor]::Position; $script:orig = $form.Location } }
$move = { if ($script:drag) { $c = [System.Windows.Forms.Cursor]::Position; $form.Location = New-Object System.Drawing.Point ($script:orig.X + $c.X - $script:drag.X), ($script:orig.Y + $c.Y - $script:drag.Y) } }
$up = { if ($script:drag) { $script:drag = $null; try { @{ x = $form.Left; y = $form.Top } | ConvertTo-Json | Set-Content $CfgPath -Encoding UTF8 } catch {} } }
foreach ($c in @($form) + @($form.Controls | Where-Object { $_ -ne $lX -and $_ -ne $lRef -and $_ -ne $lWeb })) { $c.Add_MouseDown($down); $c.Add_MouseMove($move); $c.Add_MouseUp($up) }

# 불러오기 (백그라운드, 창이 멈추지 않게)
$script:busy = $false
function Load-Data {
  if ($script:busy) { return }
  $script:busy = $true; $lRef.ForeColor = [System.Drawing.Color]::FromArgb(90, 90, 90)
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $wc = New-Object System.Net.WebClient; $wc.Encoding = [System.Text.Encoding]::UTF8; $wc.Headers.Add('User-Agent', 'LU4-LiveViewer')
    $wc.Add_DownloadStringCompleted({
      param($s, $e)
      $script:busy = $false; $lRef.ForeColor = $cDim
      try {
        if ($e.Error) { throw $e.Error }
        $d = $e.Result | ConvertFrom-Json
        $lNow.Text = ([string]$d.livePeople + '명')
        foreach ($k in @('chat', 'meter', 'patch')) { $r = $rows[$k]; $o = $d.$k; if ($o -eq $null) { continue }; $vals = @($o.live, $o.today, $o.yday, $o.week, $o.total); for ($ci = 0; $ci -lt 5; $ci++) { $r[$ci].Text = $(if ($vals[$ci] -ne $null) { [string]$vals[$ci] } else { '-' }) } }
        if ($d.game -and $d.game.ver) {
          if ($d.game.updated) { $lGame.Text = ('게임이 업데이트됨!  게임 ' + $d.game.ver + ' / 한글패치는 ' + $d.game.patchFor + '용'); $lGame.ForeColor = [System.Drawing.Color]::FromArgb(255, 110, 95) }
          else { $lGame.Text = ('게임 버전 ' + $d.game.ver + ' · 한글패치 맞음'); $lGame.ForeColor = $cDim }
        }
        Set-Names $d.users
        $lUpd.Text = ((Get-Date).ToString('HH:mm:ss') + ' 기준 · 30초마다')
      } catch { $lUpd.Text = '연결 실패 - 잠시 뒤 다시 시도' }
    })
    $script:wc = $wc
    $wc.DownloadStringAsync([Uri]($Url + '/json?t=' + [DateTime]::UtcNow.Ticks + $(if ($Key) { '&key=' + [Uri]::EscapeDataString($Key) } else { '' })))
  } catch { $script:busy = $false; $lUpd.Text = '연결 실패' }
}
$lRef.Add_Click({ Load-Data })
$lX.Add_Click({ $form.Close() })
$lX.Add_MouseEnter({ $lX.ForeColor = [System.Drawing.Color]::IndianRed }); $lX.Add_MouseLeave({ $lX.ForeColor = $cDim })
$lWeb.Add_Click({ try { Start-Process $Url } catch {} })
$tm = New-Object System.Windows.Forms.Timer; $tm.Interval = 30000; $tm.Add_Tick({ Load-Data }); $tm.Start()
$form.Add_Shown({ Load-Data })
[System.Windows.Forms.Application]::Run($form)
