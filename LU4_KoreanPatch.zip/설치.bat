@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0프로그램파일\install.ps1"
