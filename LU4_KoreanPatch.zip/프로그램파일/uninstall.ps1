﻿# made by DoZ
# LU4 한글패치 제거: 바로가기, 자동 실행, 설치 폴더를 지움 (게임 폴더에 넣은 한글패치 파일은 그대로 둠)
Add-Type -AssemblyName System.Windows.Forms
$here = $PSScriptRoot; $prog = 'LU4_KoreanPatch'; $title = 'LU4 한글패치'
if (-not (Test-Path (Join-Path $here ($prog + '.ps1')))) { exit }
if ([System.Windows.Forms.MessageBox]::Show("$title 프로그램을 지울까요?`n바탕화면 아이콘, 자동 실행, 이 폴더가 지워져요.`n(게임에 넣어 둔 한글패치 자체는 그대로 남아요)`n`n$here", 'LU4 제거', 'YesNo', 'Warning') -ne 'Yes') { exit }
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like ('*' + $prog + '.ps1*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'LU4 Tools'
$ps = @((Join-Path $menu ($title + '.lnk')), (Join-Path $menu ($title + ' 제거.lnk')), (Join-Path ([Environment]::GetFolderPath('Startup')) ($title + ' (자동 실행).lnk')), (Join-Path ([Environment]::GetFolderPath('Desktop')) ($title + '.lnk')))
try { Get-ChildItem $env:USERPROFILE -Directory -Recurse -Depth 2 -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'Desktop' -or $_.Name -eq '바탕 화면' } | ForEach-Object { $ps += (Join-Path $_.FullName ($title + '.lnk')) } } catch {}
foreach ($p in $ps) { Remove-Item $p -Force -ErrorAction SilentlyContinue }
if ((Test-Path $menu) -and -not (Get-ChildItem $menu -ErrorAction SilentlyContinue)) { Remove-Item $menu -Force -ErrorAction SilentlyContinue }
Remove-Item (Join-Path $env:LOCALAPPDATA 'LU4_Tools\patch_cache') -Recurse -Force -ErrorAction SilentlyContinue
[System.Windows.Forms.MessageBox]::Show("$title 을(를) 지웠어요.", 'LU4 제거') | Out-Null
Start-Process cmd -WindowStyle Hidden -WorkingDirectory $env:TEMP -ArgumentList ('/c timeout /t 2 /nobreak >nul & rmdir /s /q "' + $here + '"')
