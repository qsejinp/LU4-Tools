﻿# made by DoZ
# LU4 설치: 프로그램을 C:\LU4_Tools\프로그램이름 폴더에 복사하고 바탕화면/시작 메뉴에 바로가기를 만듦
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$src = $PSScriptRoot
$prog = $(if (Test-Path (Join-Path $src 'LU4_ChatTranslate.ps1')) { 'LU4_ChatTranslate' } elseif (Test-Path (Join-Path $src 'LU4_GrindMeter.ps1')) { 'LU4_GrindMeter' } else { '' })
function Msg($t, $b = 'OK', $i = 'Information') { return [System.Windows.Forms.MessageBox]::Show($t, 'LU4 설치 (made by DoZ)', $b, $i) }
if (-not $prog) { Msg '이 폴더에서 프로그램을 찾지 못했어요. 압축을 푼 폴더 안의 설치.bat 을 실행해 주세요.' 'OK' 'Warning' | Out-Null; exit }
$title = @{ LU4_ChatTranslate = 'LU4 채팅 번역'; LU4_GrindMeter = 'LU4 사냥지표' }[$prog]
# 압축을 풀지 않고 압축 파일 안에서 바로 실행한 경우
if ($src -like '*\AppData\Local\Temp\*' -and -not (Test-Path (Join-Path $src 'install_update.ps1'))) { Msg '압축 파일 안에서 바로 실행했어요. 먼저 [압축 풀기]를 한 다음, 풀린 폴더의 설치.bat 을 실행해 주세요.' 'OK' 'Warning' | Out-Null; exit }
$dst = Join-Path 'C:\LU4_Tools' $prog
if ((Msg ("$title 을(를) 설치할까요?`n`n설치 위치: $dst`n바탕화면에 '$title' 아이콘이 만들어져요.`n(이미 설치돼 있으면 내 설정은 그대로 두고 프로그램만 바꿔요)") 'YesNo' 'Question') -ne 'Yes') { exit }
# 켜져 있으면 끄라고 안내
while (@(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like ('*' + $prog + '.ps1*') }).Count) {
  if ((Msg "$title 이(가) 켜져 있어요. 프로그램을 닫은 뒤 [확인]을 눌러 주세요." 'OKCancel' 'Warning') -ne 'OK') { exit }
}
$keep = @('deepl_key.txt', 'clan_members.txt', 'chat_glossary.txt', 'loot_alert.wav', 'chat_alert.wav')
$keepPat = '(_cfg\.json|_error\.log|_debug\.log)$'
try {
  New-Item -ItemType Directory -Path $dst -Force | Out-Null
  if ((Resolve-Path $src).Path.TrimEnd('\') -ne (Resolve-Path $dst).Path.TrimEnd('\')) {
    foreach ($f in Get-ChildItem -Path $src -File) {
      $to = Join-Path $dst $f.Name
      # 내 설정 파일: 설치 폴더에 이미 있으면 그대로 둠 (처음 설치면 지금 폴더의 것을 가져감)
      if (($keep -contains $f.Name -or $f.Name -match $keepPat) -and (Test-Path $to)) { continue }
      Copy-Item $f.FullName $to -Force
    }
  }
  # 바로가기: 검은 창 없이 켜지도록 wscript 로 .vbs 실행 (vbs 를 쓸 수 없는 PC는 PowerShell 숨김 실행)
  $sh = New-Object -ComObject WScript.Shell
  $vbs = Join-Path $dst ($prog + '_run.vbs'); $ps1 = Join-Path $dst ($prog + '.ps1'); $ico = Join-Path $dst ($prog + '.ico')
  $ws = Join-Path $env:WINDIR 'System32\wscript.exe'
  $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'LU4 Tools'
  New-Item -ItemType Directory -Path $menu -Force | Out-Null
  $desks = New-Object System.Collections.ArrayList
  foreach ($cand in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:USERPROFILE 'Desktop'), (Join-Path $env:USERPROFILE 'OneDrive\Desktop'), (Join-Path $env:USERPROFILE 'OneDrive\바탕 화면'))) { if ($cand -and (Test-Path $cand) -and (-not $desks.Contains($cand))) { [void]$desks.Add($cand) } }
  if ($env:OneDrive) { foreach ($c in @((Join-Path $env:OneDrive 'Desktop'), (Join-Path $env:OneDrive '바탕 화면'))) { if ((Test-Path $c) -and (-not $desks.Contains($c))) { [void]$desks.Add($c) } } }
  $targets = @(); foreach ($dk in $desks) { $targets += (Join-Path $dk ($title + '.lnk')) }
  $targets += (Join-Path $menu ($title + '.lnk'))
  foreach ($lnkPath in $targets) {
    $l = $sh.CreateShortcut($lnkPath)
    if ((Test-Path $ws) -and (Test-Path $vbs)) { $l.TargetPath = $ws; $l.Arguments = '"' + $vbs + '"' }
    else { $l.TargetPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'; $l.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $ps1 + '"'; $l.WindowStyle = 7 }
    $l.WorkingDirectory = $dst
    if (Test-Path $ico) { $l.IconLocation = $ico + ',0' }
    $l.Description = $title + ' (made by DoZ)'
    $l.Save()
  }
  $u = $sh.CreateShortcut((Join-Path $menu ($title + ' 제거.lnk'))); $u.TargetPath = Join-Path $dst '제거.bat'; $u.WorkingDirectory = $dst; $u.Save()
  $f = $sh.CreateShortcut((Join-Path $menu ($title + ' 폴더 열기.lnk'))); $f.TargetPath = $dst; $f.Save()
} catch { Msg ('설치 중 문제가 생겼어요: ' + $_.Exception.Message) 'OK' 'Error' | Out-Null; exit }
if ((Msg ("설치 완료!`n`n바탕화면의 '$title' 아이콘으로 실행하세요.`n(시작 메뉴 > LU4 Tools 에도 있어요)`n`n지금 실행할까요?") 'YesNo' 'Information') -eq 'Yes') {
  if ((Test-Path $ws) -and (Test-Path $vbs)) { Start-Process -FilePath $ws -ArgumentList ('"' + $vbs + '"') -WorkingDirectory $dst }
  else { Start-Process powershell -WindowStyle Hidden -WorkingDirectory $dst -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-WindowStyle', 'Hidden', '-File', ('"' + $ps1 + '"')) }
}
