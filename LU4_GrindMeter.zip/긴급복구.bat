@echo off
chcp 65001 >nul
echo ============================================
echo  LU4 긴급 복구 (업데이트가 멈출 때만 사용)
echo  - 실행 중인 LU4 를 닫고 최신으로 고칩니다.
echo  - 내 설정(키/명단/용어/위치)은 그대로 유지돼요.
echo ============================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; iex ((New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/qsejinp/LU4-Tools/main/fix.ps1?t='+[DateTime]::UtcNow.Ticks))"
echo.
echo 끝났습니다. 바탕화면 아이콘으로 프로그램을 다시 켜세요.
pause
