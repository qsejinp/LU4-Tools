﻿# made by DoZ
# LU4 사냥 지표 (외부 프로그램) - 게임 파일/메모리는 건드리지 않고 화면 글자만 읽습니다.
# 실행: LU4_GrindMeter_run.bat
$ErrorActionPreference = 'Stop'
# exe(ps2exe)로 묶여 실행될 때는 $PSScriptRoot 가 비어 있어서 폴더(글꼴/설정/명단)를 못 찾음 -> 직접 채움
if (-not $PSScriptRoot) {
  try { $exe = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName } catch { $exe = $null }
  if ($exe -and ($exe -notmatch '(?i)\\(powershell|pwsh)\.exe$')) { $script:PSScriptRoot = Split-Path $exe -Parent }
  elseif ($PSCommandPath) { $script:PSScriptRoot = Split-Path $PSCommandPath -Parent }
  else { $script:PSScriptRoot = (Get-Location).Path }
}
# 중복 실행 방지: 같은 프로그램이 이미 켜져 있으면 조용히 종료 (업데이트 재실행이 겹쳐도 하나만 유지)
try { $script:LU4New = $false; $script:LU4Mutex = New-Object System.Threading.Mutex($true, 'LU4_GrindMeter_SingleInstance', [ref]$script:LU4New); if (-not $script:LU4New) { exit } } catch {}
# 검은 콘솔 창 숨기기(창 없이 실행)
try { Add-Type -Name ConWin -Namespace LU4H -MemberDefinition '[DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int n);'; $cw = [LU4H.ConWin]::GetConsoleWindow(); if ($cw -ne [System.IntPtr]::Zero) { [void][LU4H.ConWin]::ShowWindow($cw, 0) } } catch {}
try { Add-Type -Name Key -Namespace LU4K -MemberDefinition '[DllImport("user32.dll")] public static extern short GetAsyncKeyState(int k);' } catch {}
Add-Type -AssemblyName System.Windows.Forms, System.Drawing, System.Runtime.WindowsRuntime, Microsoft.VisualBasic
Add-Type @"
using System; using System.Runtime.InteropServices;
public static class LU4W {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L; public int T; public int R; public int B; }
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
}
"@
[void][LU4W]::SetProcessDPIAware()
# ---------- 글꼴: 한글 패치에 쓴 Pretendard (폴더에 있으면 사용, 없으면 맑은 고딕) ----------
Add-Type -Namespace LU4F -Name G -MemberDefinition '[DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern int AddFontResourceEx(string f, uint fl, IntPtr r);'
$PFC = New-Object System.Drawing.Text.PrivateFontCollection
$FamReg = $null; $FamBold = $null
foreach ($fp in @('Pretendard-SemiBold.ttf', 'Pretendard-Bold.ttf')) {
  $full = Join-Path $PSScriptRoot $fp
  if (Test-Path $full) { try { [void][LU4F.G]::AddFontResourceEx($full, 0x10, [IntPtr]::Zero); $PFC.AddFontFile($full) } catch {} }
}
foreach ($ff in $PFC.Families) { if ($ff.Name -eq 'Pretendard SemiBold') { $FamReg = $ff } elseif ($ff.Name -eq 'Pretendard') { $FamBold = $ff } }
if (-not $FamBold) { $FamBold = $FamReg }; if (-not $FamReg) { $FamReg = $FamBold }
function UIFont($size, [switch]$bold) {
  if ($bold -and $FamBold) { return New-Object System.Drawing.Font($FamBold, [single]$size, [System.Drawing.FontStyle]::Bold) }
  if ($FamReg) { return New-Object System.Drawing.Font($FamReg, [single]$size) }
  if ($bold) { return New-Object System.Drawing.Font('Malgun Gothic', [single]$size, [System.Drawing.FontStyle]::Bold) }
  return New-Object System.Drawing.Font('Malgun Gothic', [single]$size)
}

# ---------- 설정 ----------
$Interval = 2000      # 화면 읽기 간격(ms)
$GapSec   = 180       # 경험치 변화 간격이 이 안이면 사냥 중으로 봄(초)
$RestSec  = 600       # 이만큼 경험치가 없으면 시간당 값 초기화(초) - 총합은 유지
$MinShow  = 60        # 구간 사냥 시간이 이 이상일 때부터 시간당 값 표시(초)
# 찾는 위치(게임 화면 비율: 왼쪽, 위, 너비, 높이)
$ZoneName  = @(0.00, 0.00, 0.25, 0.06)   # 좌측 위: 캐릭터 이름(상태창 맨 위)
$ZoneExp   = @(0.00, 0.965, 0.25, 0.035) # 맨 아래 줄 좌측: "EXP ... 21.98%"
$ZoneAdena = @(0.75, 0.965, 0.25, 0.035) # 맨 아래 줄 우측: 아데나 "54,360,135"
$ZoneChat  = @(0.00, 0.55, 0.30, 0.255)  # 좌측 아래 채팅창(피해 메시지)
$ChatMs    = 800      # 채팅 읽기 간격(ms)
$FightGap  = 30       # 이 시간(초) 동안 피해가 없으면 전투 사이로 봄
$CfgPath  = Join-Path $PSScriptRoot 'LU4_GrindMeter_cfg.json'

# 값이 배열로 섞여 들어와도 계산이 멈추지 않게 숫자 하나로 정리
function Num($x) { if ($x -is [array]) { if ($x.Count -eq 0) { return 0.0 }; $x = $x[-1] }; if ($x -eq $null) { return 0.0 }; return [double]$x }
$ErrLog = Join-Path $PSScriptRoot 'LU4_GrindMeter_error.log'
function Log-Err($where, $err) {
  try { $msg = "[{0}] {1}: {2} (줄 {3})`r`n{4}`r`n" -f (Get-Date).ToString('HH:mm:ss'), $where, $err.Exception.Message, $err.InvocationInfo.ScriptLineNumber, $err.ScriptStackTrace
        Add-Content -Path $ErrLog -Value $msg -Encoding UTF8 } catch {}
}

# ---------- Windows 내장 OCR ----------
[void][Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
$asTaskG = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$t) { $task = $asTaskG.MakeGenericMethod($t).Invoke($null, @($op)); [void]$task.Wait(-1); $task.Result }
$ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if (-not $ocr) { $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US')) }

# ---------- 게임 창 ----------
$GamePids = @{}
function Refresh-GamePids {
  $GamePids.Clear()
  Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'lu4*' } | ForEach-Object { $GamePids[[uint32]$_.Id] = $true }
}
function Is-GameWin($h) {
  if ($h -eq [IntPtr]::Zero) { return $false }
  $procId = [uint32]0; [void][LU4W]::GetWindowThreadProcessId($h, [ref]$procId)
  return $GamePids.ContainsKey($procId)
}
$Hwnd = [IntPtr]::Zero     # 측정 중인 게임 창
$LastGame = [IntPtr]::Zero # 마지막으로 앞에 있던 게임 창
$CapMode = ''
$FgSince = $null   # 측정 창이 앞에 온 시각
$TickN = 0
$LastOcr = @()
$AdPos = $null   # 아데나 숫자 위치(하단 우측 영역 안 비율)

function Client-Rect($h) {
  $cr = New-Object LU4W+RECT; [void][LU4W]::GetClientRect($h, [ref]$cr)
  $p = New-Object LU4W+POINT; [void][LU4W]::ClientToScreen($h, [ref]$p)
  return @{ x = $p.X; y = $p.Y; w = $cr.R; h = $cr.B }
}
# 측정 창이 앞에 있을 때만 해당 영역을 화면에서 읽음(다른 캐릭터 창 숫자가 섞이지 않게)
function Grab-Zone($h, $z) {
  if (-not [LU4W]::IsWindow($h)) { $script:CapMode = '게임 창 닫힘'; return $null }
  if ([LU4W]::IsIconic($h)) { $script:CapMode = '최소화'; return $null }
  if ([LU4W]::GetForegroundWindow() -ne $h) {
    $script:CapMode = '다른 창 보는 중(대기)'
    if ($FgSince) { $script:FgSince = $null; $S.pend = $null; $S.pendN = 0; $S.aPend = $null; $S.aPendN = 0; $DP.prev = @(); $DP.prevIds = @() }
    return $null
  }
  # 창을 바꾼 직후에는 화면에 다른 창이 잠깐 남아 있을 수 있어 2초 기다린 뒤 읽음
  if (-not $FgSince) { $script:FgSince = [DateTime]::Now; $script:CapMode = '창 전환 대기'; return $null }
  if (([DateTime]::Now - $FgSince).TotalSeconds -lt 2) { $script:CapMode = '창 전환 대기'; return $null }
  $c = Client-Rect $h
  if ($c.w -le 0 -or $c.h -le 0) { return $null }
  $x = $c.x + [int]($c.w * $z[0]); $y = $c.y + [int]($c.h * $z[1])
  $w = [int]($c.w * $z[2]); $hh = [int]($c.h * $z[3])
  $bmp = New-Object System.Drawing.Bitmap $w, $hh
  $g = [System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($x, $y, 0, 0, $bmp.Size); $g.Dispose()
  $script:CapMode = '읽는 중'
  return $bmp
}
$ocrEn = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US'))
function Ocr-Lines($bmp, $eng = $null) {
  if (-not $bmp) { return @() }
  if (-not $eng) { $eng = $ocr }
  $max = [Math]::Max($bmp.Width, $bmp.Height)
  $scale = [Math]::Max(1.0, [Math]::Min(4.0, 2400.0 / $max))
  $big = New-Object System.Drawing.Bitmap ([int]($bmp.Width * $scale)), ([int]($bmp.Height * $scale))
  $g = [System.Drawing.Graphics]::FromImage($big); $g.InterpolationMode = 'HighQualityBicubic'
  $g.DrawImage($bmp, 0, 0, $big.Width, $big.Height); $g.Dispose(); $bmp.Dispose()
  $ms = New-Object System.IO.MemoryStream; $big.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $big.Dispose(); $ms.Position = 0
  $ras = [System.IO.WindowsRuntimeStreamExtensions]::AsRandomAccessStream($ms)
  $dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ras)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $sb  = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $res = Await ($eng.RecognizeAsync($sb)) ([Windows.Media.Ocr.OcrResult])
  $ms.Dispose()
  $imgW = [double]$sb.PixelWidth; $imgH = [double]$sb.PixelHeight
  $script:LastOcr = @($res.Lines | ForEach-Object {
    $x0 = 1e9; $y0 = 1e9; $x1 = 0; $y1 = 0; $fw = $null
    # (WinRT 목록은 [0]으로 꺼낼 수 없어서 첫 단어는 반복문에서 직접 기억)
    foreach ($wd in $_.Words) { if ($fw -eq $null) { $fw = $wd }; $br = $wd.BoundingRect; $x0 = [Math]::Min($x0, $br.X); $y0 = [Math]::Min($y0, $br.Y); $x1 = [Math]::Max($x1, $br.X + $br.Width); $y1 = [Math]::Max($y1, $br.Y + $br.Height) }
    if ($fw -ne $null) { $fr = $fw.BoundingRect; $fwt = $fw.Text; $fx0 = $fr.X; $fy0 = $fr.Y; $fx1 = $fr.X + $fr.Width; $fy1 = $fr.Y + $fr.Height } else { $fwt = ''; $fx0 = 0; $fy0 = 0; $fx1 = 0; $fy1 = 0 }
    [pscustomobject]@{ Text = $_.Text; Cx = (($x0 + $x1) / 2) / $imgW; Cy = (($y0 + $y1) / 2) / $imgH
      FwText = $fwt; Fx0 = $fx0 / $imgW; Fy0 = $fy0 / $imgH; Fx1 = $fx1 / $imgW; Fy1 = $fy1 / $imgH }
  })
  return @($script:LastOcr | ForEach-Object { $_.Text })
}
function Norm($t) { return (($t -replace '(?<=\d)\s*([,.])\s*(?=\d)', '$1') -replace '(?<=\d)\s+(?=%)', '') }

function Find-Name {
  # 좌측 위 영역에서 위쪽부터 보며 이름처럼 생긴 줄(공백 없는 2~16자, 숫자/기호 위주 아님)을 고름
  $cands = @($LastOcr | Sort-Object Cy, Cx)
  foreach ($ln in $cands) {
    $t = ($ln.Text -replace '[\[\]\(\)|]', '').Trim()
    if ($t.Length -lt 2 -or $t.Length -gt 16) { continue }
    if ($t -match '\s' -or $t -match '[/%:.,+]') { continue }
    if ($t -match '^(?i)(HP|MP|CP|Lv|EXP|SP)\d*$') { continue }
    $letters = ([regex]::Matches($t, '[A-Za-z\uAC00-\uD7A3]')).Count
    if ($letters -ge 2 -and $letters -ge ([double]$t.Length) / 2) { return $t }
  }
  return $null
}
function Find-Exp($lines) {
  foreach ($l in $lines) {
    $m = [regex]::Match((Norm $l), '(\d{1,3})[.,](\d{1,4})%')
    if ($m.Success) { $v = [double]("$($m.Groups[1].Value).$($m.Groups[2].Value)"); if ($v -ge 0 -and $v -le 100) { return $v } }
  }
  return $null
}
function Adena-Cands {
  # 마지막 OCR 결과에서 쉼표 숫자 후보(값, 위치)
  $out = @()
  foreach ($ln in $LastOcr) {
    $n = Norm $ln.Text
    foreach ($m in [regex]::Matches($n, '\d{1,3}(?:[,.]\d{3})+|\d{4,13}')) {
      $out += [pscustomobject]@{ V = [int64]($m.Value -replace '[,.]', ''); Cx = $ln.Cx; Cy = $ln.Cy; Tag = ($n -match '(?i)adena|아데나') }
    }
  }
  return $out
}
function Find-Adena {
  # 저장된 아데나 위치에서 가장 가까운 숫자만 사용
  if (-not $AdPos) { return $null }
  $best = $null; $bd = 1e9
  foreach ($c in (Adena-Cands)) {
    $d = [Math]::Abs($c.Cx - $AdPos.cx) + 3 * [Math]::Abs($c.Cy - $AdPos.cy)
    if ($d -lt $bd) { $bd = $d; $best = $c }
  }
  if ($best -and $bd -lt 0.12) { return $best.V }
  return $null
}
function Pick-AdenaPos {
  $cands = @(Adena-Cands)
  if ($cands.Count -eq 0) { return $null }
  $tag = @($cands | Where-Object { $_.Tag })
  if ($tag.Count -eq 1) { return @{ cx = $tag[0].Cx; cy = $tag[0].Cy } }
  if ($cands.Count -eq 1) { return @{ cx = $cands[0].Cx; cy = $cands[0].Cy } }
  # 여러 개면 묻지 않고 가장 큰 숫자를 아데나로 봄 (정확히 하려면 [영역] → [아데나 영역]으로 숫자 하나만 감싸기)
  $c = @($cands | Sort-Object V -Descending)[0]
  return @{ cx = $c.Cx; cy = $c.Cy }
}

# ---------- 상태/계산 (v31 사냥 지표 규칙) ----------
$S = @{ running = $false; name = ''; last = $null; pend = $null; pendN = 0; lastGain = $null
        totExp = 0.0; segExp = 0.0; hunt = 0.0; segHunt = 0.0
        aLast = $null; aPend = $null; aPendN = 0; totAd = [int64]0; segAd = [int64]0; dbg = ''; adSeen = $false; adChat = $false; chatTot = [int64]0; chatSeg = [int64]0; ocrTot = [int64]0; ocrSeg = [int64]0; adDbg = ''; asked = $false; gains = (New-Object System.Collections.ArrayList) }
function Reset-Seg { $S.segExp = 0.0; $S.segHunt = 0.0; $S.segAd = 0; $S.chatSeg = 0; $S.ocrSeg = 0 }
function Reset-All { $S.gains.Clear(); $S.totExp = 0.0; $S.hunt = 0.0; $S.totAd = 0; $S.chatTot = 0; $S.ocrTot = 0; Reset-Seg; $S.last = $null; $S.pend = $null; $S.aLast = $null; $S.aPend = $null; $S.lastGain = $null }
function On-Gain {
  $now = [DateTime]::Now
  if ($S.lastGain) {
    $gap = ($now - $S.lastGain).TotalSeconds
    if ($gap -le $GapSec) { $S.hunt += $gap; $S.segHunt += $gap } elseif ($gap -ge $RestSec) { Reset-Seg }
  }
  $S.lastGain = $now
}
function Feed-Exp($v) {
  if ($v -eq $null) { return }
  if ($S.pend -ne $null -and [Math]::Abs($S.pend - $v) -lt 0.0001) { $S.pendN++ } else { $S.pend = $v; $S.pendN = 1 }
  # 증가: 15% 미만은 2회, 그 이상은 4회 연속 같으면 인정(저레벨은 한 마리에 몇 %씩 올라서 기다리면 놓침)
  # 감소(레벨업/잘못 읽음): 6회 연속 같아야 인정
  $need = 2
  if ($S.last -ne $null) {
    if ($v -lt $S.last) { $need = 6 } elseif (($v - $S.last) -ge 15) { $need = 4 }
  }
  if ($S.pendN -lt $need) { return }
  $now = [DateTime]::Now
  if ($S.last -eq $null) { $S.last = $v; return }
  if ($v -gt $S.last) {
    $d = $v - $S.last
    if ($d -lt 40) { $S.totExp += $d; $S.segExp += $d; [void]$S.gains.Add(@($now, $d)); On-Gain }   # 40% 넘게 한 번에 오르면 잘못 읽은 것으로 보고 기준만 갱신
    $S.last = $v
  } elseif ($v -lt $S.last) {
    if ($S.last - $v -gt 50) {
      $S.totExp += (100 - $S.last) + $v; On-Gain; Reset-Seg; $S.gains.Clear()   # 레벨업: 이 시점부터 시간당 재계산
    } else {
      # 잘못 읽어 올라갔던 값이 원래대로 돌아온 경우: 최근 2분 안에 더한 만큼 되돌림
      $back = $S.last - $v; $undo = 0.0
      for ($q = $S.gains.Count - 1; $q -ge 0 -and $back -gt 0.00001; $q--) {
        $gq = $S.gains[$q]
        if (($now - $gq[0]).TotalSeconds -gt 120) { break }
        $take = [Math]::Min($back, $gq[1]); $undo += $take; $back -= $take
        if ($take -ge $gq[1] - 0.00001) { $S.gains.RemoveAt($q) } else { $S.gains[$q] = @($gq[0], ($gq[1] - $take)) }
      }
      if ($undo -gt 0) { $S.totExp = [Math]::Max(0, $S.totExp - $undo); $S.segExp = [Math]::Max(0, $S.segExp - $undo) }
    }
    $S.last = $v
  }
  while ($S.gains.Count -and ($now - $S.gains[0][0]).TotalSeconds -gt 120) { $S.gains.RemoveAt(0) }
}
function Feed-Adena($a) {
  if ($a -eq $null) { return }
  $S.adSeen = $true
  if ($S.aPend -eq $a) { $S.aPendN++ } else { $S.aPend = $a; $S.aPendN = 1 }
  $need = 3
  if ($S.aLast -ne $null) {
    $d = $a - $S.aLast; $need = 2
    if ($d -lt 0 -or $d -ge 1000000 -or ("$a").Length -ne ("$($S.aLast)").Length) { $need = 5 }
  }
  if ($S.aPendN -lt $need) { return }
  if ($S.aLast -eq $null) { $S.aLast = $a }
  elseif ($a -gt $S.aLast) { $d = $a - $S.aLast; if ($d -lt 20000000) { $S.ocrTot += $d; $S.ocrSeg += $d }; $S.aLast = $a }
  else { $S.aLast = $a }
  Mix-Adena
}
# 채팅 합계와 화면(오른쪽 아래) 숫자 증가분을 서로 확인
#  - 화면 증가분이 채팅보다 조금 적으면(절반 이상) 채팅이 중복으로 센 것 → 화면 값
#  - 화면 증가분이 훨씬 적으면(절반 미만) 화면 숫자를 못 읽는 중 → 채팅 값
#  - 화면 증가분이 더 크면 화면을 잘못 읽어 튄 것 → 채팅 값
function Pick-Ad($c, $o) { if ($o -lt $c -and $o -ge $c * 0.5) { return $o } else { return $c } }
function Mix-Adena {
  if ($S.adChat -and $S.aLast -ne $null) { $S.totAd = Pick-Ad $S.chatTot $S.ocrTot; $S.segAd = Pick-Ad $S.chatSeg $S.ocrSeg }
  elseif ($S.adChat) { $S.totAd = $S.chatTot; $S.segAd = $S.chatSeg }
  else { $S.totAd = $S.ocrTot; $S.segAd = $S.ocrSeg }
}

function Tick {
  $script:TickN++
  if ($TickN % 15 -eq 1) { Refresh-GamePids }
  # 마지막으로 앞에 있던 게임 창 기억
  $fg = [LU4W]::GetForegroundWindow()
  if (Is-GameWin $fg) { $script:LastGame = $fg }
  if (-not $S.running) { return }
  if ($S.lastGain -and ([DateTime]::Now - $S.lastGain).TotalSeconds -ge $RestSec -and $S.segHunt -gt 0) { Reset-Seg }
  try {
    $le = Ocr-Lines (Grab-Zone $Hwnd $ZoneExp)
    if ($le.Count) { $S.dbg = ($le -join ' | '); Feed-Exp (Find-Exp $le) }
    $la = Ocr-Lines (Grab-Zone $Hwnd $ZoneAdena)
    if ($la.Count) {
      $S.adDbg = ($la -join ' | ')
      if (-not $AdPos) {
        $c = @(Adena-Cands)
        if ($c.Count -eq 1) { $script:AdPos = @{ cx = $c[0].Cx; cy = $c[0].Cy }; Save-Cfg }
        elseif ($c.Count -gt 1 -and -not $S.asked) { $S.asked = $true; $p = Pick-AdenaPos; if ($p) { $script:AdPos = $p; Save-Cfg } }
      }
      Feed-Adena (Find-Adena)
    }
  } catch { $S.dbg = "오류: $($_.Exception.Message)" }
}

# ---------- 파티원 완제품 획득 ----------
$Equip = New-Object 'System.Collections.Generic.HashSet[string]'
$EqPath = Join-Path $PSScriptRoot 'equip_names.txt'
function Norm-Item($n) { return (($n -replace '\s', '') -replace '[^\w가-힣+\-]', '').ToLower() }
if (Test-Path $EqPath) { foreach ($ln in (Get-Content $EqPath -Encoding UTF8)) { if ($ln.Trim()) { [void]$Equip.Add((Norm-Item $ln)) } } }
$LastLoot = ''
$Loots = New-Object System.Collections.ArrayList   # 대박기원 목록(최근 50개)
$AdSeenK = @{}   # 이미 센 아데나 획득 줄
$EvSeen = @{}; $EvSeenInit = $false   # 이미 센 채팅 줄(시간 표시 기준)
$TmRe = '([0-2]?\d)\s*[:;.]\s*([0-5]\d)\s*[\)\]\}]?\s*$'
$GetSeen = @{}
$NameCache = @{}
$CaseVotes = New-Object System.Collections.ArrayList   # 이름 표기(대소문자) 확인용
$NameVotes = @{}   # 채팅 피해 줄에서 본 이름 횟수(내 이름 자동 확인용)
$NameDbg = ''
# 알림음: 같은 폴더에 alert.wav가 있으면 그 소리, 없으면 윈도우 기본 알림음
$AlertWav = @((Join-Path $PSScriptRoot 'alert.wav'), "$env:WINDIR\Media\Windows Notify System Generic.wav", "$env:WINDIR\Media\Windows Notify.wav", "$env:WINDIR\Media\chimes.wav") | Where-Object { Test-Path $_ } | Select-Object -First 1
$Player = $null
if ($AlertWav) { try { $Player = New-Object System.Media.SoundPlayer $AlertWav; $Player.Load() } catch { $Player = $null } }
# 대박기원 알림음: "대박기원" 글자 오른쪽 클릭으로 소리 바꾸기(차례로 미리 듣기). 폴더의 loot_alert.wav 도 목록에 들어감
$LootSnd = @()
$pp0 = Join-Path $PSScriptRoot 'loot_alert.wav'; if (Test-Path $pp0) { $LootSnd += $pp0 }
foreach ($nm in @('tada.wav', 'chimes.wav', 'chord.wav', 'ding.wav', 'notify.wav', 'Windows Notify System Generic.wav', 'Windows Notify Messaging.wav',
                  'Windows Notify Email.wav', 'Windows Notify Calendar.wav', 'Windows Message Nudge.wav', 'Windows Proximity Notification.wav')) {
  $pp = Join-Path $env:WINDIR ('Media\' + $nm); if (Test-Path $pp) { $LootSnd += $pp }
}
$Player = $null; $LootIdx = 0
function Load-LootSnd($i) {
  if ($LootSnd.Count -eq 0) { return }
  $script:LootIdx = (($i % $LootSnd.Count) + $LootSnd.Count) % $LootSnd.Count
  try { $script:Player = New-Object System.Media.SoundPlayer $LootSnd[$LootIdx]; $Player.Load() } catch { $script:Player = $null }
}
function Play-Alert { try { if ($Player) { $Player.Play() } else { [System.Media.SystemSounds]::Exclamation.Play() } } catch {} }
$LootSeen = @{}
# 강화 주문서: 젤(무기) / 데이(갑옷). 축복받은 → 축젤/축데이, 결정 → 결정젤/결정데이
function Is-Scroll($item) { return ($item -match '(무기|갑옷)\s*강화\s*주문서') }
function Short-Scroll($item) {
  $kind = $(if ($item -match '무기') { '젤' } else { '데이' })
  $pre = $(if ($item -match '축복') { '축' } elseif ($item -match '결정') { '결정' } else { '' })
  $gm = [regex]::Match($item, '([ABCDS])\s*-?\s*(Grade|그레이드)')
  $cnt = [regex]::Match($item, '(\d+)\s*개')
  return ($pre + $kind + $(if ($gm.Success) { '(' + $gm.Groups[1].Value + ')' } else { '' }) + $(if ($cnt.Success) { ' x' + $cnt.Groups[1].Value } else { '' }))
}
function Is-Equip($item, $enchanted) {
  if ($enchanted) { return $true }
  if (Is-Scroll $item) { return $true }
  $n = Norm-Item $item
  if ($Equip.Contains($n)) { return $true }
  $base = Norm-Item (($item -split '\*')[0])
  return $Equip.Contains($base)
}

# ---------- DPS (채팅창 피해 메시지) ----------
$DP = @{ prevIds = @(); prev = @(); dmg = [int64]0; hits = 0; crits = 0; fight = 0.0; lastHit = $null; recent = New-Object System.Collections.ArrayList
        taken = [int64]0; takenRecent = New-Object System.Collections.ArrayList; chatDbg = '' }
function Reset-Dps { $DP.prevIds = @(); $AdSeenK.Clear(); $EvSeen.Clear(); $script:EvSeenInit = $false; $script:LastLoot = ''; $Loots.Clear(); $LootSeen.Clear(); $DP.prev = @(); $DP.dmg = 0; $DP.hits = 0; $DP.crits = 0; $DP.fight = 0.0; $DP.lastHit = $null; $DP.recent.Clear(); $DP.taken = 0; $DP.takenRecent.Clear() }
function Parse-Chat($t) {
  $t = ($t -replace '\s+', ' ').Trim()
  # 채팅 시간 표시 "(21:24)"가 끝에 붙어 있으면 떼어 냄(시간은 따로 기억: 같은 줄 중복 확인용)
  $tmm = [regex]::Match($t, '([0-2]?\d)\s*[:;.]\s*([0-5]\d)\s*[\)\]\}]?\s*$'); $tmS = $(if ($tmm.Success) { $tmm.Groups[1].Value + ':' + $tmm.Groups[2].Value } else { '' })
  $t = ($t -replace '\s*[\(\[\{]?\s*[0-2]?\d\s*[:;.]\s*[0-5]\d\s*[\)\]\}]?\s*$', '').Trim()
  # 구분 기호(»» 등)는 글자 인식에 따라 다르게 읽히므로 기호 1~3개면 모두 허용
  $sep = '[^\w\s가-힣]{1,5}'
  $m = [regex]::Match($t, "^(\S+?) ?$sep ?(.+?) ?$sep ?([\d][\d,.]{0,8})$")
  if ($m.Success) { return @{ k = 'out'; who = $m.Groups[1].Value; v = [int64]($m.Groups[3].Value -replace '[,.]', ''); t = $t } }
  $m = [regex]::Match($t, "^([\d][\d,.]{0,8}) ?$sep ?(\S+?) ?$sep ?(.+)$")
  if ($m.Success) { return @{ k = 'in'; who = $m.Groups[2].Value; v = [int64]($m.Groups[1].Value -replace '[,.]', ''); t = $t } }
  if ($t -match '크리티컬') { return @{ k = 'crit'; who = ($t -replace '[이(].*$', ''); v = 0; t = $t } }
  # 내가 얻은 아데나: "4293 아데나를 획득했습니다." (다른 사람 "~님이"는 제외)
  $m = [regex]::Match($t, '^([\d][\d,.]{0,12}) ?아데나')
  if ($m.Success -and $t -notmatch '님이' -and $t -match '(획[득특]|얻었)') { return @{ k = 'adena'; v = [int64]($m.Groups[1].Value -replace '[,.]', ''); t = $t; tm = $tmS } }
  $m = [regex]::Match($t, '^(\S+?) ?님이 ?(\+ ?\d+ ?)?(.+?) ?[을를]\s*\(?[을를]?\)? ?획[득특]')
  if ($m.Success) {
    $item = $m.Groups[3].Value.Trim()
    if (($item -match '\d+ ?개$' -and -not (Is-Scroll $item)) -or $item -match '아데나$') { return @{ k = 'stack'; who = $m.Groups[1].Value; v = 0; t = $t } }
    return @{ k = 'loot'; who = $m.Groups[1].Value; item = $item; ench = ($m.Groups[2].Value -replace ' ', ''); v = 0; t = $t }
  }
  # 내가 획득: "아이템을(를) 획득했습니다." / "+4 아이템을(를) 획득했습니다."
  $m = [regex]::Match($t, '^(\+ ?\d+ ?)?(.+?) ?[을를]\s*\(?[을를]?\)? ?(획[득특]|얻었)')
  if ($m.Success -and $t -notmatch '님이') {
    $item = $m.Groups[2].Value.Trim()
    if ($item -match '^(경험치|SP)' -or ($item -match '^\d' -and -not (Is-Scroll $item)) -or ($item -match '\d+ ?개$' -and -not (Is-Scroll $item)) -or $item -match '아데나$') { return $null }
    return @{ k = 'loot'; who = '(나)'; mine = $true; item = $item; ench = ($m.Groups[1].Value -replace ' ', ''); v = 0; t = $t }
  }
  return $null
}
function Name-Key($n) { if (-not $n) { return '' }; return ($n.ToLower() -replace '0', 'o' -replace '[1il|]', 'l' -replace '[^a-z0-9가-힣]', '') }
function Same-Seq($a, $b) {
  # 글자 인식 흔들림을 감안해 3줄 이상이면 1줄 차이까지 같은 것으로 봄
  $bad = 0
  for ($i = 0; $i -lt $a.Count; $i++) { if ($a[$i] -ne $b[$i]) { $bad++ } }
  return ($bad -eq 0) -or ($a.Count -ge 3 -and $bad -le 1)
}
function Char-W($t) { $acc = 0.0; foreach ($ch in $t.ToCharArray()) { if ([int]$ch -ge 0xAC00 -and [int]$ch -le 0xD7A3) { $acc += 1.8 } else { $acc += 1.0 } }; return $acc }
function Pad-Bmp($src) {
  # 글자 인식이 잘 되도록 둘레에 여백(배경색)을 붙임
  $pad = [int][Math]::Max(8, $src.Height)
  $bg = $src.GetPixel(0, 0)
  $out = New-Object System.Drawing.Bitmap ($src.Width + 2 * $pad), ($src.Height + 2 * $pad)
  $g = [System.Drawing.Graphics]::FromImage($out); $g.Clear($bg); $g.DrawImage($src, $pad, $pad, $src.Width, $src.Height); $g.Dispose(); $src.Dispose()
  return $out
}
function Ocr-Crop($img, $x0, $y0, $x1, $y1) {
  $x0 = [int][Math]::Max(0, $x0); $y0 = [int][Math]::Max(0, $y0)
  $x1 = [int][Math]::Min($img.Width, $x1); $y1 = [int][Math]::Min($img.Height, $y1)
  if ($x1 - $x0 -lt 4 -or $y1 - $y0 -lt 4) { return '' }
  $crop = $img.Clone((New-Object System.Drawing.Rectangle $x0, $y0, ($x1 - $x0), ($y1 - $y0)), $img.PixelFormat)
  $save = $LastOcr
  $txt = (Ocr-Lines (Pad-Bmp $crop) $ocrEn) -join ' '
  $script:LastOcr = $save
  return $txt
}
function Read-NameEn($img, $ln) {
  $script:NameDbg = '(잘라 읽기 안 함)'
  $fw = "$($ln.FwText)"
  $i = $fw.IndexOf('님')
  if ($i -eq 0) { return $null }
  $namePart = if ($i -gt 0) { $fw.Substring(0, $i) } else { $fw }
  $frac = if ($i -gt 0) { (Num (Char-W $namePart)) / [Math]::Max(1.0, (Num (Char-W $fw))) } else { 1.0 }
  $imW = $img.Width; $imH = $img.Height
  $lx = $ln.Fx0 * $imW; $rx = $ln.Fx1 * $imW; $ty = $ln.Fy0 * $imH - 3; $by = $ln.Fy1 * $imH + 3
  # 1) 이름 부분만 잘라 읽기
  $t1 = Ocr-Crop $img ($lx - 2) $ty ($lx + ($rx - $lx) * $frac + 1) $by
  $tok1 = $t1 -replace '[^A-Za-z0-9_]', ''
  # 2) 첫 단어 전체를 읽고 앞에서 이름 길이만큼 자르기
  $t2 = Ocr-Crop $img ($lx - 2) $ty ($rx + 2) $by
  $tok2 = (($t2 -split '\s+')[0]) -replace '[^A-Za-z0-9_]', ''
  $n = [int][Math]::Round((Num (Char-W $namePart)))
  if ($n -lt 2) { $n = 2 }
  $script:NameDbg = "1차='$t1' 2차='$t2' 예상길이=$n"
  if ($tok1.Length -ge 2) { return $tok1 }
  if ($tok2.Length -ge 2) { return $tok2.Substring(0, [Math]::Min($n, $tok2.Length)) }
  return $null
}
function Chat-Tick {
  if (-not $S.running) { return }
  $bmp = Grab-Zone $Hwnd $ZoneChat
  if (-not $bmp) { return }
  $copy = $bmp.Clone()
  $lines = Ocr-Lines $bmp
  if (-not $lines.Count) { $copy.Dispose(); return }
  $ocrLn = $LastOcr
  $ev = @()
  for ($j = 0; $j -lt $ocrLn.Count; $j++) { $e = Parse-Chat $ocrLn[$j].Text; if ($e) { $e.cy = $ocrLn[$j].Cy; $e.ln = $ocrLn[$j]; $ev += ,$e } }
  # 획득 줄의 이름이 영문인데 한글로 잘못 읽힌 경우(예: ZIC -> 기c) 영문 인식으로 다시 확인
  # 캐릭터 이름은 모두 영문: 획득 줄 맨 앞 단어에서 "님이" 앞의 이름 부분만 잘라 영문으로 다시 읽음
  foreach ($e in @($ev | Where-Object { $_.k -eq 'loot' -and -not $_.mine })) {
    if (-not $e.ln) { continue }
    $kor = $e.who
    $script:NameDbg = '(영문 인식 엔진 없음)'
    # 같은 줄은 한 번만 영문으로 다시 읽음(채팅에 남아 있는 동안 반복하지 않게)
    if ($NameCache.ContainsKey($e.t)) { $nm = $NameCache[$e.t] }
    else { $nm = if ($ocrEn) { Read-NameEn $copy $e.ln } else { $null }; if ($NameCache.Count -gt 200) { $NameCache.Clear() }; $NameCache[$e.t] = $nm }
    if ($nm) { $e.who = $nm }
  }
  $DP.chatDbg = if ($ev.Count) { $ev[-1].t } else { '(피해 줄 없음) 읽은 줄: ' + ($lines[-3..-1] -join ' | ') }
  $cur = @($ev | ForEach-Object { $_.t })
  $prev = $DP.prev
  # 이전 화면의 끝부분과 지금 화면의 앞부분이 겹치는 만큼은 이미 센 줄
  $k = 0
  for ($n = [Math]::Min($prev.Count, $cur.Count); $n -ge 1; $n--) {
    if (Same-Seq @($prev[($prev.Count - $n)..($prev.Count - 1)]) @($cur[0..($n - 1)])) { $k = $n; break }
  }
  if ($prev.Count -eq 0) { $k = $cur.Count }   # 처음 화면은 기준으로만 사용
  $DP.prev = $cur
  $now = [DateTime]::Now
  # 내 피해 줄("이름 »» 대상 »» 숫자")에 가장 많이 나오는 이름을 내 이름으로 확인
  for ($i2 = $k; $i2 -lt $ev.Count; $i2++) {
    $e2 = $ev[$i2]
    if ($e2.k -eq 'out' -or $e2.k -eq 'crit') {
      $raw = ($e2.who -replace '[^A-Za-z0-9_가-힣]', '')
      $nk = Name-Key $raw
      if ($nk) {
        if (-not $NameVotes.ContainsKey($nk)) { $NameVotes[$nk] = @{ n = 0; raws = @{} } }
        $NameVotes[$nk].n++
        if (-not $NameVotes[$nk].raws.ContainsKey($raw)) { $NameVotes[$nk].raws[$raw] = 0 }
        $NameVotes[$nk].raws[$raw]++
      }
    }
  }
  if (-not $S.nameManual -and $NameVotes.Count) {
    $top = $NameVotes.GetEnumerator() | Sort-Object { $_.Value.n } -Descending | Select-Object -First 1
    if ($top.Value.n -ge 5) {
      # 대소문자: 채팅은 DOZ/Doz처럼 섞여 읽히므로 대소문자가 섞인 표기 중 가장 많이 본 것을 사용
      $vars = $top.Value.raws.GetEnumerator() | Sort-Object { $(if ($_.Key -cmatch '[a-z]' -and $_.Key -cmatch '[A-Z]') { 0 } else { 1 }) }, { -$_.Value }
      $best = ($vars | Select-Object -First 1).Key
      # 시작할 때 좌측 위에서 영문으로 읽은 이름이 같은 이름이면 그 표기(DoZ)를 그대로 유지
      if ($top.Key -ne (Name-Key $S.name) -and $top.Key -ne $S.aliasKey) { $S.name = $best; $CaseVotes.Clear() }
    }
  }
  # 이름 대소문자 자동 맞춤: 내 피해 줄 맨 앞 단어(이름)만 잘라 영문으로 읽고, 5번 중 가장 많이 나온 표기 사용
  if ($ocrEn -and -not $S.nameManual -and -not $S.nameFromStatus -and $CaseVotes.Count -lt 5 -and $S.name) {
    $myKey = Name-Key $S.name
    $cand = @($ev | Where-Object { $_.k -eq 'out' -and $_.ln -and (Name-Key $_.who) -eq $myKey }) | Select-Object -Last 1
    if ($cand -and $copy) {
      $ln = $cand.ln; $iw = $copy.Width; $ih = $copy.Height
      $tc = (Ocr-Crop $copy ($ln.Fx0 * $iw - 2) ($ln.Fy0 * $ih - 3) ($ln.Fx1 * $iw + 2) ($ln.Fy1 * $ih + 3)) -replace '[^A-Za-z0-9_]', ''
      # 이름이 한글로 잘못 읽힌 경우(ZIC -> 기C): 같은 줄 맨 앞 이름을 영문으로 읽은 값을 그대로 사용
      if ((Name-Key $tc) -eq $myKey -or ($S.name -match '[가-힣]' -and $tc -match '^[A-Za-z][A-Za-z0-9_]{1,15}$')) { [void]$CaseVotes.Add($tc) }
    }
    if ($CaseVotes.Count -ge 5) {
      $bestCase = ($CaseVotes | Group-Object -CaseSensitive | Sort-Object Count -Descending | Select-Object -First 1).Name
      if ($bestCase) { if ((Name-Key $bestCase) -ne $myKey) { $S.aliasKey = $myKey }; $S.name = $bestCase }
    }
  }
  if ($copy) { $copy.Dispose(); $copy = $null }
  $me = Name-Key $S.name
  $al = $S.aliasKey
  # 처리할 줄 고르기
  #  - 채팅 시간 표시가 켜져 있으면: 줄마다 "종류|숫자|시간"과 같은 화면 안 몇 번째인지로 이름을 붙여 한 번만 셈
  #    (글자 인식이 흔들려 같은 줄을 새 줄로 착각해 두 번 세는 것을 막음 → DPS/크리 과대 방지)
  #  - 없으면: 이전 화면과 겹치는 부분 다음부터(기존 방식)
  $todoIdx = @()
  $nTm = 0; foreach ($e0 in $ev) { if ($e0.ln -and $e0.ln.Text -match $TmRe) { $nTm++ } }
  if ($true) {   # 채팅 시간 표시가 없어도 같은 방식(위치 맞춤)으로
    # 줄마다 짧은 이름 "종류|숫자|시간"을 붙이고, 이전 화면과 겹치는 위치를 찾아 그 뒤의 줄만 새 줄로 셈
    # (같은 숫자가 반복되거나 글자 인식이 한두 줄 틀려도 위치로 맞춤)
    $ids = @()
    foreach ($e0 in $ev) {
      $tmm0 = [regex]::Match([string]$e0.ln.Text, $TmRe)
      $tm0 = $(if ($tmm0.Success) { $tmm0.Groups[1].Value + ':' + $tmm0.Groups[2].Value } else { '?' })
      $ids += ($e0.k + '|' + $e0.v + '|' + $tm0)
    }
    $pv = @($DP.prevIds)
    if ($pv.Count -eq 0) { $startI = $ids.Count }   # 처음 화면은 기준으로만
    else {
      $best = -1.0; $bestO = -1
      for ($o = 0; $o -lt $pv.Count; $o++) {
        $len = [Math]::Min($pv.Count - $o, $ids.Count); if ($len -le 0) { continue }
        $mt = 0; for ($q = 0; $q -lt $len; $q++) { if ($pv[$o + $q] -eq $ids[$q]) { $mt++ } }
        $sc = $mt / [double]$len
        if ($len -lt 3 -and $sc -lt 1) { continue }
        if ($sc -gt $best + 0.001) { $best = $sc; $bestO = $o }
      }
      if ($bestO -ge 0 -and $best -ge 0.6) { $startI = [Math]::Min($ids.Count, $pv.Count - $bestO) }
      elseif ($bestO -lt 0 -and $ids.Count -gt 0) { $startI = 0 }   # 겹침이 전혀 없음 = 화면이 통째로 바뀜(전부 새 줄)
      else { $startI = $ids.Count }                                  # 애매하면 이번엔 세지 않음(두 번 세기 방지)
    }
    $DP.prevIds = $ids
    for ($i0 = $startI; $i0 -lt $ev.Count; $i0++) { $todoIdx += $i0 }
  } else { for ($i0 = $k; $i0 -lt $ev.Count; $i0++) { $todoIdx += $i0 } }
  foreach ($i in $todoIdx) {
    $e = $ev[$i]
    if ($e.k -eq 'loot') {
      if (($e.mine -or ((Name-Key $e.who) -ne $me -and (Name-Key $e.who) -ne $al)) -and (Is-Equip $e.item ([bool]$e.ench))) {
        # 같은 아이템 획득 줄을 여러 번 읽는 경우가 있어 60초 안의 같은 아이템은 한 번만
        $key = Norm-Item ($e.ench + $e.item)
        if (-not $LootSeen.ContainsKey($key) -or ($now - $LootSeen[$key]).TotalSeconds -gt 60) {
          $LootSeen[$key] = $now
          $iname = $e.item   # 게임 안 이름 그대로
          $txtL = '★ {0}: {1}{2} ({3})' -f $(if ($e.mine) { '나' } else { $e.who }), $(if ($e.ench) { $e.ench + ' ' } else { '' }), $iname, $now.ToString('HH:mm')
          [void]$Loots.Insert(0, $txtL); while ($Loots.Count -gt 50) { $Loots.RemoveAt(50) }; $script:LastLoot = $txtL
          Play-Alert
        }
      }
      continue
    }
    if ($e.k -eq 'adena') {
      # 채팅의 아데나 획득 메시지로 아데나를 셈(화면 숫자 읽기보다 정확해서, 한 번이라도 잡히면 이쪽만 사용)
      if (-not $S.adChat) { $S.adChat = $true; $S.ocrTot = 0; $S.ocrSeg = 0; Log-Err '아데나' ([pscustomobject]@{ Exception = [pscustomobject]@{ Message = '채팅 아데나 획득 메시지로 계산 시작' }; InvocationInfo = [pscustomobject]@{ ScriptLineNumber = 0 } }) }
      $S.adSeen = $true
      # 같은 획득 줄을 두 번 세지 않게: 채팅 시간이 있으면 "금액@시간", 없으면 같은 금액 90초 안은 한 번만
      $ak = '' + $e.v + '@' + $e.tm
      $dup = $AdSeenK.ContainsKey($ak) -and ($e.tm -or ($now - $AdSeenK[$ak]).TotalSeconds -lt 90)
      if ($dup) { continue }
      $AdSeenK[$ak] = $now; if ($AdSeenK.Count -gt 400) { $AdSeenK.Clear() }
      if ($e.v -gt 0 -and $e.v -lt 50000000) { $S.chatTot += $e.v; $S.chatSeg += $e.v }
      Mix-Adena
      continue
    }
    if ($me -and (Name-Key $e.who) -ne $me -and (Name-Key $e.who) -ne $al) { continue }
    if ($e.k -eq 'out' -and $e.v -gt 0 -and $e.v -lt 1000000) {
      if ($DP.lastHit) { $gap = ($now - $DP.lastHit).TotalSeconds; if ($gap -le $FightGap) { $DP.fight += $gap } }
      $DP.lastHit = $now; $DP.dmg += $e.v; $DP.hits++; [void]$DP.recent.Add(@($now, $e.v))
      # 크리티컬: 대미지 줄 바로 위에 "크리티컬 공격에 성공했습니다!" 줄이 있으면 그 타격은 크리
      # (크리 줄은 글이 모두 같아서 따로 세면 빠지거나 겹치므로, 대미지 줄에 붙여서 셈)
      if ($i -ge 1 -and $ev[$i - 1].k -eq 'crit') { $DP.crits++ }
    } elseif ($e.k -eq 'crit') { }
    elseif ($e.k -eq 'in' -and $e.v -gt 0 -and $e.v -lt 1000000) { $DP.taken += $e.v; [void]$DP.takenRecent.Add(@($now, $e.v)) }
  }
  foreach ($lst in @($DP.recent, $DP.takenRecent)) { while ($lst.Count -and ($now - $lst[0][0]).TotalSeconds -gt 10) { $lst.RemoveAt(0) } }
}
function Dps-Text {
  $now = [DateTime]::Now
  $r = [int64]0; foreach ($x in $DP.recent) { $r += $x[1] }
  $win = 10.0
  if ($DP.recent.Count) { $win = [Math]::Min(10.0, [Math]::Max(1.0, ($now - $DP.recent[0][0]).TotalSeconds + 1)) }
  $cur = if ($DP.lastHit -and ($now - $DP.lastHit).TotalSeconds -le $FightGap) { (Num $r) / [Math]::Max(1.0, (Num $win)) } else { 0 }
  $avg = if ($DP.fight -ge 1) { (Num $DP.dmg) / (Num $DP.fight) } else { 0 }
  $cr = if ($DP.hits) { 100.0 * (Num $DP.crits) / (Num $DP.hits) } else { 0 }
  return ('DPS: {0:N0} (평균 {1:N0}) 크리 {2:N0}%' -f $cur, $avg, [Math]::Min(100, $cr))
}
function Taken-Text {
  $t = [int64]0; foreach ($x in $DP.takenRecent) { $t += $x[1] }
  return ('받은 피해: 초당 {0:N0} (총 {1:N0})' -f ((Num $t) / 10.0), (Num $DP.taken))
}

# ---------- 창 ----------
$cfg = @{ x = 50; y = 50; sndFile = ''; zchat = $null; zad = $null }
$SavedNames = @()   # 직접 입력한 캐릭터 이름(대소문자 표기 기억)
if (Test-Path $CfgPath) { try { $j = Get-Content $CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json; $cfg.x = $j.x; $cfg.y = $j.y; if ($j.adcx -ne $null) { $AdPos = @{ cx = [double]$j.adcx; cy = [double]$j.adcy } }; if ($j.names) { $SavedNames = @($j.names) }; if ($j.sndFile) { $cfg.sndFile = [string]$j.sndFile }; if ($j.zchat -and @($j.zchat).Count -eq 4) { $ZoneChat = @([double]$j.zchat[0], [double]$j.zchat[1], [double]$j.zchat[2], [double]$j.zchat[3]); $cfg.zchat = $ZoneChat }; if ($j.zad -and @($j.zad).Count -eq 4) { $ZoneAdena = @([double]$j.zad[0], [double]$j.zad[1], [double]$j.zad[2], [double]$j.zad[3]); $cfg.zad = $ZoneAdena } } catch {} }
function Save-Cfg { $o = @{ x = $cfg.x; y = $cfg.y; names = @($SavedNames); sndFile = $cfg.sndFile; zchat = $cfg.zchat; zad = $cfg.zad }; if ($AdPos) { $o.adcx = $AdPos.cx; $o.adcy = $AdPos.cy }; $o | ConvertTo-Json | Set-Content $CfgPath -Encoding UTF8 }
function Fix-NameCase($n) {
  # 저장된 이름과 같은 이름(대소문자만 다름)이면 저장된 표기로
  if (-not $n) { return $n }
  foreach ($sv in $SavedNames) { if ((Name-Key $sv) -eq (Name-Key $n)) { return $sv } }
  # 혈맹원 명단(clan_members.txt, 이 폴더 또는 채팅 번역 폴더)에 있으면 그 표기로 (예: Doz -> DoZ)
  foreach ($sv in $KnownNames) { if ((Name-Key $sv) -eq (Name-Key $n)) { return $sv } }
  return $n
}
$KnownNames = @()
foreach ($kp in @((Join-Path $PSScriptRoot 'clan_members.txt'), (Join-Path (Split-Path $PSScriptRoot -Parent) 'LU4_ChatTranslate\clan_members.txt'))) {
  try { if (Test-Path $kp) { $KnownNames += @([System.IO.File]::ReadAllLines($kp, [System.Text.Encoding]::UTF8) | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') }) } } catch {}
}
$form = New-Object System.Windows.Forms.Form
$form.Text = 'LU4 사냥 지표 - made by DoZ'; $form.FormBorderStyle = 'None'; $form.TopMost = $true; $form.ShowInTaskbar = $true
$form.BackColor = [System.Drawing.Color]::FromArgb(20, 22, 26); $form.Opacity = 0.88
$form.StartPosition = 'Manual'; $form.Location = New-Object System.Drawing.Point ([int]$cfg.x), ([int]$cfg.y); $form.Size = '400,318'
$font = UIFont 11
function New-Lbl($y, $color) { $l = New-Object System.Windows.Forms.Label; $l.Location = "10,$y"; $l.Size = '385,23'; $l.ForeColor = $color; $l.Font = $font; $form.Controls.Add($l); $l }
$lTitle = New-Lbl 6 ([System.Drawing.Color]::FromArgb(200,170,90))
$lExp = New-Lbl 33 'White'; $lAd = New-Lbl 58 'White'; $lHunt = New-Lbl 83 'White'
$lDps = New-Lbl 112 ([System.Drawing.Color]::FromArgb(255,170,90)); $lTaken = New-Lbl 137 ([System.Drawing.Color]::FromArgb(200,200,200))
# 대박기원(완제품/강화 주문서 획득): 제목 줄 아래에 목록, 4개 이상이면 스크롤
$lLootHead = New-Lbl 166 ([System.Drawing.Color]::FromArgb(255,140,40))
$lbLoot = New-Object System.Windows.Forms.ListBox
$lbLoot.Location = '10,191'; $lbLoot.Size = '385,70'; $lbLoot.Font = $font; $lbLoot.BorderStyle = 'None'
$lbLoot.BackColor = $form.BackColor; $lbLoot.ForeColor = [System.Drawing.Color]::FromArgb(255,140,40)
$lbLoot.IntegralHeight = $false; $lbLoot.ItemHeight = 23; $lbLoot.SelectionMode = 'None'
$form.Controls.Add($lbLoot)
$lLoot = @($lLootHead)
$LootShownN = -1
$fontBtn = UIFont 10
function New-Btn($text, $x, $w = 90) { $b = New-Object System.Windows.Forms.Button; $b.Text = $text; $b.Location = "$x,272"; $b.Size = "$w,32"; $b.FlatStyle = 'Flat'; $b.ForeColor = 'White'; $b.Font = $fontBtn; $form.Controls.Add($b); $b }
# 창 폭(400) 안에 4개: 시작 / 전체초기화 / 경험치초기화 / 닫기
$bStart = New-Btn '시작' 8 76; $bReset = New-Btn '전체초기화' 88 100; $bExpReset = New-Btn '경험치초기화' 192 112; $bClose = New-Btn '닫기' 308 76
$tip = New-Object System.Windows.Forms.ToolTip
# ---------- 읽을 영역 지정: 게임 화면을 찍어 띄우고 마우스로 드래그 ----------
# $cl = @{ x; y; w; h } (게임 창 안쪽의 화면 좌표). 돌려주는 값: 게임 창 기준 비율 @(왼쪽, 위, 너비, 높이) / 취소하면 $null
function Pick-Zone($cl, $guide, $cur) {
  if (-not $cl -or $cl.w -le 0 -or $cl.h -le 0) { [System.Windows.Forms.MessageBox]::Show('게임 창을 찾지 못했어요. 게임을 한 번 앞에 띄운 뒤 다시 눌러 주세요.', '영역 지정') | Out-Null; return $null }
  $shot = New-Object System.Drawing.Bitmap $cl.w, $cl.h
  $g0 = [System.Drawing.Graphics]::FromImage($shot); $g0.CopyFromScreen($cl.x, $cl.y, 0, 0, $shot.Size); $g0.Dispose()
  $pf = New-Object System.Windows.Forms.Form
  $pf.FormBorderStyle = 'None'; $pf.StartPosition = 'Manual'; $pf.TopMost = $true; $pf.ShowInTaskbar = $false
  $pf.Location = New-Object System.Drawing.Point $cl.x, $cl.y; $pf.Size = New-Object System.Drawing.Size $cl.w, $cl.h
  $pf.Cursor = [System.Windows.Forms.Cursors]::Cross; $pf.KeyPreview = $true
  $pf.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'NonPublic,Instance').SetValue($pf, $true, $null)
  $st = @{ a = $null; b = $null; res = $null }
  if ($cur) { $st.a = New-Object System.Drawing.Point ([int]($cur[0] * $cl.w)), ([int]($cur[1] * $cl.h)); $st.b = New-Object System.Drawing.Point ([int](($cur[0] + $cur[2]) * $cl.w)), ([int](($cur[1] + $cur[3]) * $cl.h)) }
  $fnt = UIFont 14 -bold
  $pf.Add_Paint({
    $gg = $_.Graphics; $gg.DrawImage($shot, 0, 0)
    $dim = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(120, 0, 0, 0))
    $gg.FillRectangle($dim, 0, 0, $pf.Width, $pf.Height)
    if ($st.a -and $st.b) {
      $rx = [Math]::Min($st.a.X, $st.b.X); $ry = [Math]::Min($st.a.Y, $st.b.Y); $rw = [Math]::Abs($st.b.X - $st.a.X); $rh = [Math]::Abs($st.b.Y - $st.a.Y)
      if ($rw -gt 0 -and $rh -gt 0) {
        $gg.DrawImage($shot, (New-Object System.Drawing.Rectangle $rx, $ry, $rw, $rh), (New-Object System.Drawing.Rectangle $rx, $ry, $rw, $rh), [System.Drawing.GraphicsUnit]::Pixel)
        $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(255, 200, 60)), 3; $gg.DrawRectangle($pen, $rx, $ry, $rw, $rh); $pen.Dispose()
      }
    }
    $msg = $guide + "`n마우스로 드래그해서 영역을 정한 뒤 Enter 또는 마우스 오른쪽 클릭으로 저장"
    $sz = $gg.MeasureString($msg, $fnt)
    $gg.FillRectangle((New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(210, 20, 22, 26))), 20, 20, $sz.Width + 20, $sz.Height + 14)
    $gg.DrawString($msg, $fnt, [System.Drawing.Brushes]::Gold, 30, 27)
    $dim.Dispose()
  })
  $pf.Add_MouseDown({ if ($_.Button -eq 'Left') { $st.a = $_.Location; $st.b = $_.Location; $pf.Invalidate() } elseif ($_.Button -eq 'Right') { $st.res = 'ok'; $pf.Close() } })
  $pf.Add_MouseMove({ if ($_.Button -eq 'Left' -and $st.a) { $st.b = $_.Location; $pf.Invalidate() } })
  $pf.Add_KeyDown({ if ($_.KeyCode -eq 'Return') { $st.res = 'ok'; $pf.Close() } })
  # 영역 창에 키보드 초점이 안 와도(게임이 잡고 있어도) Enter가 먹도록 키 상태를 직접 확인
  $kt = New-Object System.Windows.Forms.Timer; $kt.Interval = 40; $st.k0 = $true
  $kt.Add_Tick({
    $ent = ([int][LU4K.Key]::GetAsyncKeyState(13) -band 0x8000) -ne 0
    if ($st.k0) { if (-not $ent) { $st.k0 = $false }; return }
    if ($ent) { $kt.Stop(); $st.res = 'ok'; $pf.Close() }
  })
  $pf.Add_Shown({ $pf.Activate(); [void]$pf.Focus(); try { $kt.Start() } catch {} })
  $pf.Add_Deactivate({ try { $pf.Activate() } catch {} })
  [void]$pf.ShowDialog()
  try { $kt.Stop(); $kt.Dispose() } catch {}
  $shot.Dispose(); $fnt.Dispose()
  if ($st.res -ne 'ok' -or -not $st.a -or -not $st.b) { return $null }
  $rx = [Math]::Max(0, [Math]::Min($st.a.X, $st.b.X)); $ry = [Math]::Max(0, [Math]::Min($st.a.Y, $st.b.Y))
  $rw = [Math]::Min($cl.w - $rx, [Math]::Abs($st.b.X - $st.a.X)); $rh = [Math]::Min($cl.h - $ry, [Math]::Abs($st.b.Y - $st.a.Y))
  if ($rw -lt 20 -or $rh -lt 8) { return $null }
  return @([Math]::Round($rx / $cl.w, 4), [Math]::Round($ry / $cl.h, 4), [Math]::Round($rw / $cl.w, 4), [Math]::Round($rh / $cl.h, 4))
}

# 영역: 대미지/아데나/획득 메시지가 나오는 채팅칸을 마우스로 지정
$lZone = New-Object System.Windows.Forms.Label
$lZone.Text = '영역선택'; $lZone.Font = $fontBtn; $lZone.ForeColor = [System.Drawing.Color]::Silver; $lZone.Location = '322,6'; $lZone.Size = '74,23'; $lZone.Cursor = 'Hand'; $lZone.TextAlign = 'MiddleRight'
$form.Controls.Add($lZone); $lZone.BringToFront(); $lTitle.Width = 248
$lUpd = New-Object System.Windows.Forms.Label
$lUpd.Text = '업데이트'; $lUpd.Font = $fontBtn; $lUpd.ForeColor = [System.Drawing.Color]::Silver; $lUpd.Location = '256,6'; $lUpd.Size = '64,23'; $lUpd.Cursor = 'Hand'; $lUpd.TextAlign = 'MiddleRight'
$form.Controls.Add($lUpd); $lUpd.BringToFront()
# 오른쪽 위 글자를 글자 폭에 딱 맞추고(오른쪽 끝 396), 두 글자 사이 12칸에 구분선이 보이게
$wZn = [System.Windows.Forms.TextRenderer]::MeasureText($lZone.Text, $fontBtn).Width + 2; $lZone.Width = $wZn; $lZone.Left = 396 - $wZn
$wUp = [System.Windows.Forms.TextRenderer]::MeasureText($lUpd.Text, $fontBtn).Width + 2; $lUpd.Width = $wUp; $lUpd.Left = $lZone.Left - 12 - $wUp
$lTitle.Width = [Math]::Max(150, $lUpd.Left - 12 - $lTitle.Left)
$lTitle.Height = 21; $lUpd.Height = 21; $lZone.Height = 21   # 제목줄 높이를 줄여서 아래 가로선을 위로
$tip.SetToolTip($lUpd, '새로 받은 압축 파일로 업데이트 (설정은 그대로)')
# 제작자 표시
$lBy = New-Object System.Windows.Forms.Label
$lBy.Text = 'LU4 · made by DoZ'; $lBy.Font = (UIFont 10); $lBy.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120); $lBy.BackColor = [System.Drawing.Color]::Transparent
$byW = [System.Windows.Forms.TextRenderer]::MeasureText($lBy.Text, $lBy.Font).Width + 6; $lBy.Size = New-Object System.Drawing.Size $byW, 22; $lBy.Location = New-Object System.Drawing.Point (392 - $byW), 167; $lBy.TextAlign = 'MiddleRight'   # 채팅번역과 같은 글자 크기(10)
$form.Controls.Add($lBy); $lBy.BringToFront()
# 업데이트: 받은 새 압축 파일로 업데이트(이 프로그램은 닫고, 끝나면 다시 켬)
function Start-Update([switch]$NoAsk) {
  $up = Join-Path $PSScriptRoot 'install_update.ps1'
  if (-not (Test-Path $up)) { [System.Windows.Forms.MessageBox]::Show('install_update.ps1 이 없어요. 새 압축 파일을 한 번 풀어서 덮어써 주세요.', '업데이트') | Out-Null; return }
  if (-not $NoAsk) {
    $ok = [System.Windows.Forms.MessageBox]::Show("최신 버전을 받아서 업데이트할까요?`n(설정은 그대로 남고, 끝나면 프로그램이 다시 켜져요)", '업데이트', 'YesNo', 'Question')
    if ($ok -ne 'Yes') { return }
  }
  Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $up + '"'), '-FromApp') -WorkingDirectory $PSScriptRoot
  $form.Close()
}
$lUpd.Add_Click({ Start-Update })
$tip.SetToolTip($lZone, '영역 지정: 대미지(시스템 창) / 아데나 숫자')
function Zone-Pick($guide, $cur) {
  $h = $(if ($Hwnd -ne [IntPtr]::Zero -and [LU4W]::IsWindow($Hwnd)) { $Hwnd } else { $LastGame })
  if ($h -eq [IntPtr]::Zero) { [System.Windows.Forms.MessageBox]::Show('게임 창을 한 번 앞에 띄운 뒤 다시 눌러 주세요.', '영역 지정') | Out-Null; return $null }
  [void][LU4W]::SetForegroundWindow($h); Start-Sleep -Milliseconds 400
  $form.Hide(); Start-Sleep -Milliseconds 150
  $z = Pick-Zone (Client-Rect $h) $guide $cur
  $form.Show(); return $z
}
$ZoneMenu = New-Object System.Windows.Forms.ContextMenuStrip; $ZoneMenu.Font = $fontBtn
$miZChat = $ZoneMenu.Items.Add('대미지 영역 (시스템 창)')
$miZAd = $ZoneMenu.Items.Add('아데나 영역 (아데나 숫자)')
$miZAdAuto = $ZoneMenu.Items.Add('아데나 영역 처음 설정으로')
$miZChat.Add_Click({
  $z = Zone-Pick '사냥지표: 시스템(대미지 올라오는 곳) 영역을 지정하세요.' $ZoneChat
  if ($z) { $script:ZoneChat = $z; $cfg.zchat = $z; Save-Cfg; $DP.prev = @(); $lTitle.Text = '대미지 영역 저장됨' }
})
function Ad-Rebase { $script:AdPos = $null; $S.aLast = $null; $S.aPend = $null; $S.aPendN = 0; $S.asked = $false }
$miZAd.Add_Click({
  $z = Zone-Pick '사냥지표: 화면에 보이는 아데나 숫자만 감싸세요. (다른 숫자가 같이 들어가지 않게)' $ZoneAdena
  if ($z) { $script:ZoneAdena = $z; $cfg.zad = $z; Ad-Rebase; Save-Cfg; $lTitle.Text = '아데나 영역 저장됨' }
})
$miZAdAuto.Add_Click({ $script:ZoneAdena = @(0.75, 0.965, 0.25, 0.035); $cfg.zad = $null; Ad-Rebase; Save-Cfg; $lTitle.Text = '아데나 영역: 처음 설정' })
$lZone.Add_Click({ $ZoneMenu.Show($lZone, (New-Object System.Drawing.Point 0, $lZone.Height)) })
# | 업데이트 | 영역선택 구분선 (제목과 업데이트 사이, 업데이트와 영역선택 사이)
$form.Add_Paint({
  $g = $_.Graphics
  $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(95, 95, 100)), 1
  foreach ($xm in @([int]($lUpd.Left - 6), [int](($lUpd.Right + $lZone.Left) / 2))) { $g.DrawLine($pen, $xm, $lZone.Top + 5, $xm, $lZone.Bottom - 5) }
  $yh = $lTitle.Bottom + 1; $g.DrawLine($pen, $lTitle.Left, $yh, $lZone.Right, $yh)   # 제목줄과 경험치 칸 사이 가로선
  $pen.Dispose()
})

function Fmt-Hunt($sec) { $m = [int][Math]::Floor((Num $sec) / 60); "{0}시간 {1}분" -f [int][Math]::Floor($m / 60), ($m % 60) }
function Refresh-UI {
  $ph = if ($S.segHunt -ge $MinShow) { (Num $S.segExp) * 3600 / (Num $S.segHunt) } else { 0 }
  $lExp.Text = ('경험치: {0:N2}%/시간 (총 {1:N2}%)' -f $ph, $S.totExp)
  if ($S.adSeen -or -not $S.running) {
    $pa = if ($S.segHunt -ge $MinShow) { [int64]((Num $S.segAd) * 3600 / (Num $S.segHunt)) } else { 0 }
    $lAd.Text = ('아데나: {0:N0}/시간 (총 {1:N0})' -f $pa, $S.totAd)
  } else { $lAd.Text = '아데나: (화면에서 찾는 중)' }
  $lHunt.Text = '사냥 시간: ' + (Fmt-Hunt $S.hunt)
  $tip.SetToolTip($lAd, ('채팅 획득 메시지 합계: {0:N0}' -f $S.chatTot) + "`n" + ('화면 아데나 증가분: {0:N0}' -f $S.ocrTot) + "`n두 값을 서로 확인해서 맞는 쪽을 표시")
  $lDps.Text = Dps-Text; $lTaken.Text = Taken-Text
  $lLootHead.Text = $(if ($Loots.Count) { '대박기원: ' + $Loots.Count + '개' } elseif (-not $ocrEn) { '대박기원: (영문 OCR 미설치 - 이름이 틀릴 수 있음)' } else { '대박기원: (아직 없음)' })
  if ($Loots.Count -ne $LootShownN -or ($Loots.Count -and $lbLoot.Items.Count -and $lbLoot.Items[0] -ne $Loots[0])) {
    $script:LootShownN = $Loots.Count
    $lbLoot.BeginUpdate(); $lbLoot.Items.Clear(); foreach ($li in $Loots) { [void]$lbLoot.Items.Add($li) }; $lbLoot.EndUpdate()
  }
  $tip.SetToolTip($lDps, "마지막 피해 줄: $($DP.chatDbg)`n총 피해 $('{0:N0}' -f $DP.dmg) / 타격 $($DP.hits)회 / 전투 시간 $([int]$DP.fight)초")
  $who = if ($S.name) { Fix-NameCase $S.name } else { '사냥 지표' }
  $state = if ($S.running) { if ($CapMode -eq '다른 창 보는 중(대기)' -or $CapMode -eq '창 전환 대기') { '대기중' } else { '측정중' } } else { '정지' }
  $lTitle.Text = $(if ($S.name) { "사냥지표 · $who ($state)" } else { "사냥지표 ($state)" })
  $tip.SetToolTip($lTitle, "상태: $CapMode`n경험치 줄: $($S.dbg)`n아데나 영역 글자: $($S.adDbg)`n기준 경험치: $($S.last)%  기준 아데나: $($S.aLast)")
  $tip.SetToolTip($lAd, "아데나 영역 글자: $($S.adDbg)`n(더블클릭: 아데나 숫자 다시 고르기)")
}

function Start-Measure {
  Refresh-GamePids
  $h = $LastGame
  if (-not (Is-GameWin $h) -or -not [LU4W]::IsWindow($h)) {
    [System.Windows.Forms.MessageBox]::Show('게임 창을 한 번 클릭해서 앞에 띄운 뒤 다시 시작을 눌러 주세요.', 'LU4 사냥 지표') | Out-Null; return $false
  }
  $script:Hwnd = $h
  # 게임 창을 앞으로 가져와 이름/경험치 위치 확인
  $procId = [uint32]0; [void][LU4W]::GetWindowThreadProcessId($h, [ref]$procId)
  try { [Microsoft.VisualBasic.Interaction]::AppActivate([int]$procId) } catch {}
  Start-Sleep -Milliseconds 800
  $script:FgSince = [DateTime]::Now.AddSeconds(-5)
  $nmLines = Ocr-Lines (Grab-Zone $h $ZoneName) $ocrEn; $S.name = Find-Name; $S.nameManual = $false; $S.aliasKey = ''; $NameVotes.Clear(); $CaseVotes.Clear()
  $S.nameFromStatus = $false
  if ($S.name -and ($S.name -cmatch '[A-Za-z]')) {
    # 좌측 위 상태창(큰 글씨)에서 영문으로 읽은 표기를 가장 믿을 만한 것으로 보고 저장
    $S.nameFromStatus = $true
  }
  try { Add-Content -Path $ErrLog -Encoding UTF8 -Value ("[{0}] 시작: 상태창 이름 읽음='{1}' -> {2}" -f (Get-Date).ToString('HH:mm:ss'), ($nmLines -join ' | '), $S.name) } catch {}
  # 경험치 %는 최대 3번까지 다시 읽어 보고, 그래도 없으면 알림 없이 측정을 시작하며 계속 찾음
  $e = $null; $expTxt = ''
  for ($try = 0; $try -lt 3 -and $e -eq $null; $try++) {
    $le0 = Ocr-Lines (Grab-Zone $h $ZoneExp); $expTxt = ($le0 -join ' | '); $e = Find-Exp $le0
    if ($e -eq $null) { Start-Sleep -Milliseconds 400 }
  }
  if ($e -eq $null) {
    $S.dbg = "(시작 시 경험치 못 찾음) $expTxt"
    try { Add-Content -Path $ErrLog -Encoding UTF8 -Value ("[{0}] 시작: 하단 좌측에서 경험치 %를 못 찾음. 상태={1} 읽은 글자='{2}'" -f (Get-Date).ToString('HH:mm:ss'), $CapMode, $expTxt) } catch {}
  }
  # 아데나 위치: 저장된 위치에 숫자가 있으면 그대로, 없으면 새로 고르기
  [void](Ocr-Lines (Grab-Zone $h $ZoneAdena))
  if (-not $AdPos -or (Find-Adena) -eq $null) {
    $p = Pick-AdenaPos
    if ($p) { $script:AdPos = $p; Save-Cfg }
    try { [Microsoft.VisualBasic.Interaction]::AppActivate([int]$procId) } catch {}
  }
  Reset-All; Reset-Dps; $S.adSeen = $false; $S.adChat = $false; $S.asked = $false
  return $true
}

$bStart.Add_Click({ try {
  if (-not $S.running) { if (Start-Measure) { $S.running = $true } }
  else { $S.running = $false }
  $bStart.Text = if ($S.running) { '중지' } else { '시작' }; Refresh-UI } catch { Log-Err 'Start' $_; [System.Windows.Forms.MessageBox]::Show("오류: $($_.Exception.Message)", 'LU4 사냥 지표') | Out-Null } })
$bReset.Add_Click({ Reset-All; Reset-Dps; Refresh-UI })
# 경험치초기화: 경험치/시간당 경험치/사냥 시간을 0부터, 시간당 아데나도 다시 계산 (총 아데나, DPS, 대박기원은 그대로)
$bExpReset.Add_Click({
  $S.gains.Clear(); $S.totExp = 0.0; $S.hunt = 0.0; Reset-Seg   # 시간당 아데나도 여기서부터 다시 계산(총 아데나는 유지)
  $S.last = $null; $S.pend = $null; $S.pendN = 0; $S.lastGain = $null
  Refresh-UI
})
# 파티원 완제품 줄을 더블클릭하면 알림음 미리 듣기
$lLoot[0].Add_DoubleClick({ Play-Alert })
$li0 = 0; if ($cfg.sndFile) { for ($q = 0; $q -lt $LootSnd.Count; $q++) { if ((Split-Path $LootSnd[$q] -Leaf) -eq $cfg.sndFile) { $li0 = $q } } }
Load-LootSnd $li0
$tip.SetToolTip($lLoot[0], '더블클릭: 소리 미리 듣기 · 오른쪽 클릭: 소리 바꾸기')
$lLoot[0].Add_MouseUp({
  if ($_.Button -eq 'Right') {
    Load-LootSnd ($LootIdx + 1); $cfg.sndFile = $(if ($LootSnd.Count) { Split-Path $LootSnd[$LootIdx] -Leaf } else { '' })
    Play-Alert; Save-Cfg
    $lLootHead.Text = '대박기원 알림음: ' + [IO.Path]::GetFileNameWithoutExtension($cfg.sndFile)
  }
})
function Ask-Text($msg, $def) {
  # 사냥 지표 창(항상 위) 뒤에 숨지 않도록 직접 만든 입력 창
  $f = New-Object System.Windows.Forms.Form
  $f.Text = 'LU4 사냥 지표'; $f.Size = '340,150'; $f.StartPosition = 'CenterScreen'; $f.TopMost = $true; $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.MinimizeBox = $false
  $lb = New-Object System.Windows.Forms.Label; $lb.Text = $msg; $lb.Location = '12,10'; $lb.Size = '310,20'; $f.Controls.Add($lb)
  $tb = New-Object System.Windows.Forms.TextBox; $tb.Text = "$def"; $tb.Location = '12,36'; $tb.Size = '300,24'; $tb.Font = $font; $f.Controls.Add($tb)
  $ok = New-Object System.Windows.Forms.Button; $ok.Text = '확인'; $ok.Location = '120,72'; $ok.Size = '90,28'; $ok.DialogResult = 'OK'; $f.Controls.Add($ok); $f.AcceptButton = $ok
  $f.Add_Shown({ $f.Activate(); $tb.Focus(); $tb.SelectAll() })
  if ($f.ShowDialog($form) -eq 'OK') { return $tb.Text }
  return $null
}
# 제목(캐릭터 이름)을 더블클릭하거나 오른쪽 클릭하면 직접 입력
$EditName = {
  $v = Ask-Text '표시할 캐릭터 이름을 입력해 주세요. (대소문자 그대로)' (Fix-NameCase $S.name)
  if ($v -ne $null -and $v.Trim()) {
    $oldKey = Name-Key $S.name
    $S.name = $v.Trim(); $S.nameManual = $true
    # 채팅에서 다르게 읽히던 내 이름(예: 기C)도 계속 내 피해로 셈
    if ($oldKey -and $oldKey -ne (Name-Key $S.name)) { $S.aliasKey = $oldKey }
    $script:SavedNames = @($SavedNames | Where-Object { (Name-Key $_) -ne (Name-Key $S.name) }) + $S.name
    Save-Cfg; Refresh-UI } }
$lTitle.Add_DoubleClick($EditName)
$lTitle.Add_MouseUp({ if ($_.Button -eq 'Right') { & $EditName } })
# 아데나 줄을 더블클릭하면 아데나 숫자 위치를 다시 고름
$lAd.Add_DoubleClick({ $script:AdPos = $null; $S.asked = $false; Save-Cfg; [System.Windows.Forms.MessageBox]::Show('잠시 뒤 아데나 숫자를 다시 고를 수 있어요. (게임 창을 앞에 두세요)', 'LU4 사냥 지표') | Out-Null })
$bClose.Add_Click({ $form.Close() })

# 창 끌어서 이동
$drag = @{ on = $false; p = $null }
$moveDown = { $drag.on = $true; $drag.p = [System.Windows.Forms.Cursor]::Position }
$moveMove = { if ($drag.on) { $c = [System.Windows.Forms.Cursor]::Position; $form.Left += $c.X - $drag.p.X; $form.Top += $c.Y - $drag.p.Y; $drag.p = $c } }
$moveUp   = { $drag.on = $false; $cfg.x = $form.Left; $cfg.y = $form.Top; Save-Cfg }
foreach ($c in (@($form, $lTitle, $lExp, $lAd, $lHunt, $lDps, $lTaken) + $lLoot)) { $c.Add_MouseDown($moveDown); $c.Add_MouseMove($moveMove); $c.Add_MouseUp($moveUp) }

Refresh-GamePids
$timer = New-Object System.Windows.Forms.Timer; $timer.Interval = $Interval
$Busy = @{ on = $false }
$timer.Add_Tick({ if ($Busy.on) { return }; $Busy.on = $true; try { Tick; Refresh-UI } catch { Log-Err 'Tick' $_; $S.dbg = "오류: $($_.Exception.Message)" } finally { $Busy.on = $false } })
$timer.Start()
$ctimer = New-Object System.Windows.Forms.Timer; $ctimer.Interval = $ChatMs
$ctimer.Add_Tick({ if ($Busy.on) { return }; $Busy.on = $true; try { Chat-Tick } catch { Log-Err 'Chat' $_; $DP.chatDbg = "오류: $($_.Exception.Message)" } finally { $Busy.on = $false } })
$ctimer.Start()
# 가로선과 경험치 줄 사이를 조금 띄움: 경험치 줄부터 아래를 4칸 내림
foreach ($cc in @($form.Controls)) { if ($cc.Top -ge 30) { $cc.Top += 4 } }; $form.Height += 4
Refresh-UI
# 실행할 때 새 업데이트가 있는지 확인해서 알려 줌 (GitHub의 버전 번호와 비교, 3초 안에 답이 없으면 그냥 넘어감)
$UpdChk = New-Object System.Windows.Forms.Timer; $UpdChk.Interval = 4000
$UpdChk.Add_Tick({
  $UpdChk.Stop()
  try {
    $vf = Join-Path $PSScriptRoot 'version.txt'
    $lv = $(if (Test-Path $vf) { ([string](Get-Content $vf -Encoding UTF8 | Select-Object -First 1)).Trim() } else { '' })
    if ($lv -notmatch '^\d{8}\.\d{4}$') { return }
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $rq = [System.Net.HttpWebRequest]::Create('https://raw.githubusercontent.com/qsejinp/LU4-Tools/main/LU4_GrindMeter_version.txt?t=' + [DateTime]::UtcNow.Ticks)
    $rq.Timeout = 3000; $rq.ReadWriteTimeout = 3000; $rq.UserAgent = 'LU4-Updater'
    $rs = $rq.GetResponse(); $sr = New-Object System.IO.StreamReader($rs.GetResponseStream()); $rv = $sr.ReadToEnd(); $sr.Close(); $rs.Close()
    $rv = ($rv -split "`n")[0].Trim()
    if ($rv -match '^\d{8}\.\d{4}$' -and [decimal]$rv -gt [decimal]$lv) {
      $fmt = { param($v) $v.Substring(4, 2) + '/' + $v.Substring(6, 2) + ' ' + $v.Substring(9, 2) + ':' + $v.Substring(11, 2) }
      $a = [System.Windows.Forms.MessageBox]::Show(("업데이트가 있습니다. 업데이트하세요.`n`n확인: 지금 업데이트 (내 설정은 그대로)`n취소: 나중에`n`n(지금 " + (& $fmt $lv) + "  →  최신 " + (& $fmt $rv) + ")"), '업데이트 알림', 'OKCancel', 'Information')
      if ($a -eq 'OK') { Start-Update -NoAsk }
    }
  } catch {}
})
$UpdChk.Start()
[void]$form.ShowDialog()
$timer.Stop(); $ctimer.Stop()
