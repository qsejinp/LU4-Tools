﻿# made by DoZ
# LU4 한글패치 설치: C:\LU4_Tools\LU4_KoreanPatch 에 복사, 바탕화면/시작 메뉴 바로가기, 윈도우 시작 때 자동 실행 등록
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$src = $PSScriptRoot; $prog = 'LU4_KoreanPatch'; $title = 'LU4 한글패치'
# 방송용 설치파일이면 '방송용' 아이콘을 따로 만듦 (일반 아이콘이 이미 있으면 그대로 둠)
$isBc = Test-Path (Join-Path $PSScriptRoot 'channel_bc.txt')
$ititle = $(if ($isBc) { 'LU4 한글패치(방송용)' } else { $title }); $runv = $(if ($isBc) { '_run_bc.vbs' } else { '_run.vbs' }); $icoName = $(if ($isBc) { '_bc.ico' } else { '.ico' })
function Msg($t, $b = 'OK', $i = 'Information') { return [System.Windows.Forms.MessageBox]::Show($t, 'LU4 설치 (made by DoZ)', $b, $i) }
if (-not (Test-Path (Join-Path $src ($prog + '.ps1')))) { Msg '이 폴더에서 프로그램을 찾지 못했어요. 압축을 푼 폴더 안의 설치.bat 을 실행해 주세요.' 'OK' 'Warning' | Out-Null; exit }
$dst = Join-Path 'C:\LU4_Tools' $prog
if ((Msg ("$ititle 을(를) 설치할까요?`n`n설치 위치: $dst`n바탕화면에 '$ititle' 아이콘이 만들어져요.`n`n· 아이콘을 누르면 한글패치를 확인해서 없으면 넣고, 게임 런처를 켜요.") 'YesNo' 'Question') -ne 'Yes') { exit }
try {
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like ('*' + $prog + '.ps1*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}
try {
  New-Item -ItemType Directory -Path $dst -Force | Out-Null
  if ((Resolve-Path $src).Path.TrimEnd('\') -ne (Resolve-Path $dst).Path.TrimEnd('\')) {
    foreach ($f in Get-ChildItem -Path $src -File -Force) { $to = Join-Path $dst $f.Name; if (Test-Path $to) { try { (Get-Item $to -Force).Attributes = 'Normal' } catch {} }; Copy-Item $f.FullName $to -Force }
  }
  $vis = @('제거.bat', '사용법.txt')
  try { Get-ChildItem -Path $dst -File -Force | ForEach-Object { if ($vis -contains $_.Name) { $_.Attributes = 'Normal' } else { $_.Attributes = ($_.Attributes -bor [System.IO.FileAttributes]::Hidden) } } } catch {}
  # 패치 종류 표시: 방송용 설치파일이면 bc 로 시작 (그 뒤로는 마지막에 누른 아이콘을 따라감)
  try {
    $dd = Join-Path $env:LOCALAPPDATA 'LU4_Tools'; if (-not (Test-Path $dd)) { New-Item -ItemType Directory -Path $dd -Force | Out-Null }
    $pcf = Join-Path $dd 'patch_channel.txt'
    if ($isBc) { [System.IO.File]::WriteAllText($pcf, 'bc') }
  } catch {}
  $sh = New-Object -ComObject WScript.Shell
  $ws = Join-Path $env:WINDIR 'System32\wscript.exe'; $ico = Join-Path $dst ($prog + '.ico')
  $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'LU4 Tools'; New-Item -ItemType Directory -Path $menu -Force | Out-Null
  $desks = New-Object System.Collections.ArrayList
  $rd = [Environment]::GetFolderPath('Desktop'); if ($rd -and (Test-Path $rd)) { [void]$desks.Add($rd) }
  try { Get-ChildItem $env:USERPROFILE -Directory -Recurse -Depth 2 -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'Desktop' -or $_.Name -eq '바탕 화면' } | ForEach-Object { if (-not $desks.Contains($_.FullName)) { [void]$desks.Add($_.FullName) } } } catch {}
  if ($desks.Count -eq 0) { [void]$desks.Add((Join-Path $env:USERPROFILE 'Desktop')) }
  $targets = @(); foreach ($dk in $desks) { $targets += (Join-Path $dk ($ititle + '.lnk')) }; $targets += (Join-Path $menu ($ititle + '.lnk'))
  $ico2 = Join-Path $dst ($prog + $icoName); if (-not (Test-Path $ico2)) { $ico2 = $ico }
  foreach ($lnkPath in $targets) {
    $l = $sh.CreateShortcut($lnkPath); $l.TargetPath = $ws; $l.Arguments = '"' + (Join-Path $dst ($prog + $runv)) + '"'; $l.WorkingDirectory = $dst
    if (Test-Path $ico2) { $l.IconLocation = $ico2 + ',0' }; $l.Description = $ititle + ' (made by DoZ)'; $l.Save()
  }
  # 윈도우 시작 때 자동 실행(시작프로그램 폴더의 바로가기)
  $st = $sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) ($title + ' (자동 실행).lnk')))
  $st.TargetPath = $ws; $st.Arguments = '"' + (Join-Path $dst ($prog + '_watch.vbs')) + '"'; $st.WorkingDirectory = $dst; if (Test-Path $ico) { $st.IconLocation = $ico + ',0' }; $st.Save()
  $u = $sh.CreateShortcut((Join-Path $menu ($title + ' 제거.lnk'))); $u.TargetPath = Join-Path $dst '제거.bat'; $u.WorkingDirectory = $dst; $u.Save()
} catch { Msg ('설치 중 문제가 생겼어요: ' + $_.Exception.Message) 'OK' 'Error' | Out-Null; exit }
if ((Msg ("설치 완료!`n`n바탕화면의 '$ititle' 아이콘을 누르면 한글패치를 확인하고 게임 런처를 켜요.`n`n지금 실행할까요?") 'YesNo' 'Information') -eq 'Yes') {
  Start-Process -FilePath $ws -ArgumentList ('"' + (Join-Path $dst ($prog + $runv)) + '"') -WorkingDirectory $dst
} else { Start-Process -FilePath $ws -ArgumentList ('"' + (Join-Path $dst ($prog + '_watch.vbs')) + '"') -WorkingDirectory $dst }
