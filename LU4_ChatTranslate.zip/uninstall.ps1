﻿# made by DoZ
# LU4 제거: 바로가기와 설치 폴더를 지움
Add-Type -AssemblyName System.Windows.Forms
$here = $PSScriptRoot
$prog = $(if (Test-Path (Join-Path $here 'LU4_ChatTranslate.ps1')) { 'LU4_ChatTranslate' } elseif (Test-Path (Join-Path $here 'LU4_GrindMeter.ps1')) { 'LU4_GrindMeter' } else { '' })
if (-not $prog) { exit }
$title = @{ LU4_ChatTranslate = 'LU4 채팅 번역'; LU4_GrindMeter = 'LU4 사냥지표' }[$prog]
if ([System.Windows.Forms.MessageBox]::Show("$title 을(를) 지울까요?`n바탕화면 아이콘과 이 폴더(설정, DeepL 키 포함)가 모두 지워져요.`n`n$here", 'LU4 제거', 'YesNo', 'Warning') -ne 'Yes') { exit }
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like ('*' + $prog + '.ps1*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$desk = [Environment]::GetFolderPath('Desktop'); $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'LU4 Tools'
foreach ($p in @((Join-Path $desk ($title + '.lnk')), (Join-Path $menu ($title + '.lnk')), (Join-Path $menu ($title + ' 제거.lnk')), (Join-Path $menu ($title + ' 폴더 열기.lnk')))) { Remove-Item $p -Force -ErrorAction SilentlyContinue }
if ((Test-Path $menu) -and -not (Get-ChildItem $menu -ErrorAction SilentlyContinue)) { Remove-Item $menu -Force -ErrorAction SilentlyContinue }
[System.Windows.Forms.MessageBox]::Show("$title 을(를) 지웠어요.", 'LU4 제거') | Out-Null
# 이 스크립트가 폴더 안에 있으므로, 끝난 뒤 잠시 기다렸다가 폴더를 지움
Start-Process cmd -WindowStyle Hidden -WorkingDirectory $env:TEMP -ArgumentList ('/c timeout /t 2 /nobreak >nul & rmdir /s /q "' + $here + '"')
