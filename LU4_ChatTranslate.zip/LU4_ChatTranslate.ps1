﻿# made by DoZ
# LU4 채팅 실시간 번역 (외부 프로그램) - 게임 파일/메모리는 건드리지 않고 화면 글자만 읽습니다.
# 좌측 아래 채팅창에서 "이름: 내용" 줄을 읽어 한국어가 아니면 번역해서 작은 창에 보여 줍니다.
# 실행: LU4_ChatTranslate_run.bat
$ErrorActionPreference = 'Stop'
# 검은 콘솔 창 숨기기(창 없이 실행)
try { Add-Type -Name ConWin -Namespace LU4H -MemberDefinition '[DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int n);'; $cw = [LU4H.ConWin]::GetConsoleWindow(); if ($cw -ne [System.IntPtr]::Zero) { [void][LU4H.ConWin]::ShowWindow($cw, 0) } } catch {}
try { Add-Type -Name Key -Namespace LU4K -MemberDefinition '[DllImport("user32.dll")] public static extern short GetAsyncKeyState(int k);' } catch {}
Add-Type -AssemblyName System.Windows.Forms, System.Drawing, System.Runtime.WindowsRuntime
Add-Type @"
using System; using System.Runtime.InteropServices;
public static class LU4T {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L; public int T; public int R; public int B; }
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool SetWindowDisplayAffinity(IntPtr h, uint a);
  [DllImport("user32.dll")] public static extern bool ReleaseCapture();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int m, int w, int l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "SendMessageW")] public static extern IntPtr SendMessageStr(IntPtr h, int m, IntPtr w, string l);
}
"@
[void][LU4T]::SetProcessDPIAware()
# ---------- 글꼴: 한글 패치에 쓴 Pretendard (폴더에 있으면 사용, 없으면 맑은 고딕) ----------
Add-Type -Namespace LU4F -Name G -MemberDefinition '[DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern int AddFontResourceEx(string f, uint fl, IntPtr r);'
$PFC = New-Object System.Drawing.Text.PrivateFontCollection
$FamReg = $null; $FamBold = $null
foreach ($fp in @('Pretendard-SemiBold.ttf', 'Pretendard-Bold.ttf')) {
  $full = Join-Path $PSScriptRoot $fp
  if (Test-Path $full) { try { [void][LU4F.G]::AddFontResourceEx($full, 0x10, [IntPtr]::Zero); $PFC.AddFontFile($full) } catch {} }
}
foreach ($ff in $PFC.Families) { if ($ff.Name -eq 'Pretendard SemiBold') { $FamReg = $ff } elseif ($ff.Name -eq 'Pretendard') { $FamBold = $ff } }
if (-not $FamBold) { $FamBold = $FamReg }; if (-not $FamReg) { $FamReg = $FamBold }
function UIFont($size, [switch]$bold) {
  if ($bold -and $FamBold) { return New-Object System.Drawing.Font($FamBold, [single]$size, [System.Drawing.FontStyle]::Bold) }
  if ($FamReg) { return New-Object System.Drawing.Font($FamReg, [single]$size) }
  if ($bold) { return New-Object System.Drawing.Font('Malgun Gothic', [single]$size, [System.Drawing.FontStyle]::Bold) }
  return New-Object System.Drawing.Font('Malgun Gothic', [single]$size)
}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ---------- 설정 ----------
$ZoneChat = @(0.00, 0.58, 0.30, 0.385)   # 좌측 아래 채팅창 전체(게임 화면 비율: 왼쪽, 위, 너비, 높이)
$TickMs   = 600      # 채팅 읽기 간격(ms)
$ShowN    = 7        # 번역 창에 보여 줄 줄 수
$Target   = 'ko'     # 번역할 언어
$CfgPath  = Join-Path $PSScriptRoot 'LU4_ChatTranslate_cfg.json'
$ErrLog   = Join-Path $PSScriptRoot 'LU4_ChatTranslate_error.log'
function Log-Err($where, $err) {
  try { Add-Content -Path $ErrLog -Encoding UTF8 -Value ("[{0}] {1}: {2} (줄 {3})" -f (Get-Date).ToString('HH:mm:ss'), $where, $err.Exception.Message, $err.InvocationInfo.ScriptLineNumber) } catch {}
}

# ---------- Windows 내장 OCR ----------
[void][Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
$asTaskG = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$t) { $task = $asTaskG.MakeGenericMethod($t).Invoke($null, @($op)); [void]$task.Wait(-1); $task.Result }
function New-Eng($tag) { try { return [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new($tag)) } catch { return $null } }
# 설치된 OCR 언어 중에서 고름 (en-US가 없으면 en-GB 등 다른 영어도 사용)
$OcrLangs = @(); try { foreach ($lg in [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) { $OcrLangs += $lg.LanguageTag } } catch {}
function Pick-Eng($prefix, $pref) {
  $e = New-Eng $pref; if ($e) { return $e }
  foreach ($tg in $OcrLangs) { if ($tg -like ($prefix + '*')) { $e = New-Eng $tg; if ($e) { return $e } } }
  return $null
}
$ocrKo = Pick-Eng 'ko' 'ko-KR'
$ocrEn = Pick-Eng 'en' 'en-US'
$ocrRu = Pick-Eng 'ru' 'ru-RU'
$HasEn = [bool]$ocrEn; $HasRu = [bool]$ocrRu
if (-not $ocrKo) { $ocrKo = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if (-not $ocrEn) { $ocrEn = $ocrKo }
$DbgLog = Join-Path $PSScriptRoot 'LU4_ChatTranslate_debug.log'
$DbgN = 0
function Dbg($m) {
  try {
    $script:DbgN++
    # 기록 파일이 2MB를 넘으면 지우고 새로 시작
    if ($DbgN % 200 -eq 0 -and (Test-Path $DbgLog) -and (Get-Item $DbgLog).Length -gt 2MB) { Remove-Item $DbgLog -ErrorAction SilentlyContinue }
    Add-Content -Path $DbgLog -Encoding UTF8 -Value ('[{0}] {1}' -f (Get-Date).ToString('HH:mm:ss'), $m)
  } catch {}
}
try { if ((Test-Path $DbgLog) -and (Get-Item $DbgLog).Length -gt 1MB) { Remove-Item $DbgLog } } catch {}
Dbg ('시작. 설치된 OCR 언어: ' + ($OcrLangs -join ', ') + ' / 영어=' + $HasEn + ' 러시아어=' + $HasRu)

# 그림을 키워서 OCR. 줄마다 글자와 위치(그림 안 비율)를 돌려줌
function Ocr-Bmp($bmp, $eng, $maxPx = 2400) {
  $max = [Math]::Max($bmp.Width, $bmp.Height)
  $scale = [Math]::Max(1.0, [Math]::Min(4.0, $maxPx / $max))
  $big = New-Object System.Drawing.Bitmap ([int]($bmp.Width * $scale)), ([int]($bmp.Height * $scale))
  $g = [System.Drawing.Graphics]::FromImage($big); $g.InterpolationMode = 'HighQualityBicubic'
  $g.DrawImage($bmp, 0, 0, $big.Width, $big.Height); $g.Dispose()
  $ms = New-Object System.IO.MemoryStream; $big.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $big.Dispose(); $ms.Position = 0
  $ras = [System.IO.WindowsRuntimeStreamExtensions]::AsRandomAccessStream($ms)
  $dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ras)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $sb  = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $res = Await ($eng.RecognizeAsync($sb)) ([Windows.Media.Ocr.OcrResult])
  $ms.Dispose()
  $imgW = [double]$sb.PixelWidth; $imgH = [double]$sb.PixelHeight
  $out = @()
  foreach ($ln in $res.Lines) {
    $x0 = 1e9; $y0 = 1e9; $x1 = 0; $y1 = 0
    $wl = @()
    foreach ($wd in $ln.Words) { $br = $wd.BoundingRect; $x0 = [Math]::Min($x0, $br.X); $y0 = [Math]::Min($y0, $br.Y); $x1 = [Math]::Max($x1, $br.X + $br.Width); $y1 = [Math]::Max($y1, $br.Y + $br.Height)
      $wl += [pscustomobject]@{ t = $wd.Text; x0 = $br.X / $imgW; x1 = ($br.X + $br.Width) / $imgW } }
    $out += [pscustomobject]@{ Text = $ln.Text; X0 = $x0 / $imgW; Y0 = $y0 / $imgH; X1 = $x1 / $imgW; Y1 = $y1 / $imgH; Words = $wl }
  }
  return $out
}
# 한 줄만 잘라(여백을 배경색으로 채워) 다시 읽기
function Ocr-LineCrop($img, $ln, $eng) {
  $iw = $img.Width; $ih = $img.Height
  $x0 = [Math]::Max(0, [int]($ln.X0 * $iw) - 3); $y0 = [Math]::Max(0, [int]($ln.Y0 * $ih) - 4)
  $x1 = [Math]::Min($iw, [int]($iw * $ChatRight)); $y1 = [Math]::Min($ih, [int]($ln.Y1 * $ih) + 4)
  if ($x1 - $x0 -lt 8 -or $y1 - $y0 -lt 6) { return '' }
  $crop = $img.Clone((New-Object System.Drawing.Rectangle $x0, $y0, ($x1 - $x0), ($y1 - $y0)), $img.PixelFormat)
  $pad = 12
  $bg = $crop.GetPixel(0, 0)
  $pb = New-Object System.Drawing.Bitmap ($crop.Width + $pad * 2), ($crop.Height + $pad * 2)
  $g = [System.Drawing.Graphics]::FromImage($pb); $g.Clear($bg); $g.DrawImage($crop, $pad, $pad); $g.Dispose(); $crop.Dispose()
  $pbW = $pb.Width
  $r = Ocr-Bmp $pb $eng; $pb.Dispose()
  # 단어 위치를 채팅창 그림 기준 비율로 기록(글자 색 읽기용)
  $cw = @(); foreach ($rl in $r) { foreach ($w in $rl.Words) { $cw += [pscustomobject]@{ t = $w.t; x0 = ($x0 + $w.x0 * $pbW - $pad) / $iw; x1 = ($x0 + $w.x1 * $pbW - $pad) / $iw } } }
  $script:CropWords = $cw
  return (($r | ForEach-Object { $_.Text }) -join ' ')
}

# ---------- 게임 창 ----------
function Is-GameWin($h) {
  if ($h -eq [IntPtr]::Zero) { return $false }
  $procId = [uint32]0; [void][LU4T]::GetWindowThreadProcessId($h, [ref]$procId)
  try { return ((Get-Process -Id $procId -ErrorAction Stop).ProcessName -like 'lu4*') } catch { return $false }
}
$FgWin = [IntPtr]::Zero; $LastGameWin = [IntPtr]::Zero; $FgSince = $null; $State = '대기중'
function Grab-Chat {
  $h = [LU4T]::GetForegroundWindow()
  if (-not (Is-GameWin $h) -or [LU4T]::IsIconic($h)) { $script:FgWin = [IntPtr]::Zero; $script:State = '대기중'; return $null }
  # 창을 바꾼 직후에는 화면이 다 바뀌지 않았을 수 있어 1초 기다림
  $script:LastGameWin = $h
  if ($h -ne $FgWin) { $script:FgWin = $h; $script:FgSince = [DateTime]::Now; $script:State = '대기중'; return $null }
  if (([DateTime]::Now - $FgSince).TotalSeconds -lt 1) { return $null }
  $cr = New-Object LU4T+RECT; [void][LU4T]::GetClientRect($h, [ref]$cr)
  $p = New-Object LU4T+POINT; [void][LU4T]::ClientToScreen($h, [ref]$p)
  if ($cr.R -le 0 -or $cr.B -le 0) { return $null }
  $x = $p.X + [int]($cr.R * $ZoneChat[0]); $y = $p.Y + [int]($cr.B * $ZoneChat[1])
  $w = [int]($cr.R * $ZoneChat[2]); $hh = [int]($cr.B * $ZoneChat[3])
  $bmp = New-Object System.Drawing.Bitmap $w, $hh
  $g = [System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($x, $y, 0, 0, $bmp.Size)
  # 번역 창이 채팅창 위에 겹쳐 있으면 그 부분은 검게 지움(내 번역 글을 다시 읽지 않게)
  try {
    if ($form -and $form.Visible) {
      $fr = $form.Bounds; $fr.Offset(-$x, -$y)
      $fr.Intersect((New-Object System.Drawing.Rectangle 0, 0, $w, $hh))
      if ($fr.Width -gt 0 -and $fr.Height -gt 0) { $g.FillRectangle([System.Drawing.Brushes]::Black, $fr) }
    }
  } catch {}
  $g.Dispose()
  if (-not $TrFail -or ([DateTime]::Now - $TrFail).TotalSeconds -gt 30) { $script:State = '읽는 중' }
  return $bmp
}

# ---------- 게임 용어 (chat_glossary.txt: 한 줄에 "약어=한국어") ----------
$GlossPath = Join-Path $PSScriptRoot 'chat_glossary.txt'
if (-not (Test-Path $GlossPath)) {
  @('# 게임 용어 바꾸기: 한 줄에 "약어=한국어" (대소문자 구분 없음, 줄 맨 앞 #은 설명)',
    '# 같은 뜻의 약어가 여러 개면 줄을 따로 쓰세요. 고친 뒤 채팅 번역을 다시 켜면 적용됩니다.',
    'DD=딜러', 'Tank=탱커', 'Heal=힐러', 'Healer=힐러', 'Support=버퍼', 'BD=블댄', 'Bard=블댄',
    'SWS=소싱', 'PP=플핏', 'EE=엘더', 'SE=실엘', 'WC=워크', 'OL=오버로드',
    'Puller=풀러(몹 끌어오는 사람)', 'AOE=몰이 사냥', 'LFP=파티 구함', 'LFM=파티원 모집', 'LFG=파티 찾는 중',
    'RB=레이드 보스', 'EPIC=에픽 보스', 'WB=월드 보스', 'CC=커맨드 채널', 'WTS=[판매]', 'WTT=[교환]', 'WTB=[구매]') | Set-Content $GlossPath -Encoding UTF8
}
$Gloss = @()
$GlossMap = [ordered]@{}
# "약어=뜻"(대소문자 무시) / "약어==뜻"(대소문자 구분, 전부 대문자도 허용)
function Add-Gl($line) {
  $i = $line.IndexOf('='); if ($i -lt 1) { return }
  $k = $line.Substring(0, $i).Trim(); $rest = $line.Substring($i + 1)
  $cs = $rest.StartsWith('='); if ($cs) { $rest = $rest.Substring(1) }
  $v = $rest.Trim(); if (-not $k -or -not $v -or $k -eq 'x') { return }
  if ($cs) { $script:GlossMap['==' + $k] = $v } else { $script:GlossMap[$k.ToUpper()] = $v }
}
foreach ($d in @('DD=딜러', 'Tank=탱커', 'Heal=힐러', 'Healer=힐러', 'Support=버퍼', 'BD=블댄', 'Bard=블댄',
    'SWS=소싱', 'PP=플핏', 'EE=엘더', 'SE=실엘', 'WC=워크', 'OL=오버로드',
    'Puller=풀러(몹 끌어오는 사람)', 'AOE=몰이 사냥', 'LFP=파티 구함', 'LFM=파티원 모집', 'LFG=파티 찾는 중',
    'RB=레이드 보스', 'EPIC=에픽 보스', 'WB=월드 보스', 'CC=커맨드 채널', 'WTS=[판매]', 'WTT=[교환]', 'WTB=[구매]',
    'PM=귓말', 'ПМ=귓말', 'ЛС=귓말', 'дд=딜러', 'танк=탱커', 'хил=힐러', 'хилер=힐러', 'бд=블댄', 'свс=소싱', 'пп=플핏',
    'ее=엘더', 'се=실엘', 'вк=워크', 'овер=오버로드', 'кач=사냥', 'качаю=사냥 중', 'качаюсь=사냥 중', 'фарм=파밍',
    'пати=파티', 'пт=파티', 'кп=커맨드 채널', 'пк=PK', 'пкшить=PK하다', 'солью=넘길게', 'сольют=넘긴다', 'рб=레이드 보스', 'продам=[판매]', 'куплю=[구매]', 'обменяю=[교환]',
    # 사냥터: "약어==이름"은 대소문자 구분(영어 낱말과 헷갈리는 것: it, bs 등). 전부 대문자로 쓴 것도 인식
    'DV==용의 계곡', 'GC==거인들의 동굴', 'ToI==오만의 탑', 'Necro=네크로폴리스', 'CT==크루마 탑', 'Cruma=크루마 탑',
    'DI==악마의 섬', 'IT==상아탑', 'FP==망각의 평원', 'MoS==침묵의 수도원', 'FoD==망자의 숲', 'FoM==거울의 숲',
    'VoS==성자의 계곡', 'RoD==파괴된 성채', 'RoA==고통의 폐허', 'HV==사냥꾼의 마을', 'FT==잊혀진 신전', 'OB==오크 병영',
    'FG==사교의 신전', 'BS==화염의 늪', 'SoS==실렌의 봉인',
    'Dragon Valley=용의 계곡', 'Giants Cave=거인들의 동굴', "Giant's Cave=거인들의 동굴", 'Tower of Insolence=오만의 탑',
    'Necropolis=네크로폴리스', 'Cruma Tower=크루마 탑', "Devil's Isle=악마의 섬", 'Ivory Tower=상아탑',
    'Forsaken Plains=망각의 평원', 'Monastery of Silence=침묵의 수도원', 'Forest of the Dead=망자의 숲',
    'Forest of Mirrors=거울의 숲', 'Valley of Saints=성자의 계곡', "Pilgrim's Path=순례자의 길", 'Ruins of Despair=파괴된 성채',
    'Ruins of Agony=고통의 폐허', 'Hunters Village=사냥꾼의 마을', "Hunter's Village=사냥꾼의 마을", 'Forgotten Temple=잊혀진 신전',
    'Orc Barracks=오크 병영', 'Forbidden Gateway=사교의 신전', 'Blazing Swamp=화염의 늪', 'Seal of Shilen=실렌의 봉인',
    # 파티 모집: "DV AFK i MA" = 용계 잠수파티, 내가 메인 어시
    'I MA=내가 메인 어시', "I'm MA=내가 메인 어시", 'Im MA=내가 메인 어시', 'MA==메인 어시', 'AFK party=잠수파티', 'AFK pt=잠수파티', 'AFK=잠수',
    # 무기 특수 능력(SA, 게임 한글 번역 이름) / 거래 말
    'Your Offer=제안주세요', 'Offer PM=귓으로 제안주세요', 'PM Offer=귓으로 제안주세요', 'Offer=제안주세요', 'Empower=엠파워', 'Acumen=아큐멘', 'Mana Up=마나 업', 'Focus=포커스', 'Haste=헤이스트', 'Health=헬스', 'Guidance=가이던스', 'Critical Damage=크리티컬 대미지', 'Crt. Damage=크리티컬 대미지', 'Critical Bleed=크리티컬 블리드', 'Crt. Bleed=크리티컬 블리드', 'Critical Poison=크리티컬 포이즌', 'Crt. Poison=크리티컬 포이즌', 'Critical Stun=크리티컬 스턴', 'Crt. Stun=크리티컬 스턴', 'Critical Slow=크리티컬 슬로우', 'Crt. Slow=크리티컬 슬로우', 'Critical Drain=크리티컬 드레인', 'Crt. Drain=크리티컬 드레인', 'Critical Anger=크리티컬 앵거', 'Back Blow=백 블로우', 'Anger=앵거', 'Rsk. Focus=리스크 포커스', 'Risk Focus=리스크 포커스', 'Rsk. Haste=리스크 헤이스트', 'Risk Haste=리스크 헤이스트', 'Rsk. Evasion=리스크 이베이젼', 'Risk Evasion=리스크 이베이젼', 'Evasion=이베이젼', 'Mental Shield=멘탈 실드', 'Magic Hold=매직 홀드', 'Magic Paralyze=매직 패럴라이즈', 'Magic Poison=매직 포이즌', 'Magic Weakness=매직 위크니스', 'Magic Chaos=매직 카오스', 'Magic Silence=매직 사일런스', 'Magic Damage=매직 대미지', 'Magic Focus=매직 포커스', 'Magic Regeneration=매직 리제네레이션', 'Conversion=업다운', 'Cheap Shot=칩 샷', 'Quick Recovery=퀵 리커버리', 'Wide Blow=와이드 블로우', 'Long Blow=롱 블로우', 'Towering Blow=솟구치는 일격', 'HP Drain=HP 드레인', 'HP Regeneration=HP 리제네레이션', 'MP Regeneration=MP 리제네레이션', 'Mighty Mortal=마이트 모탈', 'Robust Health=로버스트 헬스', 'Special Ability=특수 능력',
    # 장비: MJ = 마제스틱 장비
    'MJ set=마제스틱 세트', 'MJ==마제스틱 장비', 'Majestic set=마제스틱 세트', 'Majestic=마제스틱',
    'MJ Unsealed=봉인 해제된 마제스틱', 'Unsealed MJ=봉인 해제된 마제스틱', 'MJ Sealed=봉인된 마제스틱', 'Sealed MJ=봉인된 마제스틱', 'Unsealed=봉인 해제된', 'Sealed=봉인된', 'Acu=아큐',
    'Dual SLS=싸울이도', 'SLS Dual=싸울이도', 'SLS=싸울', 'Gloves=장갑',
    'x=x')) { Add-Gl $d }
try {
  foreach ($gl in (Get-Content $GlossPath -Encoding UTF8)) {
    $gl = $gl.Trim(); if (-not $gl -or $gl.StartsWith('#') -or $gl.IndexOf('=') -lt 1) { continue }
    Add-Gl $gl
  }
} catch { Log-Err '용어 파일' $_ }
try {
  foreach ($gk in $GlossMap.Keys) {
    if ($gk.StartsWith('==')) {
      # 대소문자 구분: 적힌 그대로 또는 전부 대문자만
      $kk = $gk.Substring(2)
      $alts = @([regex]::Escape($kk)); if ($kk.ToUpper() -cne $kk) { $alts += [regex]::Escape($kk.ToUpper()) }
      $Gloss += [pscustomobject]@{ re = '(?<![A-Za-z0-9Ѐ-ӿ])(?:' + ($alts -join '|') + ')(?![A-Za-z0-9Ѐ-ӿ])'; v = $GlossMap[$gk]; n = $kk.Length }
      continue
    }
    # 짧은 영어 약어는 글자 사이 띄어쓰기도 허용(OCR이 "W TB"처럼 읽는 경우)
    if ($gk -cmatch '^[A-Z]{2,4}$') { $pat = (($gk.ToCharArray() | ForEach-Object { [regex]::Escape([string]$_) }) -join ' ?') } else { $pat = [regex]::Escape($gk) -replace '\\ ', '\s+' -replace "'", "['’]?" }
    $Gloss += [pscustomobject]@{ re = '(?i)(?<![A-Za-z0-9Ѐ-ӿ])' + $pat + '(s)?(?![A-Za-z0-9Ѐ-ӿ])'; v = $GlossMap[$gk]; n = $gk.Length } }
  $Gloss = @($Gloss | Sort-Object n -Descending)
} catch { Log-Err '용어 파일' $_ }
function Money-Ko($v) {
  if ($v -ge 100000000) { return ('{0:0.##}억' -f ($v / 100000000)) }
  if ($v -ge 10000) { return ('{0:0.##}만' -f ($v / 10000)) }
  return ('{0:0}' -f $v)
}
# 용어는 번역기에 보내기 전에 표시(QZ0Q 같은 기호)로 바꿔 두고, 번역이 끝난 뒤 한국어로 바꿈
# (먼저 한국어로 바꿔서 보내면 번역기가 글 전체를 한국어로 착각해서 번역하지 않음)
$PMap = @{}; $LinkKeys = @{}
# 아이템 이름(게임 한글 번역): items_ko.txt "영어<탭>한국어"
$Items = @{}; $ItemMaxW = 1
$ItemStop = @{ 'club' = 1; 'scythe' = 1; 'lance' = 1; 'shirt' = 1; 'pants' = 1; 'boots' = 1; 'gloves' = 1; 'knife' = 1; 'adena' = 1 }
function Item-Norm($t) { $t = $t.ToLower().Replace([string][char]0x2019, "'"); $t = [regex]::Replace($t, "'s\b", ''); $t = $t.Replace("'", ''); return ([regex]::Replace($t, '\s+', ' ')).Trim() }
try {
  $ip = Join-Path $PSScriptRoot 'items_ko.txt'
  if (Test-Path $ip) {
    foreach ($il in [System.IO.File]::ReadAllLines($ip, [System.Text.Encoding]::UTF8)) {
      if ($il.StartsWith('#')) { continue }
      $tb = $il.IndexOf("`t"); if ($tb -lt 1) { continue }
      $nk = Item-Norm $il.Substring(0, $tb)
      if ($nk.IndexOf(' ') -lt 0 -and ($nk.Length -lt 5 -or $ItemStop.ContainsKey($nk))) { continue }
      $Items[$nk] = $il.Substring($tb + 1).Trim()
      $wc2 = $nk.Split(' ').Count; if ($wc2 -gt $ItemMaxW) { $ItemMaxW = $wc2 }
    }
  }
} catch { Log-Err '아이템 파일' $_ }
Dbg ('아이템 이름 ' + $Items.Count + '개 불러옴')
function Protect-Items($t) {
  if ($Items.Count -eq 0) { return $t }
  $ms = @([regex]::Matches($t, "[A-Za-z][A-Za-z'’\*\-]*"))
  $out = New-Object System.Text.StringBuilder; $last = 0; $i = 0
  while ($i -lt $ms.Count) {
    $hit = $null
    for ($n = [Math]::Min($ItemMaxW, $ms.Count - $i); $n -ge 1; $n--) {
      $a = $ms[$i].Index; $e = $ms[$i + $n - 1].Index + $ms[$i + $n - 1].Length
      $seg = $t.Substring($a, $e - $a)
      if ($seg -match '[^A-Za-z\x27\u2019\*\- ]') { continue }
      $nk = Item-Norm $seg
      if ($Items.ContainsKey($nk)) { $hit = @($a, $e, $Items[$nk], $n); break }
    }
    if ($hit) { [void]$out.Append($t.Substring($last, $hit[0] - $last)).Append((Put-Tok $hit[2])); $last = $hit[1]; $i += $hit[3] } else { $i++ }
  }
  [void]$out.Append($t.Substring($last))
  return $out.ToString()
}
function Put-Tok($v) { $k = 'QZ' + $script:PMap.Count + 'Q'; $script:PMap[$k] = $v; return ' ' + $k + ' ' }
function Protect($t) {
  $script:PMap = @{}
  # 이미 한글인 부분(아이템 링크 등)은 그대로 둠
  $script:LinkKeys = @{}
  $t = [regex]::Replace($t, '[가-힣][가-힣0-9\*\+\-\(\)\[\] ]*[가-힣\)\]]|[가-힣]', { param($mm) $tk = Put-Tok $mm.Value.Trim(); $script:LinkKeys[$tk.Trim()] = 1; $tk })
  $t = Protect-Items $t
  # FAST / ASAP: 구매 글이면 급구, 판매 글이면 급매
  $fastW = $(if ($t -match '(?i)(?<![A-Za-z])(W ?T ?B|куплю)(?![A-Za-z])') { '급구' } elseif ($t -match '(?i)(?<![A-Za-z])(W ?T ?S|продам)(?![A-Za-z])') { '급매' } else { '급함' })
  $t = [regex]::Replace($t, '(?i)(?<![A-Za-z])(fast|asap|срочно)(?![A-Za-z])', { param($mm) Put-Tok $fastW })
  # "LF 무엇" -> "무엇 구함"
  $t = [regex]::Replace($t, '(?i)(?<![A-Za-z0-9])LF\s+([^\s,.!?]+)', { param($mm) $mm.Groups[1].Value + (Put-Tok '구함') })
  foreach ($g in $Gloss) { $gv = $g.v; $t = [regex]::Replace($t, $g.re, { param($mm) Put-Tok $gv }) }
  # 금액: 1.5kk / 1.5кк = 150만, 300k / 300к = 30만
  $t = [regex]::Replace($t, '(?i)(\d+(?:[.,]\d+)?)\s?(?:kk|кк)(?![A-Za-zЀ-ӿ])', { param($mm) Put-Tok (Money-Ko ([double]($mm.Groups[1].Value -replace ',', '.') * 1000000)) })
  $t = [regex]::Replace($t, '(?i)(\d+(?:[.,]\d+)?)\s?(?:k|к)(?![A-Za-zЀ-ӿ])', { param($mm) Put-Tok (Money-Ko ([double]($mm.Groups[1].Value -replace ',', '.') * 1000)) })
  return (($t -replace '\s{2,}', ' ').Trim())
}
# 번역 결과를 색 조각으로: 한글 링크 표시는 링크 색, 나머지는 기본 색
function Restore-Segs($t, $map, $links, $cBase, $cLink) {
  $segs = New-Object System.Collections.ArrayList
  $pos = 0
  foreach ($mm in [regex]::Matches($t, '(?i)Q\s?Z\s?(\d+)\s?Q')) {
    if ($mm.Index -gt $pos) { [void]$segs.Add([pscustomobject]@{ t = $t.Substring($pos, $mm.Index - $pos); c = $cBase }) }
    $key = 'QZ' + $mm.Groups[1].Value + 'Q'
    $val = $(if ($map.ContainsKey($key)) { [string]$map[$key] } else { $mm.Value })
    [void]$segs.Add([pscustomobject]@{ t = $val; c = $(if ($links.ContainsKey($key)) { $cLink } else { $cBase }) })
    $pos = $mm.Index + $mm.Length
  }
  if ($pos -lt $t.Length) { [void]$segs.Add([pscustomobject]@{ t = $t.Substring($pos); c = $cBase }) }
  return $segs
}
function Restore($t, $map) {
  foreach ($k in $map.Keys) {
    $n = $k.Substring(2, $k.Length - 3)
    $t = [regex]::Replace($t, '(?i)Q\s?Z\s?' + $n + '\s?Q', [string]$map[$k].Replace('$', '$$'))
  }
  return (($t -replace '\s{2,}', ' ').Trim())
}

# ---------- 번역 ----------
$TrCache = @{}
# deepl_key.txt 에 DeepL API 키가 있으면 DeepL(더 자연스러움), 없으면 구글 번역
$DeepLKey = ''
$DeepLPath = Join-Path $PSScriptRoot 'deepl_key.txt'
if (Test-Path $DeepLPath) { try { $DeepLKey = ((Get-Content $DeepLPath -Encoding UTF8) | Where-Object { $_.Trim() -and -not $_.Trim().StartsWith('#') } | Select-Object -First 1).Trim() } catch {} }
$Engine = if ($DeepLKey) { 'DeepL' } else { '구글' }
function Translate($text, $sl = 'auto', $tl = $Target) {
  $ck = $sl + '>' + $tl + '|' + $text
  if ($TrCache.ContainsKey($ck)) { return $TrCache[$ck] }
  $wc = New-Object System.Net.WebClient
  $wc.Encoding = [System.Text.Encoding]::UTF8
  $wc.Headers.Add('User-Agent', 'Mozilla/5.0')
  if ($DeepLKey) {
   try {
    $host2 = if ($DeepLKey.EndsWith(':fx')) { 'https://api-free.deepl.com' } else { 'https://api.deepl.com' }
    $wc.Headers.Add('Authorization', 'DeepL-Auth-Key ' + $DeepLKey)
    $wc.Headers.Add('Content-Type', 'application/x-www-form-urlencoded')
    $dtl = $(if ($tl -eq 'en') { 'EN-US' } elseif ($tl -eq 'zh') { 'ZH-HANS' } else { $tl.ToUpper() })
    $body = 'target_lang=' + $dtl + '&text=' + [Uri]::EscapeDataString($text)
    if ($sl -ne 'auto') { $body += '&source_lang=' + $sl.ToUpper() }
    $raw = $wc.UploadString($host2 + '/v2/translate', 'POST', $body); $wc.Dispose()
    $j = $raw | ConvertFrom-Json
    $r = @{ text = [string]$j.translations[0].text; lang = ([string]$j.translations[0].detected_source_language).ToLower() }
   } catch {
    # 한도 초과(456) / 키 오류(403) 등이면 이번 실행 동안은 구글 번역으로 계속
    $why = $_.Exception.Message
    Dbg ('DeepL 실패 -> 구글로 전환: ' + $why)
    $script:DeepLKey = ''
    $script:Engine = $(if ($why -match '456') { '구글 - DeepL 이번 달 한도 초과' } elseif ($why -match '403') { '구글 - DeepL 키 오류' } else { '구글 - DeepL 연결 실패' })
    return (Translate $text $sl $tl)
   }
  } else {
    $url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' + $sl + '&tl=' + $(if ($tl -eq 'zh') { 'zh-CN' } else { $tl }) + '&dt=t&q=' + [Uri]::EscapeDataString($text)
    $raw = $wc.DownloadString($url); $wc.Dispose()
    $j = $raw | ConvertFrom-Json
    $tr = (@($j[0]) | ForEach-Object { $_[0] }) -join ''
    $r = @{ text = $tr; lang = [string]$j[2] }
  }
  if ($TrCache.Count -gt 500) { $TrCache.Clear() }
  $TrCache[$ck] = $r
  return $r
}

# ---------- 채팅 줄 고르기 ----------
function Hangul-Ratio($t) {
  $l = ([regex]::Matches($t, '[A-Za-zЀ-ӿ가-힣]')).Count
  if ($l -eq 0) { return 0 }
  return ([regex]::Matches($t, '[가-힣ㄱ-ㆎ]')).Count / [double]$l
}
# "이름: 내용" (채널 기호 + # @ = 같은 것이 앞에 붙을 수 있음)
$ChatRe = '^(?:[^A-Za-z0-9가-힣]{0,4}|.{0,2}\s)([A-Za-z0-9_]{2,16})\s*[:;]\s*(.+)$'
# 줄 비교용 키: 글자 인식이 자주 헷갈리는 글자는 같은 글자로(q/g, 0/o, 1/i/l)
function Key-Of($t) { return ($t.ToLower() -replace 'q', 'g' -replace '0', 'o' -replace '[1il|!]', 'l' -replace '[^a-z0-9а-я]', '') }
function Dice($a, $b) {
  if ($a.Length -lt 2 -or $b.Length -lt 2) { return $(if ($a -eq $b) { 1.0 } else { 0.0 }) }
  $set = @{}; for ($i = 0; $i -lt $a.Length - 1; $i++) { $set[$a.Substring($i, 2)] = 1 }
  $n = 0; $tot = $b.Length - 1
  for ($i = 0; $i -lt $tot; $i++) { if ($set.ContainsKey($b.Substring($i, 2))) { $n++ } }
  return (2.0 * $n) / ($set.Count + $tot)
}
function Similar($a, $b) {
  # 같은 사람(앞 4글자 같음)의 같은 글이면 같은 줄. 이름은 빼고 "글 내용"만 비교
  if ($a -eq $b) { return $true }
  if ($a.Length -lt 4 -or $b.Length -lt 4) { return $false }
  if ($a.Substring(0, 4) -ne $b.Substring(0, 4)) { return $false }
  $p = 0; $mx = [Math]::Min($a.Length, $b.Length); while ($p -lt $mx -and $a[$p] -eq $b[$p]) { $p++ }
  $ra = $a.Substring($p); $rb = $b.Substring($p)
  if ($ra.Length -eq 0 -and $rb.Length -eq 0) { return $true }
  # 앞부분이 같아도 남은 내용이 거의 다르면 다른 글(예: "zzz" / "hello")
  $whole = Dice $a $b; $rest = Dice $ra $rb
  if ($ra.Length -lt 4 -or $rb.Length -lt 4) { return ($ra -eq $rb) }   # 끝 몇 글자만 다름(예: 시간 22:01/22:02)은 다른 줄
  return ($rest -ge 0.6) -or ($whole -ge 0.9)
}
$Seen = New-Object System.Collections.ArrayList   # 이미 처리한 줄(키)
$Shown = New-Object System.Collections.ArrayList  # 화면에 보여 줄 번역
function Was-Seen($k) { foreach ($s in $Seen) { if (Similar $s $k) { return $true } }; return $false }
function Mark-Seen($k) { [void]$Seen.Add($k); while ($Seen.Count -gt 80) { $Seen.RemoveAt(0) } }

# 채팅 줄의 글자 색 알아내기: 줄 안에서 배경보다 밝은 픽셀(글자)의 평균 색
# 그림 픽셀을 한 번에 배열로 읽기(빠름)
function Get-Px($img) {
  $rc = New-Object System.Drawing.Rectangle 0, 0, $img.Width, $img.Height
  $bd = $img.LockBits($rc, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $buf = New-Object byte[] ($bd.Stride * $img.Height)
  [System.Runtime.InteropServices.Marshal]::Copy($bd.Scan0, $buf, 0, $buf.Length)
  $img.UnlockBits($bd)
  return @{ b = $buf; s = $bd.Stride; w = $img.Width; h = $img.Height }
}
# 채팅 줄의 글자 색: 줄 안에서 가장 밝은 픽셀들(글자)의 평균 색
function Line-Color($px, $ln) { return (Color-Rect $px ($ln.X0 + ($ln.X1 - $ln.X0) * 0.3) $ln.X1 $ln.Y0 $ln.Y1) }
function Color-Rect($px, $fx0, $fx1, $fy0, $fy1) {
  $iw = $px.w; $ih = $px.h; $buf = $px.b; $st = $px.s
  $x0 = [Math]::Max(0, [int]($fx0 * $iw)); $x1 = [Math]::Min($iw - 1, [int]($fx1 * $iw))
  $y0 = [Math]::Max(0, [int]($fy0 * $ih)); $y1 = [Math]::Min($ih - 1, [int]($fy1 * $ih))
  $lum = New-Object System.Collections.Generic.List[int]
  $idx = New-Object System.Collections.Generic.List[int]
  for ($yy = $y0; $yy -le $y1; $yy += 2) { $row = $yy * $st
    for ($xx = $x0; $xx -le $x1; $xx += 2) { $o = $row + $xx * 4
      $lum.Add([int]($buf[$o + 2] * 3 + $buf[$o + 1] * 6 + $buf[$o])); $idx.Add($o) } }
  if ($lum.Count -lt 10) { return [System.Drawing.Color]::Gainsboro }
  $la = $lum.ToArray(); $ia = $idx.ToArray(); [Array]::Sort($la, $ia)
  # 밝은 픽셀(위 30%) 중 색이 진한 픽셀이 충분히 있으면 그게 글자 색(뒤 배경이 밝은 회색이어도 노란 글자를 찾음)
  $top30 = [Math]::Max(5, [int]($la.Length * 0.30))
  $sr = 0; $sg = 0; $sb = 0; $sn = 0
  for ($i = $la.Length - $top30; $i -lt $la.Length; $i++) {
    $o = $ia[$i]; $pr = [int]$buf[$o + 2]; $pg = [int]$buf[$o + 1]; $pb = [int]$buf[$o]
    $pmx = [Math]::Max($pr, [Math]::Max($pg, $pb)); $pmn = [Math]::Min($pr, [Math]::Min($pg, $pb))
    if ($pmx -ge 90 -and ($pmx - $pmn) / [double]$pmx -ge 0.3) { $sr += $pr; $sg += $pg; $sb += $pb; $sn++ }
  }
  if ($sn -ge [Math]::Max(4, $top30 * 0.2)) { $r = $sr / $sn; $g = $sg / $sn; $b = $sb / $sn }
  else {
    $top = [Math]::Max(3, [int]($la.Length * 0.12))
    $r = 0; $g = 0; $b = 0
    for ($i = $la.Length - $top; $i -lt $la.Length; $i++) { $o = $ia[$i]; $r += $buf[$o + 2]; $g += $buf[$o + 1]; $b += $buf[$o] }
    $r /= $top; $g /= $top; $b /= $top
  }
  $mx = [Math]::Max($r, [Math]::Max($g, $b))
  if ($mx -gt 0 -and $mx -lt 200) { $f = 200.0 / $mx; $r *= $f; $g *= $f; $b *= $f }
  return [System.Drawing.Color]::FromArgb([int][Math]::Min(255, $r), [int][Math]::Min(255, $g), [int][Math]::Min(255, $b))
}
# 화면이 바뀌었는지 빠르게 확인(작게 줄인 그림의 밝기 합)
function Px-Sig($px) {
  $sig = New-Object System.Text.StringBuilder; $buf = $px.b
  for ($yy = 0; $yy -lt $px.h; $yy += [Math]::Max(1, [int]($px.h / 60))) { $sum = 0; $row = $yy * $px.s
    for ($xx = 0; $xx -lt $px.w; $xx += 5) { $sum += $buf[$row + $xx * 4 + 1] }
    [void]$sig.Append($sum).Append(',') }
  return $sig.ToString()
}

function Same-Row($a, $b) { $h = [Math]::Max(0.005, ($a.Y1 - $a.Y0) / 2); return ([Math]::Abs((($a.Y0 + $a.Y1) / 2) - (($b.Y0 + $b.Y1) / 2)) -lt $h) }
function Ru-Text($bmp, $ln) {
  if (-not $HasRu) { return $null }
  # 새 줄만 러시아어로 따로 다시 읽어서 키릴 문자가 많으면 러시아어 줄로 봄
  $rt = Ocr-LineCrop $bmp $ln $ocrRu
  $cy = ([regex]::Matches($rt, '[Ѐ-ӿ]')).Count; $all = ([regex]::Matches($rt, '[A-Za-zЀ-ӿ]')).Count
  if ($cy -ge 3 -and $cy -ge $all * 0.4) { return $rt.Trim() }
  return $null
}
$TimeRe = '(?:[\(\[\{]\s*(?<h>[0-2]?\d)\s*[:;.]\s*(?<m>[0-5]\d)\s*[\)\]\}]?|(?<h>[0-2]?\d)\s*[:;.]\s*(?<m>[0-5]\d)\s*[\)\]\}])\s*$'
$TimeMode = $false
$PopupOn = $false
$PopupRe = '(?i)Price\s*\(?\s*adena|가격\s*\(|P\.\s*Atk|M\.\s*Atk|P\.\s*Def|M\.\s*Def|Atk\.?\s*Spd|Weight\s*:|무게\s*:|공격력\s*:|방어력\s*:|공격\s*속도|Soulshots?\s*Used|Spiritshots?\s*Used|Grade\s*:\s*[A-DS]\b|등급\s*:'
$LayEn = 'qwertyuiop[]asdfghjkl;''zxcvbnm,.`QWERTYUIOP{}ASDFGHJKL:"ZXCVBNM<>~&?'
$LayRu = 'йцукенгшщзхъфывапролджэячсмитьбюёЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮЁ?,'
function Fix-Layout($t) {
  $lt = [regex]::Matches($t, '[A-Za-z]'); if ($lt.Count -lt 6) { return $null }
  if ($t -match '(?i)(?<![a-z])(wts|wtb|wtt|lf|lfp|lfm|lfg|pm|top|rare|rar|afk|aoe|exp|lvl|kk|ok|lol|gg|ty|thx|np)(?![a-z])') { return $null }   # 영어 게임 약어가 있으면 진짜 영어
  $low = ([regex]::Matches($t, '[a-z]')).Count; if ($low -lt $lt.Count * 0.7) { return $null }
  if (($t -split '\s+' | Where-Object { $_ -match '[A-Za-z]' }).Count -lt 2) { return $null }
  $vEn = ([regex]::Matches($t, '[aeiouyAEIOUY]')).Count / [double]$lt.Count
  if ($vEn -ge 0.25) { return $null }
  $sb = New-Object System.Text.StringBuilder
  foreach ($ch in $t.ToCharArray()) { $ix = $LayEn.IndexOf($ch); if ($ix -ge 0) { [void]$sb.Append($LayRu[$ix]) } else { [void]$sb.Append($ch) } }
  $r = $sb.ToString()
  $cy = [regex]::Matches($r, '[а-яё]', 'IgnoreCase'); if ($cy.Count -lt 5) { return $null }
  $vRu = ([regex]::Matches($r, '[аеёиоуыэюя]', 'IgnoreCase')).Count / [double]$cy.Count
  if ($vRu -lt 0.28) { return $null }
  return $r
}
$NoticeChk = @{}; $NoticeDone = @{}; $RuneChk = @{}; $ClanChk = @{}
# 혈맹원 이름 명단(이름 대소문자/꼬리 글자 바로잡기용). 한 줄에 이름 하나
$ClanNames = @()
function Clan-Norm($t) { return ($t.ToLower() -replace '[il1|!]', 'l' -replace '0', 'o') }
try { $cnp = Join-Path $PSScriptRoot 'clan_members.txt'; if (Test-Path $cnp) { $ClanNames = @([System.IO.File]::ReadAllLines($cnp, [System.Text.Encoding]::UTF8) | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') }) } } catch {}
# 공지 속 유럽/모스크바 시각을 한국 시간으로 (서머타임 자동 반영)
function To-Kst($hh, $mm, $tzId, $fallbackAdd) {
  $d = [DateTime]::Today.AddHours([int]$hh).AddMinutes([int]$mm)
  try {
    $src = [TimeZoneInfo]::FindSystemTimeZoneById($tzId); $kst = [TimeZoneInfo]::FindSystemTimeZoneById('Korea Standard Time')
    $k = [TimeZoneInfo]::ConvertTime([DateTime]::SpecifyKind($d, 'Unspecified'), $src, $kst)
  } catch { $k = $d.AddHours($fallbackAdd) }
  return $k.ToString('HH:mm')
}
function Notice-ToKst($t) {
  $t = [regex]::Replace($t, '(?i)\b([0-2]?\d)[:.]([0-5]\d)\s*(CEST|CET)\b', { param($mm) (To-Kst $mm.Groups[1].Value $mm.Groups[2].Value 'Central Europe Standard Time' 8) + ' Korea time' })
  $t = [regex]::Replace($t, '(?i)\b([0-2]?\d)[:.]([0-5]\d)\s*(MSK)\b', { param($mm) (To-Kst $mm.Groups[1].Value $mm.Groups[2].Value 'Russian Standard Time' 6) + ' Korea time' })
  $t = [regex]::Replace($t, '([0-2]?\d)[:.]([0-5]\d)\s*по\s*Москве', { param($mm) (To-Kst $mm.Groups[1].Value $mm.Groups[2].Value 'Russian Standard Time' 6) + ' по корейскому времени' })
  $t = [regex]::Replace($t, '([0-2]?\d)[:.]([0-5]\d)\s*за\s*Києвом', { param($mm) (To-Kst $mm.Groups[1].Value $mm.Groups[2].Value 'FLE Standard Time' 7) + ' за корейським часом' })
  return $t
}
function Split-Time($t) {
  $m = [regex]::Match($t, '[\(\[\{]\s*(?<h>[0-2]?\d)\s*[:;.]\s*(?<m>[0-5]\d?)')
  if ($m.Success -and $m.Index -gt 0) { return @($t.Substring(0, $m.Index).Trim(), $m) }
  return @($t, $null)
}
$LastSig = ''; $Pending = $false; $LastTalkLang = ''; $ChatRight = 0.995
# 대화 = 흰색(일반) / 빨간색(귓속말) / 녹색(파티).  외치기 = 노란색.  그 밖의 색(거래 등)은 외치기 쪽으로
$TalkSub = ''
function Chat-Kind($c) {
  $script:TalkSub = ''
  if (-not $c) { return 'shout' }
  $cr = [double]$c.R; $cg = [double]$c.G; $cb = [double]$c.B
  $mx = [Math]::Max($cr, [Math]::Max($cg, $cb)); $mn = [Math]::Min($cr, [Math]::Min($cg, $cb))
  if ($mx -le 0) { return 'shout' }
  $sat = ($mx - $mn) / $mx
  if ($sat -lt 0.25) { $script:TalkSub = 'white'; return 'talk' }
  # 색상(hue) 0~360
  $d = $mx - $mn
  if ($mx -eq $cr) { $hue = 60 * ((($cg - $cb) / $d) % 6) } elseif ($mx -eq $cg) { $hue = 60 * ((($cb - $cr) / $d) + 2) } else { $hue = 60 * ((($cr - $cg) / $d) + 4) }
  if ($hue -lt 0) { $hue += 360 }
  if ($hue -lt 18 -or $hue -ge 335) { $script:TalkSub = 'red'; return 'talk' }
  if ($hue -ge 75 -and $hue -lt 170) { $script:TalkSub = 'green'; return 'talk' }
  return 'shout'
}
$First = $true; $AddN = 0; $TrFail = $null; $LastDump = ''
function Tick {
  $bmp = Grab-Chat
  if (-not $bmp) { return }
  try {
    $px = Get-Px $bmp
    # 채팅창이 그대로면 다시 읽지 않음
    $sig = Px-Sig $px
    if ($sig -eq $LastSig -and -not $First -and -not $Pending) { return }
    $script:LastSig = $sig; $script:Pending = $false
    # 채팅창 전체는 한 번만 읽고(영어 OCR), 새 줄만 한국어/러시아어로 따로 다시 읽음
    if ($HasEn) { $lines = @(Ocr-Bmp $bmp $ocrEn 1700) } else { $lines = @(Ocr-Bmp $bmp $ocrKo 1700) }
    # 채팅 줄은 채팅창 왼쪽에서 시작함. 오른쪽에서 시작하는 글(채팅창 밖 개인 상점 이름표 등)은 버림
    $script:PopupOn = $false
    foreach ($pl in $lines) { if ($pl.Text -match $PopupRe) { $script:PopupOn = $true; break } }
    if ($PopupOn) { Dbg '아이템 정보 창이 채팅창을 가리는 중 - 번역 쉼' }
    $lines = @($lines | Where-Object { $_.X0 -lt 0.2 } | Sort-Object Y0)
    $cr2 = 0.3; foreach ($l2 in $lines) { if ($l2.X1 -gt $cr2) { $cr2 = $l2.X1 } }
    $script:ChatRight = [Math]::Min(0.995, $cr2 + 0.015)
    # 채팅 시간 표시가 켜져 있는지(끝에 "(시:분)"이 붙은 줄이 3개 이상)
    $nT = 0; foreach ($l2 in $lines) { if ($l2.Text -match $TimeRe) { $nT++ } }
    $script:TimeMode = ($nT -ge 3)
    $dump = ($lines | ForEach-Object { $_.Text }) -join ' | '
    if ($dump -ne $LastDump) { $script:LastDump = $dump; Dbg ('채팅: ' + $dump) }
    $todo = 0; $talkNew = $false
    # 맨 아래(최신) 줄부터 위로 처리: 아래 3줄이 먼저 번역되고, 그 위 줄들은 걸러서 이어서 처리
    # (채팅창이 비어 있어 위에서부터 차는 경우도 새 줄은 항상 맨 아래쪽이라 같은 방식으로 동작)
    # 공지(하늘색 글, "이름:" 없음. 예: 서버 점검/재시작 안내) - 영어 공지가 있으면 그것만, 없으면 러시아어 하나만 번역
    $nCand = @()
    foreach ($nl in $lines) {
      $nt0 = $nl.Text.Trim()
      if ($nt0 -match $ChatRe -or $nt0 -notmatch $TimeRe -or $nt0 -match '(?i)Enter to Chat') { continue }
      if (([regex]::Matches($nt0, '[A-Za-zЀ-ӿ]')).Count -lt 6) { continue }
      $nc = $null; try { $nc = Color-Rect $px $nl.X0 $nl.X1 $nl.Y0 $nl.Y1 } catch {}
      if (-not $nc -or -not ($nc.B -ge 150 -and $nc.G -ge 140 -and $nc.R -lt $nc.B * 0.8)) { continue }
      # 이미 판단한 줄은 다시 읽지 않음
      $nck = Key-Of $nt0
      if ($NoticeChk.ContainsKey($nck)) { if ($NoticeChk[$nck]) { $nCand += $nl }; continue }
      $NoticeChk[$nck] = $false
      if ($NoticeChk.Count -gt 300) { $NoticeChk.Clear() }
      # 진짜 공지: 영어 공지 낱말이 있으면 바로 공지
      $okN = $nt0 -match '(?i)restart|server|maintenance|minutes|CET\b|update|event'
      if (-not $okN) {
        # 하늘색 한국어 시스템 메시지(예: "DoZ이(가) 공격을 회피했습니다")는 공지가 아님
        $nko = Ocr-LineCrop $bmp $nl $ocrKo
        if (([regex]::Matches($nko, '[가-힣]')).Count -ge 2) { continue }
        # 러시아어로 읽었을 때 키릴 문자가 충분히 많으면 러시아어 공지
        if ($HasRu) { $nru = Ocr-LineCrop $bmp $nl $ocrRu; $okN = ([regex]::Matches($nru, '[Ѐ-ӿ]')).Count -ge 10 }
      }
      if (-not $okN) { continue }
      $NoticeChk[$nck] = $true
      $nCand += $nl
    }
    if ($nCand.Count) {
      $lat = @($nCand | Where-Object { $_.Text -match '(?i)restart|server|maintenance|minutes|CET\b|update|event' })
      $pick = $(if ($lat.Count) { $lat[0] } else { $nCand[0] })
      $isRuN = -not $lat.Count
      $ntx = $pick.Text.Trim()
      if ($isRuN -and $HasRu) { $rt = Ocr-LineCrop $bmp $pick $ocrRu; if ($rt) { $ntx = $rt.Trim() } }
      $ntm = [regex]::Match($ntx, $TimeRe); $ntime = (Get-Date).ToString('HH:mm')
      if ($ntm.Success) { $ntime = ('{0:00}:{1}' -f [int]$ntm.Groups['h'].Value, $ntm.Groups['m'].Value); $ntx = $ntx.Substring(0, $ntm.Index).Trim() }
      # 같은 시각의 공지는 한 번만(러시아어/우크라이나어/영어 줄, 글자 인식 흔들림 모두)
      $nk = 'notice' + $ntime
      if (-not $NoticeDone.ContainsKey($nk)) {
        $NoticeDone[$nk] = 1
        if (-not $First) {
          try {
            $nr = Translate (Notice-ToKst $ntx) $(if ($isRuN) { 'ru' } else { 'en' })
            $cyan = [System.Drawing.Color]::FromArgb(120, 210, 255)
            $nsg = New-Object System.Collections.ArrayList
            [void]$nsg.Add([pscustomobject]@{ t = $ntime + ' '; c = [System.Drawing.Color]::Gray })
            [void]$nsg.Add([pscustomobject]@{ t = '[공지] ' + ([string]$nr.text).Trim(); c = $cyan })
            [void]$Shown.Add([pscustomobject]@{ t = ('{0} [공지] {1}' -f $ntime, $nr.text); c = $cyan; k = $nk; s = $nsg; kind = 'notice' })
            $script:AddN++; if ($cfg.mini) { $script:MiniNew++ }
            Dbg ('공지: ' + $ntx + ' => ' + $nr.text)
          } catch { Log-Err '공지 번역' $_ }
        }
      }
    }
    # 룬(EXP & SP 등) 만료 알림: "EXP & SP +15% 룬의 소유권이 만료되었습니다." → 번역 창에 [알림]으로 표시
    foreach ($rl in $lines) {
      $rt0 = $rl.Text.Trim()
      if ($rt0 -notmatch '(?i)EXP\s*\W{0,3}\s*SP' -or $rt0 -match $ChatRe) { continue }
      $rk = 'rune' + (Key-Of $rt0)
      if ($RuneChk.ContainsKey($rk)) { continue }
      $RuneChk[$rk] = 1; if ($RuneChk.Count -gt 200) { $RuneChk.Clear() }
      $rko = (Ocr-LineCrop $bmp $rl $ocrKo).Trim()
      if ($rko -notmatch '만료') { continue }   # 만료되었습니다 / N분 후에 만료됩니다 모두
      # 시간 "(2357)"처럼 콜론이 빠져 읽히면 "(23:57)"로, "문의 소유권" → "룬의 소유권"
      $rko = [regex]::Replace($rko, '[\(\[\{]\s*([0-2]\d)\s*([0-5]\d)\s*[\)\]\}]?\s*$', '($1:$2)')
      $rko = $rko -replace '(%\s*)[문른률루룬]\s*의', '$1룬의' -replace '만료\s*됨니다', '만료됩니다'
      # 끝의 시간 "(01:04)" / 잘못 읽힌 "(01℃4)" 등 괄호 속 숫자는 떼어 냄
      $rtm = (Get-Date).ToString('HH:mm')
      $rtt = [regex]::Match($rko, '\s*[\(\[\{][^\(\)\[\]\{\}]*\d[^\(\)\[\]\{\}]*[\)\]\}]?\s*$')
      if ($rtt.Success) {
        $dg = ($rtt.Value -replace '\D', ''); if ($dg.Length -eq 4 -and [int]$dg.Substring(0, 2) -lt 24 -and [int]$dg.Substring(2) -lt 60) { $rtm = $dg.Substring(0, 2) + ':' + $dg.Substring(2) }
        $rko = $rko.Substring(0, $rtt.Index).Trim()
      }
      # 같은 문장은 3분 안에 한 번만(글자 인식이 흔들려도)
      $dk = 'runeD|' + ($rko -replace '[^0-9가-힣A-Za-z%]', '')
      if ($NoticeDone.ContainsKey($dk) -and ([DateTime]::Now - $NoticeDone[$dk]).TotalMinutes -lt 3) { continue }
      if ($First) { $NoticeDone[$dk] = [DateTime]::Now; continue }
      $NoticeDone[$dk] = [DateTime]::Now
      $orn = [System.Drawing.Color]::FromArgb(255, 170, 80)
      $rsg = New-Object System.Collections.ArrayList
      [void]$rsg.Add([pscustomobject]@{ t = $rtm + ' '; c = [System.Drawing.Color]::Gray })
      [void]$rsg.Add([pscustomobject]@{ t = '[알림] ' + $rko; c = $orn })
      [void]$Shown.Add([pscustomobject]@{ t = ('{0} [알림] {1}' -f $rtm, $rko); c = $orn; k = $dk; s = $rsg; kind = 'notice' })
      $script:AddN++; if ($cfg.mini) { $script:MiniNew++ }
      if ($rko -match '만료\s*되었') { Play-Chat }   # 소리는 최종 만료 때만(미리 알림은 표시만)
      Dbg ('룬 알림: ' + $rko)
    }
    # 혈맹원 접속/종료 알림: "혈맹원 OOO님이 게임에 접속했습니다" 등 → [혈맹]으로 표시(소리 없음)
    foreach ($cl in $lines) {
      $ct0 = $cl.Text.Trim()
      if ($ct0 -match $ChatRe -or $ct0.Length -lt 4) { continue }
      # 영어로 읽으면 한글은 사라지고 이름만 남음(예: "QoZ (00:57)"). 이름(영문 2글자 이상)이 있고 전투 줄이 아닌 것만
      if ($ct0 -match '«|»|<<|>>' -or ($ct0 -replace '[\(\[\{]?\s*[0-2]?\d\s*[:;.]?\s*[0-5]\d\s*[\)\]\}]?\s*$', '') -notmatch '[A-Za-z]{2,}') { continue }
      $ck0 = 'clan' + (Key-Of $ct0)
      if ($ClanChk.ContainsKey($ck0)) { continue }
      $ClanChk[$ck0] = 1; if ($ClanChk.Count -gt 300) { $ClanChk.Clear() }
      # 줄 맨 왼쪽부터 다시 읽음("혈맹원"은 영어로 읽을 때 사라져서 줄 시작 위치가 이름부터로 잡힘)
      $clw = [pscustomobject]@{ Text = $cl.Text; X0 = 0.0; Y0 = $cl.Y0; X1 = $cl.X1; Y1 = $cl.Y1 }
      $cko = (Ocr-LineCrop $bmp $clw $ocrKo).Trim()
      if ($cko -notmatch '(혈맹|혈명|혈멩)' -or $cko -notmatch '(접속|입장|로그인|종료|로그아웃|나갔|퇴장)') { continue }
      # 줄 맨 왼쪽부터 읽어서 앞에 붙은 잡글자(SS 등)는 버리고 "혈맹"부터
      $hm = [regex]::Match($cko, '혈[맹명멩]'); if ($hm.Success -and $hm.Index -gt 0) { $cko = '혈맹' + $cko.Substring($hm.Index + 2) } elseif ($hm.Success) { $cko = '혈맹' + $cko.Substring(2) }
      # 끝의 시간 "(01:02)" / 잘못 읽힌 "(01℃2)" 등 괄호 속 숫자는 떼어 내고 시간으로
      $ctm = (Get-Date).ToString('HH:mm')
      $ctt = [regex]::Match($cko, '\s*[\(\[\{][^\(\)\[\]\{\}]*\d[^\(\)\[\]\{\}]*[\)\]\}]?\s*$')
      if ($ctt.Success) {
        $dg = ($ctt.Value -replace '\D', ''); if ($dg.Length -eq 4 -and [int]$dg.Substring(0, 2) -lt 24 -and [int]$dg.Substring(2) -lt 60) { $ctm = $dg.Substring(0, 2) + ':' + $dg.Substring(2) }
        $cko = $cko.Substring(0, $ctt.Index).Trim()
      }
      # 이름: 한국어로 읽은 이름이 영문이면 그대로, 한글로 깨졌을 때만 영어로 읽은 이름으로
      $cnm = [regex]::Match($cko, '([^\s]+?)(\s*님)')
      if ($cnm.Success -and $cnm.Groups[1].Value -match '[가-힣]' -and $cnm.Groups[1].Value -notmatch '^혈맹원$') {
        $cen = [regex]::Match($ct0, '[A-Za-z][A-Za-z0-9_]{1,15}')
        if ($cen.Success) { $cko = $cko.Substring(0, $cnm.Groups[1].Index) + $cen.Value + $cko.Substring($cnm.Groups[1].Index + $cnm.Groups[1].Length) }
      }
      # 대소문자: 한국어 OCR은 대소문자를 자주 틀림(QoZ → Qoz). 영어로 읽은 이름이 같은 글자로 시작하면 그 표기를 사용
      $cnm1 = [regex]::Match($cko, '([A-Za-z0-9_]+)(\s*님)')
      if ($cnm1.Success) {
        $kn = $cnm1.Groups[1].Value
        foreach ($ew in [regex]::Matches($ct0, '[A-Za-z0-9_]+')) {
          if ($ew.Value.Length -ge $kn.Length -and $ew.Value.Substring(0, $kn.Length).ToLower() -eq $kn.ToLower()) {
            $cko = $cko.Substring(0, $cnm1.Groups[1].Index) + $ew.Value.Substring(0, $kn.Length) + $cko.Substring($cnm1.Groups[1].Index + $kn.Length); break
          }
        }
      }
      # 이름 정리: 혈맹원 명단(clan_members.txt)에 있는 이름으로 시작하면 명단 표기 그대로,
      # 아니면 "님이"가 잘못 붙어 읽힌 꼬리(UOI, LdOI 등)를 떼어 냄
      $cnm3 = [regex]::Match($cko, '([A-Za-z0-9_]+)(\s*님)')
      if ($cnm3.Success) {
        $raw = $cnm3.Groups[1].Value; $fix = $null
        # 명단과 비교: 대소문자 무시 + 헷갈리는 글자(I/l/1/|, O/0) 같은 글자로 (예: Vip / Vlp / vIP -> VIP)
        $rn = Clan-Norm $raw
        foreach ($mb in ($ClanNames | Sort-Object Length -Descending)) { $mn = Clan-Norm $mb; if ($rn.Length -ge $mn.Length -and $rn.Substring(0, $mn.Length) -eq $mn) { $fix = $mb; break } }
        if (-not $fix -and $raw.Length -gt 4) { $fix = $raw -replace '(Ld|L|U|u)?[O0o][Il1|]$', '' }
        if ($fix -and $fix -ne $raw) { $cko = $cko.Substring(0, $cnm3.Groups[1].Index) + $fix + $cko.Substring($cnm3.Groups[1].Index + $raw.Length) }
      }
      $cnm2 = [regex]::Match($cko, '([A-Za-z0-9_]+)\s*님'); $nmk = $(if ($cnm2.Success) { $cnm2.Groups[1].Value.ToLower().Substring(0, [Math]::Min(3, $cnm2.Groups[1].Value.Length)) } else { '' })
      $act = $(if ($cko -match '(종료|로그아웃|나갔|퇴장)') { 'out' } else { 'in' })
      # 같은 사람의 같은 알림은 3분 안에 한 번만(글자 인식이 조금씩 달라도)
      $cdk = 'clanD|' + $nmk + '|' + $act
      if ($NoticeDone.ContainsKey($cdk) -and ([DateTime]::Now - $NoticeDone[$cdk]).TotalMinutes -lt 3) { continue }
      if ($First) { $NoticeDone[$cdk] = [DateTime]::Now; continue }
      $NoticeDone[$cdk] = [DateTime]::Now
      $cg = [System.Drawing.Color]::FromArgb(180, 160, 255)
      $csg = New-Object System.Collections.ArrayList
      [void]$csg.Add([pscustomobject]@{ t = $ctm + ' '; c = [System.Drawing.Color]::Gray })
      [void]$csg.Add([pscustomobject]@{ t = '[혈맹] ' + $cko; c = $cg })
      [void]$Shown.Add([pscustomobject]@{ t = ('{0} [혈맹] {1}' -f $ctm, $cko); c = $cg; k = $cdk; s = $csg; kind = 'notice' })
      $script:AddN++; if ($cfg.mini) { $script:MiniNew++ }
      Dbg ('혈맹 알림: ' + $cko)
    }
    $order = @(); for ($oi = $lines.Count - 1; $oi -ge 0; $oi--) { $order += $oi }
    foreach ($li in $order) {
      $ln = $lines[$li]
      $txt = $ln.Text.Trim()
      if ($txt -match 'Enter to Chat') { continue }
      $m = [regex]::Match($txt, $ChatRe)
      if (-not $m.Success) { continue }
      # 화면 뒤 개인 상점 이름 등 채팅이 아닌 글자는 무시
      if ($txt -match 'Private ?Store|<[^>]*>|[\u4E00-\u9FFF]') { continue }
      # 채팅창 위쪽 탭 줄(ALL / SYSTEM / FAMILY / TRADE / PARTY / CLAN)은 채팅이 아님
      # 탭 줄은 글자가 심하게 깨져 읽히므로, 영문자만 남겨서 탭 이름 조각이 2개 이상이면 버림
      $cmp = ($txt.ToLower() -replace '[^a-z]', '')
      $tabN = 0
      foreach ($tp in @('sys|stem|yste', 'fam|amil|mily', 'trad|rade', 'party|parfy', 'clan')) { if ($cmp -match $tp) { $tabN++ } }
      if ($tabN -ge 2 -or ($tabN -ge 1 -and $txt -match '(?i)^\W*a\s?[l1|]\w{0,2}\s*[:;v]')) { continue }
      # 전투 피해 줄("77 «« DoZ «« 몬스터", "DoZ »» 몬스터 »» 675")은 채팅이 아님
      if (([regex]::Matches($txt, '«|»|\(\(|\)\)|<<|>>')).Count -ge 2) { continue }
      $k0 = Key-Of $txt
      if (Was-Seen $k0) { continue }                                     # 이미 본 줄은 다시 읽지 않음
      if ($First) { Mark-Seen $k0; continue }                            # 켰을 때 이미 있던 줄은 번역하지 않음
      if ($todo -ge 8) { $script:Pending = $true; break }                # 한 번에 너무 많이 하지 않기(남은 줄은 다음에)
      # 새 줄만 한국어로 다시 읽어서 한국어 줄이면 건너뜀
      $kt = Ocr-LineCrop $bmp $ln $ocrKo
      $kw = $CropWords
      $km = [regex]::Match($kt.Trim(), $ChatRe); $kmsg = $(if ($km.Success) { $km.Groups[2].Value } else { $kt })
      # 채팅 시간 "(19:36)" 뒤에 붙은 글자는 채팅창 밖의 다른 글자라 버림
      $kmsg = (Split-Time $kmsg)[0]
      if (([regex]::Matches($kt, '«|»')).Count -ge 1) { Mark-Seen $k0; continue }
      # 한국어만 있는 줄은 건너뜀. 한글이 섞인 줄(아이템 링크 등)은 한글 부분은 그대로 두고 나머지만 번역
      $hasKo = ([regex]::Matches($kmsg, '[가-힣]')).Count -ge 2
      if ($hasKo -and ((Hangul-Ratio $kmsg) -ge 0.85 -or ([regex]::Matches($kmsg, '[A-Za-zЀ-ӿ]')).Count -lt 3)) { Mark-Seen $k0; Dbg ('건너뜀(한국어): ' + $txt); continue }
      $t = $txt
      if (-not $HasEn) { $t = Ocr-LineCrop $bmp $ln $ocrEn }
      # 러시아어로 읽은 같은 줄에 키릴 문자가 많으면 러시아어 줄로 봄
      $isRu = $false
      if (-not $hasKo) { $tr2 = Ru-Text $bmp $ln; if ($tr2) { $t = $tr2; $isRu = $true } }
      $m2 = [regex]::Match($t.Trim(), $ChatRe)
      if ($m2.Success) { $who = $m2.Groups[1].Value; $msg = $m2.Groups[2].Value.Trim() } else { $who = $m.Groups[1].Value; $msg = $m.Groups[2].Value.Trim() }
      if ($hasKo) { $msg = $kmsg.Trim() }   # 한글이 섞인 줄은 한국어 OCR로 읽은 글 사용
      # 긴 채팅이 다음 줄로 넘어간 경우 이어 붙이기(바로 아래 줄, "이름:"으로 시작하지 않고 글자 색이 같은 줄)
      $c1 = $null; try { $c1 = Line-Color $px $ln } catch {}
      # 색: 아이디 / 아이템 링크(한글) / 나머지 글 을 각각 게임 화면에서 읽음
      $cName = $c1; $cLink = $c1; $cBase = $c1
      try {
        $ci = -1; for ($wi = 0; $wi -lt $kw.Count; $wi++) { if ($kw[$wi].t -match '[:;]') { $ci = $wi; break } }
        if ($ci -ge 0) { $cName = Color-Rect $px $kw[0].x0 $kw[$ci].x1 $ln.Y0 $ln.Y1 }
        $hw = @($kw | Select-Object -Skip ($ci + 1) | Where-Object { $_.t -match '[가-힣]' })
        $lw = @($kw | Select-Object -Skip ($ci + 1) | Where-Object { $_.t -notmatch '[가-힣]' -and $_.t -match '[A-Za-zЀ-ӿ]{2,}' } | Sort-Object { $_.x1 - $_.x0 } -Descending)
        if ($hw.Count) { $cLink = Color-Rect $px $hw[0].x0 $hw[-1].x1 $ln.Y0 $ln.Y1 }
        if ($lw.Count) { $cBase = Color-Rect $px $lw[0].x0 $lw[0].x1 $ln.Y0 $ln.Y1 }
      } catch {}
      # 글자 색으로 외치기/대화 구분 후, 꺼 둔 종류는 건너뜀
      # 종류는 아이디(이름) 색으로 판단: 외치기 글 안의 아이템 링크는 색이 달라서 글 색으로 보면 대화로 잘못 잡힘
      $kind = Chat-Kind $(if ($cName) { $cName } else { $cBase })
      if ($kind -eq 'talk' -and $cBase -and (Chat-Kind $cBase) -eq 'shout') { $kind = 'shout' }   # 이름이나 글 중 하나라도 노란색이면 외치기
      if (($kind -eq 'shout' -and -not $cfg.shout) -or ($kind -eq 'talk' -and -not $cfg.talk)) { Mark-Seen $k0; Dbg ('건너뜀(' + $kind + ' 꺼짐): ' + $txt); continue }
      $prev = $ln
      # 채팅 시간 표시(끝의 "(21:24)")가 켜져 있으면: 시간이 붙은 줄이 그 채팅의 마지막 줄
      $endsT = ($msg -match $TimeRe) -or ($txt -match $TimeRe)
      for ($lj = $li + 1; $lj -lt $lines.Count -and $lj -le $li + 3; $lj++) {
        if ($TimeMode -and $endsT) { break }
        $nx = $lines[$lj]; $nt = $nx.Text.Trim()
        $lh = $prev.Y1 - $prev.Y0
        if ($nx.Y0 - $prev.Y1 -gt $lh * 0.9) { break }
        if ($nt -match $ChatRe -or $nt -match 'Enter to Chat' -or $nt -match '(?i)SYSTEM|TRADE|PARTY|CLAN|Private ?Store') { break }
        $c2 = $null; try { $c2 = Line-Color $px $nx } catch {}
        if ($c1 -and $c2 -and ([Math]::Abs($c1.R - $c2.R) + [Math]::Abs($c1.G - $c2.G) + [Math]::Abs($c1.B - $c2.B)) -gt 90) { break }
        if ($isRu) { $nt2 = Ru-Text $bmp $nx; if ($nt2) { $nt = $nt2 } }
        elseif ($hasKo) { $nt2 = Ocr-LineCrop $bmp $nx $ocrKo; if ($nt2) { $nt = $nt2.Trim() } }
        $msg = $msg + ' ' + $nt; $prev = $nx
        if ($nt -match $TimeRe) { $endsT = $true }
      }
      # 끝의 채팅 시간을 떼어 내서 표시용 시간으로 사용
      $tm = (Get-Date).ToString('HH:mm')
      $tmm = [regex]::Match($msg, $TimeRe)
      if ($tmm.Success) { $tm = ('{0:00}:{1}' -f [int]$tmm.Groups['h'].Value, $tmm.Groups['m'].Value); $msg = $msg.Substring(0, $tmm.Index).Trim() }
      else {
        # 시간이 일부만 읽혔어도("(19:3 ...") 그 뒤는 버림
        $sp = Split-Time $msg
        if ($sp[1]) { $msg = $sp[0]; $mmv = $sp[1].Groups['m'].Value; if ($mmv.Length -eq 2) { $tm = ('{0:00}:{1}' -f [int]$sp[1].Groups['h'].Value, $mmv) } }
      }
      # 아이템 링크를 눌러 뜬 아이템 정보 창이 채팅창을 가리면, 그 창의 글(가격/공격력 등)이 섞여 읽힘
      # → 이번엔 건너뛰고 "본 줄"로도 남기지 않음(창을 닫으면 원래 채팅을 다시 읽어 번역)
      if (($msg + ' ' + $kt) -match $PopupRe -or $PopupOn) { Dbg ('건너뜀(아이템 정보 창): ' + $txt); continue }
      $k = Key-Of ($who + ':' + $msg)
      Mark-Seen $k0
      if ($k.Length -lt 3) { continue }
      $todo++
      if (($k -ne $k0) -and (Was-Seen $k)) { Dbg ('건너뜀(이미 본 줄): ' + $txt); continue }
      Mark-Seen $k
      if (([regex]::Matches($msg, '[A-Za-zЀ-ӿ]')).Count -lt 2) { Dbg ('건너뜀(글자 없음): ' + $txt); continue }
      # 전부 대문자인 글은 번역기가 잘 못 옮겨서 소문자로 바꿔서 보냄
      # 러시아 사람이 영문 자판으로 잘못 친 글("d gr [jxtim" = "в пк хочешь")을 러시아어로 바꿈
      if (-not $isRu) { $lay = Fix-Layout $msg; if ($lay) { Dbg ('자판 변환: ' + $msg + ' => ' + $lay); $msg = $lay; $isRu = $true } }
      $msgG = Protect $msg; $map = $PMap.Clone(); $links = $LinkKeys.Clone()
      $up = ([regex]::Matches($msg, '[A-ZА-Я]')).Count; $lo = ([regex]::Matches($msg, '[a-zа-я]')).Count
      if ($up -ge 4 -and $up -gt $lo * 2) { $msgG = $msgG.ToLower() }
      $sl = 'auto'; if ($isRu) { $sl = 'ru' }
      # 용어만 있는 글(예: "판매 블댄")은 번역기에 보낼 필요 없음
      if (([regex]::Matches(($msgG -replace 'QZ\d+Q', ''), '[A-Za-zЀ-ӿ]{2,}')).Count -eq 0) { $r = @{ text = $msgG; lang = 'xx' } }
      else {
      try { $r = Translate $msgG $sl } catch { Log-Err '번역' $_; Dbg ('번역 실패: ' + $_.Exception.Message); $script:TrFail = [DateTime]::Now; $script:State = '번역 실패'; continue }
      }
      $out = Restore $r.text $map
      # 이미 한국어인 줄은 건너뜀(용어만 바뀐 줄은 보여 줌)
      Dbg ('번역: [' + $who + '] ' + $msgG + ' => ' + $r.text + ' => ' + $out + ' (' + $r.lang + ')')
      # 번역이 원문과 같아도(이름/숫자만 있는 글 등) 빠뜨리지 않고 원문 그대로 보여 줌
      if (-not $out) { $out = $msg }
      if ($r.lang -eq 'ko') { Dbg ('건너뜀(한국어 판정): ' + $txt); continue }
      if ($kind -eq 'talk') { if ($isRu -or $r.lang -eq 'ru') { $script:LastTalkLang = 'ru' } elseif ($r.lang -eq 'en') { $script:LastTalkLang = 'en' } }
      $gray = [System.Drawing.Color]::Gray; $def = [System.Drawing.Color]::Gainsboro
      # 외치기(노란 글)는 노란색, 대화(흰 글 등)는 흰색 한 가지로 표시
      if ($kind -eq 'talk') {
        $cName = $(switch ($TalkSub) { 'red' { [System.Drawing.Color]::FromArgb(255, 120, 120) } 'green' { [System.Drawing.Color]::FromArgb(120, 230, 120) } default { [System.Drawing.Color]::FromArgb(240, 240, 240) } })
      }
      elseif (-not $cName) { $cName = [System.Drawing.Color]::FromArgb(255, 222, 90) }
      $cBase = $cName; $cLink = $cName
      $segs = New-Object System.Collections.ArrayList
      [void]$segs.Add([pscustomobject]@{ t = $tm + ' '; c = $gray })
      [void]$segs.Add([pscustomobject]@{ t = $who + ': '; c = $cName })
      foreach ($sg in (Restore-Segs $r.text $map $links $cBase $cLink)) { [void]$segs.Add($sg) }
      $entry = [pscustomobject]@{ t = ('{0} {1}: {2}' -f $tm, $who, $out); c = $cBase; k = $k0; s = $segs; kind = $kind }
      # 화면에서 바로 아래에 있는 채팅이 이미 번역 창에 있으면, 그 위에 끼워 넣어 게임 채팅 순서대로 보이게
      $ins = -1
      for ($lj = $li + 1; $lj -lt $lines.Count; $lj++) {
        $bt = $lines[$lj].Text.Trim()
        if ($bt -match $ChatRe) {
          $bk = Key-Of $bt
          for ($si = [Math]::Max(0, $Shown.Count - 30); $si -lt $Shown.Count; $si++) { if ($Shown[$si].k -and (Similar $Shown[$si].k $bk)) { $ins = $si; break } }
          if ($ins -ge 0) { break }
        }
      }
      if ($ins -ge 0) { $Shown.Insert($ins, $entry) } else { [void]$Shown.Add($entry) }
      if ($kind -eq 'talk') { $talkNew = $true }
      $script:LastOrig = '{0}: {1}' -f $who, $msg
      $script:AddN++; if ($cfg.mini) { $script:MiniNew++ }
      while ($Shown.Count -gt 30) { $Shown.RemoveAt(0) }
    }
    $script:First = $false
    if ($talkNew) { Play-Chat }   # 대화(일반/파티/귓속말) 번역이 새로 올라오면 알림음
  } finally { $bmp.Dispose() }
}

# ---------- 창 ----------
$cfg = @{ zone = $null; sndFile = ''; snd = $true; mini = $false; x = 400; y = 500; w = 560; h = 230; noAsk = $false; shout = $false; talk = $true; outLang = 'auto' }
if (Test-Path $CfgPath) { try { $j = Get-Content $CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json; $cfg.x = [int]$j.x; $cfg.y = [int]$j.y; if ($j.w) { $cfg.w = [int]$j.w }; if ($j.h) { $cfg.h = [int]$j.h }; if ($j.noAsk) { $cfg.noAsk = $true }
  if ($null -ne $j.shout) { $cfg.shout = [bool]$j.shout }; if ($null -ne $j.talk) { $cfg.talk = [bool]$j.talk }; if ($j.outLang) { $cfg.outLang = [string]$j.outLang }; if ($j.mini) { $cfg.mini = $true }; if ($null -ne $j.snd) { $cfg.snd = [bool]$j.snd }; if ($j.sndFile) { $cfg.sndFile = [string]$j.sndFile }
  if ($j.zone -and @($j.zone).Count -eq 4) { $script:ZoneChat = @([double]$j.zone[0], [double]$j.zone[1], [double]$j.zone[2], [double]$j.zone[3]); $cfg.zone = $ZoneChat } } catch {} }
function Save-CfgRaw { @{ x = $cfg.x; y = $cfg.y; w = $cfg.w; h = $cfg.h; noAsk = [bool]$cfg.noAsk; shout = [bool]$cfg.shout; talk = [bool]$cfg.talk; outLang = $cfg.outLang; mini = [bool]$cfg.mini; snd = [bool]$cfg.snd; sndFile = $cfg.sndFile; zone = $cfg.zone } | ConvertTo-Json | Set-Content $CfgPath -Encoding UTF8 }
function Save-Cfg { if ($form) { $cfg.x = $form.Left; $cfg.w = $form.Width; if ($cfg.mini) { $cfg.y = $form.Bottom - $cfg.h } else { $cfg.y = $form.Top; $cfg.h = $form.Height } }; Save-CfgRaw }

# ---------- DeepL 키 입력 (사람마다 자기 계정 키 사용) ----------
function Test-DeepL($key) {
  $host2 = if ($key.EndsWith(':fx')) { 'https://api-free.deepl.com' } else { 'https://api.deepl.com' }
  $wc = New-Object System.Net.WebClient; $wc.Encoding = [System.Text.Encoding]::UTF8
  $wc.Headers.Add('Authorization', 'DeepL-Auth-Key ' + $key)
  try { $u = $wc.DownloadString($host2 + '/v2/usage') | ConvertFrom-Json; return ('사용량 {0:N0} / {1:N0} 글자' -f $u.character_count, $u.character_limit) }
  finally { $wc.Dispose() }
}
function Ask-DeepL {
  $d = New-Object System.Windows.Forms.Form
  $d.Text = 'LU4 채팅 번역 - DeepL 키'; $d.TopMost = $true; $d.StartPosition = 'CenterScreen'
  $d.FormBorderStyle = 'FixedDialog'; $d.MaximizeBox = $false; $d.MinimizeBox = $false; $d.ClientSize = '470,250'
  $d.Font = UIFont 10
  $l = New-Object System.Windows.Forms.Label; $l.Location = '14,12'; $l.Size = '445,96'
  $l.Text = "DeepL 번역을 쓰면 구글보다 훨씬 자연스럽게 번역돼요.`r`n`r`n" +
            "1) 아래 [키 받으러 가기] → DeepL API Free 가입 (월 50만 글자 무료)`r`n" +
            "2) 계정 → API Keys 에서 키 복사 (무료 키는 끝이 :fx)`r`n" +
            "3) 아래 칸에 붙여 넣고 [확인]   * 비밀번호가 아니라 API 키만 넣으세요."
  $tb = New-Object System.Windows.Forms.TextBox; $tb.Location = '14,112'; $tb.Size = '442,24'; $tb.Text = $DeepLKey
  $st = New-Object System.Windows.Forms.Label; $st.Location = '14,140'; $st.Size = '442,20'; $st.ForeColor = [System.Drawing.Color]::Firebrick
  $cb = New-Object System.Windows.Forms.CheckBox; $cb.Location = '14,164'; $cb.Size = '300,22'; $cb.Text = '다음부터 묻지 않기 (제목 오른쪽 클릭으로 다시 입력)'; $cb.Checked = [bool]$cfg.noAsk
  $bGo = New-Object System.Windows.Forms.Button; $bGo.Location = '14,200'; $bGo.Size = '130,32'; $bGo.Text = '키 받으러 가기'
  $bOk = New-Object System.Windows.Forms.Button; $bOk.Location = '226,200'; $bOk.Size = '90,32'; $bOk.Text = '확인'
  $bNo = New-Object System.Windows.Forms.Button; $bNo.Location = '322,200'; $bNo.Size = '134,32'; $bNo.Text = '구글 번역으로 사용'
  $d.Controls.AddRange(@($l, $tb, $st, $cb, $bGo, $bOk, $bNo)); $d.AcceptButton = $bOk
  $bGo.Add_Click({ try { Start-Process 'https://www.deepl.com/pro-api' } catch {} })
  $bNo.Add_Click({ $d.Tag = 'google'; $d.Close() })
  $bOk.Add_Click({
    $k = ($tb.Text -replace '\s', '')
    if (-not $k) { $st.Text = '키를 붙여 넣어 주세요.'; return }
    $st.ForeColor = [System.Drawing.Color]::DimGray; $st.Text = '키 확인 중...'; $d.Refresh()
    try { $info = Test-DeepL $k } catch {
      $st.ForeColor = [System.Drawing.Color]::Firebrick
      $st.Text = $(if ($_.Exception.Message -match '403') { '키가 맞지 않아요. 다시 확인해 주세요.' } else { '확인 실패: ' + $_.Exception.Message })
      return }
    try { @('# DeepL API 키 (이 PC 사용자 본인 계정). 지우면 구글 번역을 사용합니다.', $k) | Set-Content $DeepLPath -Encoding UTF8 } catch {}
    $script:DeepLKey = $k; $script:Engine = 'DeepL'; $script:TrCache.Clear()
    [System.Windows.Forms.MessageBox]::Show($d, "DeepL 키를 저장했어요.`r`n$info", 'LU4 채팅 번역') | Out-Null
    $d.Tag = 'ok'; $d.Close() })
  [void]$d.ShowDialog()
  $cfg.noAsk = $cb.Checked
  try { Save-Cfg } catch {}
}
# 처음 켤 때 키가 없으면 한 번 물어봄
if (-not $DeepLKey -and -not $cfg.noAsk) { Ask-DeepL }

$form = New-Object System.Windows.Forms.Form
$form.Text = 'LU4 채팅 번역 - made by DoZ'; $form.FormBorderStyle = 'None'; $form.TopMost = $true; $form.ShowInTaskbar = $true
$form.BackColor = [System.Drawing.Color]::FromArgb(20, 22, 26); $form.Opacity = 0.85
$form.StartPosition = 'Manual'; $form.Location = New-Object System.Drawing.Point $cfg.x, $cfg.y
if ($cfg.w -lt 520) { $cfg.w = 520 }
$form.Size = New-Object System.Drawing.Size $cfg.w, $cfg.h
$form.MinimumSize = New-Object System.Drawing.Size 520, 34
$fT = UIFont 11 -bold
$fB = UIFont 11
$fHint = UIFont 10        # 입력칸 안내 문구
$fBtn = UIFont 10 -bold  # 영역 / EN / RU 버튼

$lTitle = New-Object System.Windows.Forms.Label
$lTitle.Font = $fT; $lTitle.ForeColor = [System.Drawing.Color]::FromArgb(255, 190, 90)
$lTitle.Location = New-Object System.Drawing.Point 8, ($cfg.h - 31); $lTitle.Size = New-Object System.Drawing.Size ($cfg.w - 410), 26; $lTitle.TextAlign = 'MiddleLeft'; $lTitle.Anchor = 'Bottom,Left,Right'; $lTitle.AutoEllipsis = $true
$lTitle.Text = '채팅 번역'
$bPause = New-Object System.Windows.Forms.Label
$bPause.Font = $fT; $bPause.ForeColor = [System.Drawing.Color]::Silver; $bPause.Text = 'Ⅱ'; $bPause.Size = '20,26'; $bPause.TextAlign = 'MiddleCenter'
$bPause.Location = New-Object System.Drawing.Point ($cfg.w - 46), ($cfg.h - 31); $bPause.Anchor = 'Bottom,Right'; $bPause.Cursor = 'Hand'
$bClose = New-Object System.Windows.Forms.Label
$bClose.Font = $fT; $bClose.ForeColor = [System.Drawing.Color]::Silver; $bClose.Text = '✕'; $bClose.Size = '20,26'; $bClose.TextAlign = 'MiddleCenter'
$bClose.Location = New-Object System.Drawing.Point ($cfg.w - 24), ($cfg.h - 31); $bClose.Anchor = 'Bottom,Right'; $bClose.Cursor = 'Hand'
# 번역 줄을 게임 채팅 색 그대로 그리는 칸
$lBody = New-Object System.Windows.Forms.Panel
$lBody.Location = '8,6'; $lBody.Size = New-Object System.Drawing.Size ($cfg.w - 16), ($cfg.h - 70); $lBody.Anchor = 'Top,Left,Right,Bottom'
$lBody.BackColor = $form.BackColor
$lBody.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'NonPublic,Instance').SetValue($lBody, $true, $null)
# 스크롤: 마우스 휠 / 오른쪽 스크롤바. 맨 아래가 아니면 새 줄이 와도 보던 위치 유지
$ScrollOff = 0; $ShownLastN = 0
$vsb = New-Object System.Windows.Forms.VScrollBar
$vsb.Dock = 'Right'; $vsb.Width = 12; $vsb.Minimum = 0; $vsb.SmallChange = 1; $vsb.LargeChange = 1; $vsb.Visible = $false
$lBody.Controls.Add($vsb)
function Sync-Scroll {
  $mx = [Math]::Max(0, $Shown.Count - 1)
  if ($ScrollOff -gt $mx) { $script:ScrollOff = $mx }; if ($ScrollOff -lt 0) { $script:ScrollOff = 0 }
  $vsb.Visible = ($Shown.Count -gt 4)
  $vsb.Maximum = $mx; $vsb.Value = [Math]::Max(0, $mx - $ScrollOff)
}
$vsb.Add_Scroll({ $script:ScrollOff = [Math]::Max(0, $vsb.Maximum - $vsb.Value); $lBody.Invalidate() })
$wheel = { $script:ScrollOff += $(if ($_.Delta -gt 0) { 2 } else { -2 }); Sync-Scroll; $lBody.Invalidate() }
$lBody.Add_MouseWheel($wheel); $form.Add_MouseWheel($wheel)
$lBody.Add_MouseEnter({ if (-not $tbIn.Focused) { [void]$lBody.Focus() } })
$lBody.Add_Paint({
  $gr = $_.Graphics; $W2 = $lBody.Width - 4 - $(if ($vsb.Visible) { 14 } else { 0 })
  $flags = [System.Windows.Forms.TextFormatFlags]'WordBreak,NoPrefix'
  if ($Shown.Count -eq 0) {
    [System.Windows.Forms.TextRenderer]::DrawText($gr, '다른 사람 채팅이 올라오면 여기에 번역해서 보여 줘요.', $fB, (New-Object System.Drawing.Rectangle 0, 0, $W2, 40), [System.Drawing.Color]::Gray, $flags)
    $byS = [System.Windows.Forms.TextRenderer]::MeasureText('made by DoZ', $fHint); [System.Windows.Forms.TextRenderer]::DrawText($gr, 'made by DoZ', $fHint, (New-Object System.Drawing.Point ([Math]::Max(0, $W2 - $byS.Width)), ($lBody.Height - $fHint.Height - 2)), [System.Drawing.Color]::FromArgb(110, 110, 110), [System.Windows.Forms.TextFormatFlags]'NoPrefix')
    return
  }
  # 아래(최신)부터 위로 쌓아서, 칸에 들어가는 만큼만
  $yb = $lBody.Height
  $nf = [System.Windows.Forms.TextFormatFlags]'NoPrefix,NoPadding'
  $lhB = $fB.Height + 1
  for ($i = $Shown.Count - 1 - $ScrollOff; $i -ge 0 -and $yb -gt 0; $i--) {
    $e = $Shown[$i]
    if (($e.kind -eq 'shout' -and -not $cfg.shout) -or ($e.kind -eq 'talk' -and -not $cfg.talk)) { continue }
    if (-not $e.s) {
      $sz = [System.Windows.Forms.TextRenderer]::MeasureText($gr, $e.t, $fB, (New-Object System.Drawing.Size $W2, 1000), $flags)
      $yb -= ($sz.Height + 2)
      [System.Windows.Forms.TextRenderer]::DrawText($gr, $e.t, $fB, (New-Object System.Drawing.Rectangle 0, $yb, $W2, $sz.Height), $e.c, $flags)
      continue
    }
    # 색 조각을 낱말 단위로 줄바꿈하며 배치
    $ops = New-Object System.Collections.ArrayList; $x = 0; $row = 0
    foreach ($sg in $e.s) {
      foreach ($pc in [regex]::Split($sg.t, '(?<= )')) {
        if (-not $pc) { continue }
        $pw = [System.Windows.Forms.TextRenderer]::MeasureText($gr, $pc, $fB, (New-Object System.Drawing.Size 4000, 100), $nf).Width
        if ($x -gt 0 -and $x + $pw -gt $W2) { $row++; $x = 0; if ($pc -eq ' ') { continue } }
        [void]$ops.Add(@($pc, $x, $row, $sg.c)); $x += $pw
      }
    }
    $yb -= (($row + 1) * $lhB + 2)
    foreach ($op in $ops) { [System.Windows.Forms.TextRenderer]::DrawText($gr, $op[0], $fB, (New-Object System.Drawing.Point $op[1], ($yb + $op[2] * $lhB)), $op[3], $nf) }
  }
  if ($ScrollOff -gt 0) { [System.Windows.Forms.TextRenderer]::DrawText($gr, ('▼ 아래로 ' + $ScrollOff + '줄 더 있음'), $fB, (New-Object System.Drawing.Point 0, ($lBody.Height - $fB.Height)), [System.Drawing.Color]::Gray, $nf) }
})
$lBody.Add_Resize({ $lBody.Invalidate() })
$tip = New-Object System.Windows.Forms.ToolTip
# 외치기/대화 켜고 끄기 (제목줄 오른쪽)
$tShout = New-Object System.Windows.Forms.Label; $tShout.Font = $fT; $tShout.Size = '58,26'; $tShout.TextAlign = 'MiddleLeft'; $tShout.Cursor = 'Hand'; $tShout.Anchor = 'Bottom,Right'
$tShout.Location = New-Object System.Drawing.Point ($cfg.w - 398), ($cfg.h - 31)
$tTalk = New-Object System.Windows.Forms.Label; $tTalk.Font = $fT; $tTalk.Size = '148,26'; $tTalk.Cursor = 'Hand'; $tTalk.Anchor = 'Bottom,Right'
$tTalk.Location = New-Object System.Drawing.Point ($cfg.w - 334), ($cfg.h - 31)
function Paint-Toggles {
  $tShout.Text = ''; $tShout.Invalidate()
  $tTalk.Text = ''; $tTalk.Invalidate()
}
$tShout.Add_Click({ $cfg.shout = -not $cfg.shout; Paint-Toggles; Save-Cfg; $lBody.Invalidate() })
$tTalk.Add_Click({ $cfg.talk = -not $cfg.talk; Paint-Toggles; Save-Cfg; $lBody.Invalidate() })
# "대화(일반,파티,귓속말)"을 채팅 색 그대로: 일반=흰색, 파티=녹색, 귓속말=빨간색 (꺼지면 모두 회색)
# 외치기도 대화와 같은 방식으로 그려서 글자 높이를 맞춤
$tShout.Add_Paint({
  $gr = $_.Graphics; $nf = [System.Windows.Forms.TextFormatFlags]'NoPrefix,NoPadding,SingleLine'
  $on = [bool]$cfg.shout; $c = $(if ($on) { [System.Drawing.Color]::FromArgb(255, 222, 90) } else { [System.Drawing.Color]::DimGray })
  $sym = New-Object System.Drawing.Font('Segoe UI Symbol', $tShout.Font.Size)
  $bx = $(if ($on) { '☑' } else { '☐' })
  [System.Windows.Forms.TextRenderer]::DrawText($gr, $bx, $sym, (New-Object System.Drawing.Point 2, ([int](($tShout.Height - $sym.Height) / 2))), $c, $nf)
  $x0s = 2 + [System.Windows.Forms.TextRenderer]::MeasureText($gr, $bx, $sym, (New-Object System.Drawing.Size 100, 40), $nf).Width
  $sym.Dispose()
  [System.Windows.Forms.TextRenderer]::DrawText($gr, '외치기', $tShout.Font, (New-Object System.Drawing.Point $x0s, ([int](($tShout.Height - $tShout.Font.Height) / 2))), $c, $nf)
})
$tTalk.Add_Paint({
  $gr = $_.Graphics; $nf = [System.Windows.Forms.TextFormatFlags]'NoPrefix,NoPadding,SingleLine'
  $on = [bool]$cfg.talk; $dim = [System.Drawing.Color]::DimGray
  $wht = [System.Drawing.Color]::FromArgb(240, 240, 240); $grn = [System.Drawing.Color]::FromArgb(120, 230, 120); $red = [System.Drawing.Color]::FromArgb(255, 120, 120)
  $sym = New-Object System.Drawing.Font('Segoe UI Symbol', $tTalk.Font.Size)
  $bx = $(if ($on) { '☑' } else { '☐' })
  [System.Windows.Forms.TextRenderer]::DrawText($gr, $bx, $sym, (New-Object System.Drawing.Point 0, ([int](($tTalk.Height - $sym.Height) / 2))), $(if ($on) { $wht } else { $dim }), $nf)
  $x0s = [System.Windows.Forms.TextRenderer]::MeasureText($gr, $bx, $sym, (New-Object System.Drawing.Size 100, 40), $nf).Width
  $sym.Dispose()
  $parts = @(@('대화(', $wht), @('일반', $wht), @(',', $wht), @('파티', $grn), @(',', $wht), @('귓말', $red), @(')', $wht))
  $x = $x0s; $y = [int](($tTalk.Height - $tTalk.Font.Height) / 2)
  foreach ($pt in $parts) {
    $c = $(if ($on) { $pt[1] } else { $dim })
    [System.Windows.Forms.TextRenderer]::DrawText($gr, $pt[0], $tTalk.Font, (New-Object System.Drawing.Point $x, $y), $c, $nf)
    $x += [System.Windows.Forms.TextRenderer]::MeasureText($gr, $pt[0], $tTalk.Font, (New-Object System.Drawing.Size 400, 40), $nf).Width
  }
})
Paint-Toggles

# 내 말 입력 -> 상대 언어로 번역 -> 복사(게임 채팅창에 Ctrl+V)
$tbIn = New-Object System.Windows.Forms.TextBox
$tbIn.Font = $fB; $tbIn.BackColor = [System.Drawing.Color]::FromArgb(40, 42, 48); $tbIn.BorderStyle = 'FixedSingle'
$tbIn.Location = New-Object System.Drawing.Point 8, ($cfg.h - 60); $tbIn.Size = New-Object System.Drawing.Size ($cfg.w - 132), 24; $tbIn.Anchor = 'Left,Right,Bottom'
# [EN] [RU] 버튼: 누르면 그 언어로 번역해서 복사
function New-LangBtn($txt, $xoff) {
  $b = New-Object System.Windows.Forms.Label; $b.Font = $fBtn; $b.Cursor = 'Hand'; $b.TextAlign = 'MiddleCenter'; $b.Text = $txt
  $b.Location = New-Object System.Drawing.Point ($cfg.w - $xoff), ($cfg.h - 60); $b.Size = '38,24'; $b.Anchor = 'Right,Bottom'
  $b.BackColor = [System.Drawing.Color]::FromArgb(55, 58, 66); $b.ForeColor = [System.Drawing.Color]::FromArgb(255, 190, 90)
  return $b
}
$bEn = New-LangBtn 'EN' 84; $bRu = New-LangBtn 'RU' 44
# 영역: 게임 채팅창 위치/크기를 마우스로 지정
$bZone = New-LangBtn '영역' 124; $bZone.ForeColor = [System.Drawing.Color]::Silver
$tip.SetToolTip($bZone, '게임 채팅창 영역 지정 (채팅창 크기/위치를 바꿨을 때)')
$lLang = $bRu
function Out-Lang { if ($LastTalkLang) { return $LastTalkLang } else { return 'ru' } }
function Paint-Lang {
  # Enter 를 눌렀을 때 쓰일 언어(마지막 대화 상대 언어)를 밝게 표시
  $ol = Out-Lang
  $bEn.BackColor = $(if ($ol -eq 'en') { [System.Drawing.Color]::FromArgb(85, 90, 100) } else { [System.Drawing.Color]::FromArgb(55, 58, 66) })
  $bRu.BackColor = $(if ($ol -eq 'ru') { [System.Drawing.Color]::FromArgb(85, 90, 100) } else { [System.Drawing.Color]::FromArgb(55, 58, 66) })
}
$tip.SetToolTip($bEn, '입력한 한글을 영어로 번역해서 복사')
$tip.SetToolTip($bRu, '입력한 한글을 러시아어로 번역해서 복사')
$tip.SetToolTip($tbIn, '한글 입력 후 [EN] / [RU] 클릭 (Enter = 마지막 대화 상대 언어) → 번역해서 복사. 게임 채팅창에서 Ctrl+V')
$PlaceHold = '한글 입력 후 우측 버튼을 누르면 해당 언어로 번역 후 복사됩니다'
$tbIn.ForeColor = [System.Drawing.Color]::White
# 게임의 "Enter to Chat"처럼 빈 칸에 회색 안내 글(입력 칸을 클릭해도 글자를 쓰기 전까지 보임)
$lHint = New-Object System.Windows.Forms.Label
$lHint.Text = $PlaceHold; $lHint.Font = $fHint; $lHint.ForeColor = [System.Drawing.Color]::Gray; $lHint.BackColor = $tbIn.BackColor
$lHint.AutoSize = $false; $lHint.Location = New-Object System.Drawing.Point 4, 2; $lHint.Size = New-Object System.Drawing.Size ($tbIn.Width - 8), 21
$lHint.Anchor = 'Top,Left,Right'; $lHint.Cursor = 'IBeam'; $lHint.AutoEllipsis = $true
$tbIn.Controls.Add($lHint)
# 안내 문구("…복사됩니다")가 끝까지 보이도록 창 폭을 맞춤
$hintW = [System.Windows.Forms.TextRenderer]::MeasureText($PlaceHold, $fHint).Width + 10
$needW = $hintW + 132
# 메뉴 줄(제목 + 외치기~✕ 버튼)도 잘리지 않게: 가장 긴 제목 글 기준
$titleW = [System.Windows.Forms.TextRenderer]::MeasureText('번역(DeepL) · 읽는 중', $fT).Width + 8
$needW = [Math]::Max($needW, $titleW + 412)
$lHint.Add_Click({ $tbIn.Focus() })
$tbIn.Add_TextChanged({ $lHint.Visible = ($tbIn.Text.Length -eq 0) })
function Send-Out($ol) {
  $src = $tbIn.Text.Trim(); if (-not $src -or $src -eq $PlaceHold) { return }
  try {
    $rr = Translate $src 'ko' $ol
    $res = ([string]$rr.text).Trim()
    # 게임 채팅칸이 헷갈리지 않게 줄바꿈·보이지 않는 글자 제거, 일반 텍스트로만 복사
    $res = ($res -replace '[\r\n\t]+', ' ' -replace '[\u200B-\u200F\u2028-\u202F\u2060\uFEFF]', '' -replace '\u00A0', ' ' -replace '\s{2,}', ' ').Trim()
    [System.Windows.Forms.Clipboard]::SetText($res, [System.Windows.Forms.TextDataFormat]::UnicodeText)
    [void]$Shown.Add([pscustomobject]@{ t = ('나 → {0}: {1}  ({2})' -f $(if ($ol -eq 'zh') { 'CN' } else { $ol.ToUpper() }), $res, $src); c = [System.Drawing.Color]::FromArgb(140, 210, 255); k = '' })
    $script:AddN++
    $tbIn.Text = ''
    Dbg ('내 말 번역(' + $ol + '): ' + $src + ' => ' + $res)
    # 게임 창으로 돌아가기 (게임에서 Enter → Ctrl+V → Enter)
    # 자동 키 입력은 게임이 받지 않아서 복사 + 창 전환까지만 함
    if ($LastGameWin -ne [IntPtr]::Zero) { [void][LU4T]::SetForegroundWindow($LastGameWin) }
  } catch {
    Log-Err '내 말 번역' $_
    [void]$Shown.Add([pscustomobject]@{ t = '번역 실패: ' + $_.Exception.Message; c = [System.Drawing.Color]::IndianRed; k = '' }); $script:AddN++
  }
  Refresh-UI
}
$tbIn.Add_KeyDown({ if ($_.KeyCode -eq 'Return') { $_.SuppressKeyPress = $true; Send-Out (Out-Lang) } })
$bEn.Add_Click({ Send-Out 'en' })
$bRu.Add_Click({ Send-Out 'ru' })
# 대화 알림음 켜기/끄기 (♪)
# ♪ 오른쪽 클릭: 소리 바꾸기(차례로 미리 듣기). 폴더의 chat_alert.wav 도 목록에 들어감
$SndList = @()
foreach ($nm in @('chat_alert.wav')) { $pp = Join-Path $PSScriptRoot $nm; if (Test-Path $pp) { $SndList += $pp } }
foreach ($nm in @('Windows Notify System Generic.wav', 'Windows Notify Messaging.wav', 'Windows Notify Email.wav', 'Windows Notify Calendar.wav',
                  'Windows Message Nudge.wav', 'Windows Proximity Notification.wav', 'notify.wav', 'chimes.wav', 'chord.wav', 'ding.wav', 'tada.wav')) {
  $pp = Join-Path $env:WINDIR ('Media\' + $nm); if (Test-Path $pp) { $SndList += $pp }
}
$ChatPlayer = $null; $SndIdx = 0
function Load-Snd($i) {
  if ($SndList.Count -eq 0) { return }
  $script:SndIdx = (($i % $SndList.Count) + $SndList.Count) % $SndList.Count
  try { $script:ChatPlayer = New-Object System.Media.SoundPlayer $SndList[$SndIdx]; $ChatPlayer.Load() } catch { $script:ChatPlayer = $null }
}
$si0 = 0; if ($cfg.sndFile) { for ($q = 0; $q -lt $SndList.Count; $q++) { if ((Split-Path $SndList[$q] -Leaf) -eq $cfg.sndFile) { $si0 = $q } } }
Load-Snd $si0
function Play-Chat { if (-not $cfg.snd) { return }; try { if ($ChatPlayer) { $ChatPlayer.Play() } else { [System.Media.SystemSounds]::Asterisk.Play() } } catch {} }
$bSnd = New-Object System.Windows.Forms.Label
$bSnd.Font = $fT; $bSnd.Size = '32,26'; $bSnd.TextAlign = 'MiddleCenter'; $bSnd.Cursor = 'Hand'; $bSnd.Anchor = 'Bottom,Right'
$bSnd.Location = New-Object System.Drawing.Point ($cfg.w - 148), ($cfg.h - 31)
function Paint-Snd {
  $bSnd.Text = '알림'; $bSnd.ForeColor = $(if ($cfg.snd) { [System.Drawing.Color]::FromArgb(255, 200, 90) } else { [System.Drawing.Color]::DimGray })
  $cur = $(if ($SndList.Count) { [IO.Path]::GetFileNameWithoutExtension($SndList[$SndIdx]) } else { '(Windows 기본)' })
  $tip.SetToolTip($bSnd, $(if ($cfg.snd) { '대화 알림음 켜짐 (클릭: 끄기)' } else { '대화 알림음 꺼짐 (클릭: 켜기)' }) + "`n오른쪽 클릭: 소리 바꾸기  ·  지금: " + $cur)
}
$bSnd.Add_MouseUp({
  if ($_.Button -eq 'Right') {
    Load-Snd ($SndIdx + 1); $cfg.sndFile = $(if ($SndList.Count) { Split-Path $SndList[$SndIdx] -Leaf } else { '' })
    try { if ($ChatPlayer) { $ChatPlayer.Play() } } catch {}
    $nm = [IO.Path]::GetFileNameWithoutExtension($cfg.sndFile)
    $State = '알림음: ' + $nm; $lTitle.Text = '알림음: ' + $nm
    Paint-Snd; Save-Cfg
  } elseif ($_.Button -eq 'Left') { $cfg.snd = -not $cfg.snd; Paint-Snd; Save-Cfg; if ($cfg.snd) { Play-Chat } }
})
Paint-Snd
# 지우기: 번역 창에 쌓인 줄을 모두 지움(이미 본 채팅은 다시 번역하지 않음)
$bClr = New-Object System.Windows.Forms.Label
$bClr.Font = $fT; $bClr.ForeColor = [System.Drawing.Color]::Silver; $bClr.Text = '지우기'; $bClr.Size = '40,26'; $bClr.TextAlign = 'MiddleCenter'; $bClr.Cursor = 'Hand'; $bClr.Anchor = 'Bottom,Right'
$bClr.Location = New-Object System.Drawing.Point ($cfg.w - 112), ($cfg.h - 31)
$tip.SetToolTip($bClr, '지우기: 번역 창 내용 모두 지우기')
$bClr.Add_Click({ $Shown.Clear(); $script:AddN++; $script:LastOrig = ''; $lBody.Invalidate() })
# 작게(접기) 버튼: 제목줄만 남기고 접기 / 다시 펼치기
$bMini = New-Object System.Windows.Forms.Label
$bMini.Font = $fT; $bMini.ForeColor = [System.Drawing.Color]::Silver; $bMini.Size = '20,26'; $bMini.TextAlign = 'MiddleCenter'; $bMini.Cursor = 'Hand'; $bMini.Anchor = 'Bottom,Right'
$bMini.Location = New-Object System.Drawing.Point ($cfg.w - 68), ($cfg.h - 31)
$tip.SetToolTip($bMini, '작게(접기) / 펼치기   ·   Ctrl+Shift+T : 숨기기 / 보이기')
$MiniNew = 0
function Set-Mini($on) {
  $cfg.mini = [bool]$on
  foreach ($c in @($lBody, $tbIn, $bEn, $bRu)) { $c.Visible = -not $on }
  # 아래쪽(메뉴 줄)은 그 자리에 두고 위쪽 번역 칸만 접고 펼침
  $bot = $form.Bottom
  if ($on) { $form.Height = 34; $bMini.Text = '▢' } else { $form.Height = [Math]::Max(150, $cfg.h); $bMini.Text = '—'; $script:MiniNew = 0 }
  $form.Top = $bot - $form.Height
  Save-CfgRaw
}
$bMini.Add_Click({ Set-Mini (-not $cfg.mini); Refresh-UI })
$lTitle.Add_DoubleClick({ Set-Mini (-not $cfg.mini); Refresh-UI })
# ---------- 읽을 영역 지정: 게임 화면을 찍어 띄우고 마우스로 드래그 ----------
# $cl = @{ x; y; w; h } (게임 창 안쪽의 화면 좌표). 돌려주는 값: 게임 창 기준 비율 @(왼쪽, 위, 너비, 높이) / 취소하면 $null
function Pick-Zone($cl, $guide, $cur) {
  if (-not $cl -or $cl.w -le 0 -or $cl.h -le 0) { [System.Windows.Forms.MessageBox]::Show('게임 창을 찾지 못했어요. 게임을 한 번 앞에 띄운 뒤 다시 눌러 주세요.', '영역 지정') | Out-Null; return $null }
  $shot = New-Object System.Drawing.Bitmap $cl.w, $cl.h
  $g0 = [System.Drawing.Graphics]::FromImage($shot); $g0.CopyFromScreen($cl.x, $cl.y, 0, 0, $shot.Size); $g0.Dispose()
  $pf = New-Object System.Windows.Forms.Form
  $pf.FormBorderStyle = 'None'; $pf.StartPosition = 'Manual'; $pf.TopMost = $true; $pf.ShowInTaskbar = $false
  $pf.Location = New-Object System.Drawing.Point $cl.x, $cl.y; $pf.Size = New-Object System.Drawing.Size $cl.w, $cl.h
  $pf.Cursor = [System.Windows.Forms.Cursors]::Cross; $pf.KeyPreview = $true
  $pf.GetType().GetProperty('DoubleBuffered', [Reflection.BindingFlags]'NonPublic,Instance').SetValue($pf, $true, $null)
  $st = @{ a = $null; b = $null; res = $null }
  if ($cur) { $st.a = New-Object System.Drawing.Point ([int]($cur[0] * $cl.w)), ([int]($cur[1] * $cl.h)); $st.b = New-Object System.Drawing.Point ([int](($cur[0] + $cur[2]) * $cl.w)), ([int](($cur[1] + $cur[3]) * $cl.h)) }
  $fnt = UIFont 14 -bold
  $pf.Add_Paint({
    $gg = $_.Graphics; $gg.DrawImage($shot, 0, 0)
    $dim = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(120, 0, 0, 0))
    $gg.FillRectangle($dim, 0, 0, $pf.Width, $pf.Height)
    if ($st.a -and $st.b) {
      $rx = [Math]::Min($st.a.X, $st.b.X); $ry = [Math]::Min($st.a.Y, $st.b.Y); $rw = [Math]::Abs($st.b.X - $st.a.X); $rh = [Math]::Abs($st.b.Y - $st.a.Y)
      if ($rw -gt 0 -and $rh -gt 0) {
        $gg.DrawImage($shot, (New-Object System.Drawing.Rectangle $rx, $ry, $rw, $rh), (New-Object System.Drawing.Rectangle $rx, $ry, $rw, $rh), [System.Drawing.GraphicsUnit]::Pixel)
        $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(255, 200, 60)), 3; $gg.DrawRectangle($pen, $rx, $ry, $rw, $rh); $pen.Dispose()
      }
    }
    $msg = $guide + "`n마우스로 드래그해서 영역을 정한 뒤 Enter 또는 마우스 오른쪽 클릭으로 저장"
    $sz = $gg.MeasureString($msg, $fnt)
    $gg.FillRectangle((New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(210, 20, 22, 26))), 20, 20, $sz.Width + 20, $sz.Height + 14)
    $gg.DrawString($msg, $fnt, [System.Drawing.Brushes]::Gold, 30, 27)
    $dim.Dispose()
  })
  $pf.Add_MouseDown({ if ($_.Button -eq 'Left') { $st.a = $_.Location; $st.b = $_.Location; $pf.Invalidate() } elseif ($_.Button -eq 'Right') { $st.res = 'ok'; $pf.Close() } })
  $pf.Add_MouseMove({ if ($_.Button -eq 'Left' -and $st.a) { $st.b = $_.Location; $pf.Invalidate() } })
  $pf.Add_KeyDown({ if ($_.KeyCode -eq 'Return') { $st.res = 'ok'; $pf.Close() } })
  # 영역 창에 키보드 초점이 안 와도(게임이 잡고 있어도) Enter가 먹도록 키 상태를 직접 확인
  $kt = New-Object System.Windows.Forms.Timer; $kt.Interval = 40; $st.k0 = $true
  $kt.Add_Tick({
    $ent = ([int][LU4K.Key]::GetAsyncKeyState(13) -band 0x8000) -ne 0
    if ($st.k0) { if (-not $ent) { $st.k0 = $false }; return }
    if ($ent) { $kt.Stop(); $st.res = 'ok'; $pf.Close() }
  })
  $pf.Add_Shown({ $pf.Activate(); [void]$pf.Focus(); try { $kt.Start() } catch {} })
  $pf.Add_Deactivate({ try { $pf.Activate() } catch {} })
  [void]$pf.ShowDialog()
  try { $kt.Stop(); $kt.Dispose() } catch {}
  $shot.Dispose(); $fnt.Dispose()
  if ($st.res -ne 'ok' -or -not $st.a -or -not $st.b) { return $null }
  $rx = [Math]::Max(0, [Math]::Min($st.a.X, $st.b.X)); $ry = [Math]::Max(0, [Math]::Min($st.a.Y, $st.b.Y))
  $rw = [Math]::Min($cl.w - $rx, [Math]::Abs($st.b.X - $st.a.X)); $rh = [Math]::Min($cl.h - $ry, [Math]::Abs($st.b.Y - $st.a.Y))
  if ($rw -lt 40 -or $rh -lt 30) { return $null }
  return @([Math]::Round($rx / $cl.w, 4), [Math]::Round($ry / $cl.h, 4), [Math]::Round($rw / $cl.w, 4), [Math]::Round($rh / $cl.h, 4))
}

$bZone.Add_Click({
  $h = $LastGameWin
  if ($h -eq [IntPtr]::Zero) { [System.Windows.Forms.MessageBox]::Show('게임 창을 한 번 앞에 띄운 뒤 다시 눌러 주세요.', '영역 지정') | Out-Null; return }
  $cr = New-Object LU4T+RECT; [void][LU4T]::GetClientRect($h, [ref]$cr)
  $p0 = New-Object LU4T+POINT; [void][LU4T]::ClientToScreen($h, [ref]$p0)
  [void][LU4T]::SetForegroundWindow($h); Start-Sleep -Milliseconds 400
  $form.Hide(); Start-Sleep -Milliseconds 150
  $z = Pick-Zone @{ x = $p0.X; y = $p0.Y; w = $cr.R; h = $cr.B } '채팅 번역: 대화창과 시스템창 함께 모두 영역을 지정하세요.' $ZoneChat
  $form.Show()
  if ($z) { $script:ZoneChat = $z; $cfg.zone = $z; Save-Cfg; $script:LastSig = ''; Dbg ('영역 지정: ' + ($z -join ', ')); $lTitle.Text = '영역 저장됨' }
})
$bUpd = New-Object System.Windows.Forms.Label
$bUpd.Font = $fT; $bUpd.Text = 'UP'; $bUpd.ForeColor = [System.Drawing.Color]::Silver
$bUpd.Size = '28,26'; $bUpd.TextAlign = 'MiddleCenter'; $bUpd.Cursor = 'Hand'; $bUpd.Anchor = 'Bottom,Right'
$bUpd.Location = New-Object System.Drawing.Point ($cfg.w - 180), ($cfg.h - 31)
$tip.SetToolTip($bUpd, '업데이트 (새로 받은 압축 파일로, 설정은 그대로)')
$tip.SetToolTip($lTitle, 'made by DoZ')
# 업데이트: 받은 새 압축 파일로 업데이트(이 프로그램은 닫고, 끝나면 다시 켬)
function Start-Update {
  $up = Join-Path $PSScriptRoot 'install_update.ps1'
  if (-not (Test-Path $up)) { [System.Windows.Forms.MessageBox]::Show('install_update.ps1 이 없어요. 새 압축 파일을 한 번 풀어서 덮어써 주세요.', '업데이트') | Out-Null; return }
  $ok = [System.Windows.Forms.MessageBox]::Show("최신 버전을 받아서 업데이트할까요?`n(설정은 그대로 남고, 끝나면 프로그램이 다시 켜져요)", '업데이트', 'YesNo', 'Question')
  if ($ok -ne 'Yes') { return }
  Start-Process powershell -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $up + '"'), '-FromApp') -WorkingDirectory $PSScriptRoot
  $form.Close()
}
$bUpd.Add_Click({ Start-Update })
$form.Controls.AddRange(@($lTitle, $bClr, $tShout, $tTalk, $bSnd, $bUpd, $bMini, $bPause, $bClose, $lBody, $tbIn, $bEn, $bRu, $bZone))
# 모든 버튼을 붙인 뒤에 폭을 맞춰야 오른쪽 버튼들이 함께 따라 움직임(잘림 방지)
$form.MinimumSize = New-Object System.Drawing.Size $needW, 34
$form.Width = $needW
foreach ($bc in @($tShout, $tTalk, $bUpd, $bSnd, $bClr, $bMini, $bPause, $bClose)) { $bc.BringToFront() }
$fMenuS = UIFont 10 -bold
# UP / 알림 / 지우기 글자: 대화보다 한 단계 작게 직접 그림
$MenuTxt = @{}
foreach ($mb in @($bUpd, $bSnd, $bClr)) {
  $mb.Add_Paint({
    param($sd, $ev)
    $tx = [string]$sd.Tag; if (-not $tx) { return }
    $nf = [System.Windows.Forms.TextFormatFlags]'NoPrefix,NoPadding,SingleLine'
    $ev.Graphics.Clear($sd.Parent.BackColor)
    $sz = [System.Windows.Forms.TextRenderer]::MeasureText($ev.Graphics, $tx, $fMenuS, (New-Object System.Drawing.Size 200, 40), $nf)
    $px = [int](($sd.Width - $sz.Width) / 2); $py = [int](($sd.Height - $fMenuS.Height) / 2)
    [System.Windows.Forms.TextRenderer]::DrawText($ev.Graphics, $tx, $fMenuS, (New-Object System.Drawing.Point $px, $py), $sd.ForeColor, $nf)
  })
  $mb.Tag = $mb.Text; $mb.Text = ''
  $mb.Add_TextChanged({ param($sd, $ev) if ($sd.Text) { $sd.Tag = $sd.Text; $sd.Text = ''; $sd.Invalidate() } })
}   # 제목 글이 버튼을 가리지 않게
# 아래 메뉴: 실제 글자 폭을 재서 버튼 크기·간격을 정함 (PC 화면 배율이 달라도 글자가 안 잘리고 안 붙게)
$nfM = [System.Windows.Forms.TextFormatFlags]'NoPrefix,NoPadding,SingleLine'
$gM = $tTalk.CreateGraphics()   # 버튼을 그릴 때와 같은 방식으로 재야 폭이 정확함
function MW($t, $f) { return [int][System.Windows.Forms.TextRenderer]::MeasureText($gM, $t, $f, (New-Object System.Drawing.Size 400, 40), $nfM).Width }
$symF = New-Object System.Drawing.Font('Segoe UI Symbol', $fT.Size); $boxW = MW '☑' $symF; $symF.Dispose()
$wShout = 2 + $boxW + (MW '외치기' $fT) + 2
$wTalk = $boxW + 2; foreach ($pt in @('대화(', '일반', ',', '파티', ',', '귓말', ')')) { $wTalk += (MW $pt $fT) }
$wUpd = (MW 'UP' $fMenuS) + 6; $wSnd = (MW '알림' $fMenuS) + 6; $wClr = (MW '지우기' $fMenuS) + 6
$xr = $bMini.Left - 12
foreach ($pr in @(@($bClr, $wClr, 12), @($bSnd, $wSnd, 12), @($bUpd, $wUpd, 12), @($tTalk, $wTalk, 12), @($tShout, $wShout, 12))) {
  $c = $pr[0]; $ww = [int]$pr[1]; $c.Width = $ww; $c.Left = $xr - $ww; $xr = $c.Left - [int]$pr[2]
}
try { $gM.Dispose() } catch {}
$lTitle.Width = [Math]::Max(40, $xr - $lTitle.Left)
$needW = [Math]::Max($hintW + 132, $lTitle.Left + $titleW + ($form.ClientSize.Width - $xr))
$form.MinimumSize = New-Object System.Drawing.Size $needW, 34
if ($form.Width -ne $needW) { $form.Width = $needW }
# 메뉴 사이 구분선 | (외치기 | 대화 | UP | 알림 | 지우기 | —): 버튼 사이 가운데에 직접 그림
$form.Add_Paint({
  $g = $_.Graphics; $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(95, 95, 100)), 1
  $row = @($tShout, $tTalk, $bUpd, $bSnd, $bClr, $bMini)
  for ($q = 0; $q -lt $row.Count - 1; $q++) {
    $a1 = $row[$q]; $a2 = $row[$q + 1]; if (-not $a1.Visible -or -not $a2.Visible) { continue }
    $xm = [int](($a1.Right + $a2.Left) / 2); $g.DrawLine($pen, $xm, $a1.Top + 7, $xm, $a1.Bottom - 7)
  }
  $pen.Dispose()
})
$form.Add_Resize({ $form.Invalidate() })
Dbg ('메뉴 폭 재기: box=' + $boxW + ' 외치기=' + $wShout + ' 대화=' + $wTalk + ' UP=' + $wUpd + ' 알림=' + $wSnd + ' 지우기=' + $wClr + ' 창폭=' + $needW + ' 글꼴=' + $fT.Name + '/' + $fT.SizeInPoints)
$form.Add_Shown({ try { Dbg ('메뉴 위치: 창=' + $form.Width + ' 제목=' + $lTitle.Left + '+' + $lTitle.Width + ' 외치기=' + $tShout.Left + '+' + $tShout.Width + ' 대화=' + $tTalk.Left + '+' + $tTalk.Width + ' UP=' + $bUpd.Left + '+' + $bUpd.Width + ' 알림=' + $bSnd.Left + '+' + $bSnd.Width + ' 지우기=' + $bClr.Left + '+' + $bClr.Width + ' 접기=' + $bMini.Left) } catch {} })

# 전체 숨기기/보이기 단축키 (Ctrl+Shift+T)
try {
  Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @"
using System; using System.Windows.Forms; using System.Runtime.InteropServices;
public class LU4HotKey : NativeWindow {
  [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
  [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
  public event EventHandler Pressed;
  public bool Ok;
  public LU4HotKey(uint mod, uint vk) { CreateHandle(new CreateParams()); Ok = RegisterHotKey(Handle, 1, mod, vk); }
  protected override void WndProc(ref Message m) { if (m.Msg == 0x0312 && Pressed != null) Pressed(this, EventArgs.Empty); base.WndProc(ref m); }
  public void Free() { UnregisterHotKey(Handle, 1); DestroyHandle(); }
}
"@
  $HotKey = New-Object LU4HotKey 6, 0x54
  $HotKey.add_Pressed({ if ($form.Visible) { $form.Hide() } else { $form.Show(); $form.TopMost = $true; $form.Activate() } })
  $form.Add_FormClosed({ try { $HotKey.Free() } catch {} })
  if (-not $HotKey.Ok) { Dbg '단축키 Ctrl+Shift+T 등록 실패(다른 프로그램이 사용 중)' }
} catch { Log-Err '단축키' $_ }
$form.Add_Shown({
  # 창이 화면 밖으로 나가 있으면 화면 안으로
  try {
    $wa = [System.Windows.Forms.Screen]::FromPoint($form.Location).WorkingArea
    if ($form.Width -gt $wa.Width) { $form.Width = $wa.Width }
    if ($form.Right -gt $wa.Right) { $form.Left = $wa.Right - $form.Width }
    if ($form.Left -lt $wa.Left) { $form.Left = $wa.Left }
    if ($form.Bottom -gt $wa.Bottom) { $form.Top = $wa.Bottom - $form.Height }
    if ($form.Top -lt $wa.Top) { $form.Top = $wa.Top }
  } catch {}
  Set-Mini $cfg.mini
  $form.ActiveControl = $lBody
})


# 끌어서 옮기기 / 오른쪽 아래 모서리 끌어서 크기 조절
$drag = { if ($_.Button -eq 'Left') { [void][LU4T]::ReleaseCapture(); [void][LU4T]::SendMessage($form.Handle, 0xA1, 2, 0) } }
$form.Add_MouseDown($drag); $lTitle.Add_MouseDown($drag); $lTitle.Add_MouseUp({ if ($_.Button -eq 'Right') { Ask-DeepL; Refresh-UI } }); $lBody.Add_MouseDown({
  if ($_.Button -eq 'Left') {
    $nearCorner = ($_.X -gt $lBody.Width - 18 -and $_.Y -gt $lBody.Height - 18)
    [void][LU4T]::ReleaseCapture(); [void][LU4T]::SendMessage($form.Handle, 0xA1, $(if ($nearCorner) { 17 } else { 2 }), 0)
  } })
$form.Add_ResizeEnd({ Save-Cfg })
$Paused = $false
$bPause.Add_Click({ $script:Paused = -not $Paused; $bPause.Text = $(if ($Paused) { '▶' } else { 'Ⅱ' }); Refresh-UI })
$bClose.Add_Click({ $form.Close() })
$form.Add_FormClosing({ try { Save-Cfg } catch {} })
$form.Add_Shown({
  # 디스코드 화면 공유 등에도 번역 창이 보이게(화면 캡처 제외 해제)
  try { [void][LU4T]::SetWindowDisplayAffinity($form.Handle, 0) } catch {}
})

function Refresh-UI {
  try { Paint-Lang } catch {}
  $st = if ($Paused) { '일시정지' } else { $State }
  $miss = @(); if (-not $HasEn) { $miss += '영어 OCR 없음' }; if (-not $HasRu) { $miss += '러시아어 OCR 없음' }
  $lTitle.Text = '번역(' + $Engine + ') · ' + $(if ($cfg.mini -and $MiniNew -gt 0) { '새 번역 ' + $MiniNew + '줄' } else { $st }) + $(if ($miss.Count) { ' (' + ($miss -join ', ') + ')' } else { '' })
  if ($AddN -ne $DrawnN) {
    $script:DrawnN = $AddN
    $dn = $Shown.Count - $ShownLastN
    if ($ScrollOff -gt 0 -and $dn -gt 0) { $script:ScrollOff += $dn }   # 위로 올려 보는 중이면 위치 유지
    if ($Shown.Count -eq 0) { $script:ScrollOff = 0 }
    $script:ShownLastN = $Shown.Count
    Sync-Scroll; $lBody.Invalidate()
  }
  if ($LastOrig -and $LastOrig -ne $TipOrig) { $script:TipOrig = $LastOrig; $tip.SetToolTip($lBody, '마지막 원문: ' + $LastOrig) }
}

$Busy = $false; $DrawnN = -1; $TipOrig = ''
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = $TickMs
$timer.Add_Tick({
  if ($Busy -or $Paused) { Refresh-UI; return }
  $script:Busy = $true
  try { Tick } catch { Log-Err 'Tick' $_ } finally { $script:Busy = $false }
  try { Refresh-UI } catch {}
})
$timer.Start()
Refresh-UI
[System.Windows.Forms.Application]::Run($form)
