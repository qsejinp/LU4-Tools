﻿# 윈도우 러시아어 글자 인식(OCR) 기능 설치 (관리자 권한 필요)
Write-Host '러시아어 OCR 기능을 설치하는 중입니다. 잠시 기다려 주세요...'
try {
  $r = Add-WindowsCapability -Online -Name 'Language.OCR~~~ru-RU~0.0.1.0'
  Write-Host '설치 완료. 채팅 번역을 다시 실행해 주세요.'
} catch { Write-Host ('설치 실패: ' + $_.Exception.Message) }
Read-Host '엔터를 누르면 닫힙니다'
