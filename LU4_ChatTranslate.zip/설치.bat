@echo off
if exist "%~dp0install.ps1" goto run
chcp 65001 >nul
echo 압축을 먼저 풀어 주세요. [압축 풀기] 후 풀린 폴더의 설치.bat 을 다시 실행하세요.
pause
exit /b
:run
powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0install.ps1"
