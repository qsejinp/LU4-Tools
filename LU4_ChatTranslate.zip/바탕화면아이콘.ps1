﻿# made by DoZ - 바탕화면에 파란 아이콘 바로가기 만들기 (아이콘이 없거나 회색일 때 실행)
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (Test-Path (Join-Path $here 'LU4_ChatTranslate.ps1')) { $prog = 'LU4_ChatTranslate'; $title = 'LU4 채팅 번역' }
elseif (Test-Path (Join-Path $here 'LU4_GrindMeter.ps1')) { $prog = 'LU4_GrindMeter'; $title = 'LU4 사냥지표' }
else { [System.Windows.Forms.MessageBox]::Show('이 폴더에서 프로그램을 찾지 못했어요. C:\LU4_Tools 안의 프로그램 폴더에 넣고 실행하세요.','바로가기 만들기') | Out-Null; exit }
$sh = New-Object -ComObject WScript.Shell
$vbs = Join-Path $here ($prog + '_run.vbs'); $ps1b = Join-Path $here ($prog + '.ps1'); $ico = Join-Path $here ($prog + '.ico')
$ws = Join-Path $env:WINDIR 'System32\wscript.exe'
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'LU4 Tools'; New-Item -ItemType Directory -Path $menu -Force | Out-Null
$desks = New-Object System.Collections.ArrayList
$rd = [Environment]::GetFolderPath('Desktop'); if ($rd -and (Test-Path $rd)) { [void]$desks.Add($rd) }
try { Get-ChildItem $env:USERPROFILE -Directory -Recurse -Depth 2 -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'Desktop' -or $_.Name -eq '바탕 화면' } | ForEach-Object { if (-not $desks.Contains($_.FullName)) { [void]$desks.Add($_.FullName) } } } catch {}
if ($desks.Count -eq 0) { [void]$desks.Add((Join-Path $env:USERPROFILE 'Desktop')) }
$made = 0
$paths = @(); foreach ($dk in $desks) { $paths += (Join-Path $dk ($title + '.lnk')) }
$paths += (Join-Path $menu ($title + '.lnk'))
foreach ($lnkPath in $paths) {
  $l = $sh.CreateShortcut($lnkPath)
  if ((Test-Path $ws) -and (Test-Path $vbs)) { $l.TargetPath = $ws; $l.Arguments = '"' + $vbs + '"' }
  else { $l.TargetPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'; $l.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $ps1b + '"'; $l.WindowStyle = 7 }
  $l.WorkingDirectory = $here
  if (Test-Path $ico) { $l.IconLocation = $ico + ',0' }
  $l.Description = $title + ' (made by DoZ)'
  $l.Save(); $made++
}
[System.Windows.Forms.MessageBox]::Show(("바탕화면에 '" + $title + "' 아이콘을 만들었어요. (" + $made + "곳)`n회색으로 보이면 F5(새로 고침) 하거나 잠시 후 파란 아이콘으로 바뀝니다."), '바로가기 만들기') | Out-Null
