﻿# made by DoZ
# LU4 업데이트: 새로 받은 압축 파일(LU4_ChatTranslate.zip / LU4_GrindMeter.zip)로 프로그램 파일만 바꿈
# 내 설정(창 위치, 영역, DeepL 키, 혈맹 명단, 용어, 소리 등)은 그대로 둠
param([switch]$FromApp)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Windows.Forms
function Show-Msg($t) { if ($FromApp) { [System.Windows.Forms.MessageBox]::Show($t, ('업데이트 - ' + $prog)) | Out-Null } }
$here = $PSScriptRoot
$prog = $(if (Test-Path (Join-Path $here 'LU4_ChatTranslate.ps1')) { 'LU4_ChatTranslate' } elseif (Test-Path (Join-Path $here 'LU4_GrindMeter.ps1')) { 'LU4_GrindMeter' } else { '' })
if (-not $prog) { Write-Host '이 폴더에서 프로그램을 찾지 못했어요. 업데이트.bat 을 프로그램 폴더 안에서 실행해 주세요.'; Read-Host '엔터를 누르면 닫힙니다'; exit }
function Start-Prog { $ps = Join-Path $here ($prog + '.ps1'); Start-Process powershell -WindowStyle Hidden -WorkingDirectory $here -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-WindowStyle', 'Hidden', '-File', ('"' + $ps + '"')) }
function Launch($d) {
  $v = Join-Path $d ($prog + '_run.vbs'); $wsx = Join-Path $env:WINDIR 'System32\wscript.exe'; $ps = Join-Path $d ($prog + '.ps1')
  if ((Test-Path $wsx) -and (Test-Path $v)) { Start-Process -FilePath $wsx -ArgumentList ('"' + $v + '"') -WorkingDirectory $d }
  else { Start-Process powershell -WindowStyle Hidden -WorkingDirectory $d -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-WindowStyle', 'Hidden', '-File', ('"' + $ps + '"')) }
}
function Make-Shortcuts($dir, $title) {
  $sh = New-Object -ComObject WScript.Shell
  $vbs = Join-Path $dir ($prog + '_run.vbs'); $ps1b = Join-Path $dir ($prog + '.ps1'); $ico = Join-Path $dir ($prog + '.ico')
  $ws = Join-Path $env:WINDIR 'System32\wscript.exe'
  $desk = [Environment]::GetFolderPath('Desktop'); $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'LU4 Tools'
  New-Item -ItemType Directory -Path $menu -Force | Out-Null
  foreach ($lnkPath in @((Join-Path $desk ($title + '.lnk')), (Join-Path $menu ($title + '.lnk')))) {
    $l = $sh.CreateShortcut($lnkPath)
    if ((Test-Path $ws) -and (Test-Path $vbs)) { $l.TargetPath = $ws; $l.Arguments = '"' + $vbs + '"' }
    else { $l.TargetPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'; $l.Arguments = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $ps1b + '"'; $l.WindowStyle = 7 }
    $l.WorkingDirectory = $dir
    if (Test-Path $ico) { $l.IconLocation = $ico + ',0' }
    $l.Description = $title + ' (made by DoZ)'; $l.Save()
  }
  $u = $sh.CreateShortcut((Join-Path $menu ($title + ' 제거.lnk'))); $u.TargetPath = Join-Path $dir '제거.bat'; $u.WorkingDirectory = $dir; $u.Save()
  $f = $sh.CreateShortcut((Join-Path $menu ($title + ' 폴더 열기.lnk'))); $f.TargetPath = $dir; $f.Save()
}
function Finish-Update($changed) {
  $title = @{ LU4_ChatTranslate = 'LU4 채팅 번역'; LU4_GrindMeter = 'LU4 사냥지표' }[$prog]
  $target = Join-Path 'C:\LU4_Tools' $prog
  $runDir = $here; $migrated = $false; $migErr = ''
  try {
    if ($here.TrimEnd('\') -ne $target.TrimEnd('\')) {
      New-Item -ItemType Directory -Path $target -Force | Out-Null
      Get-ChildItem -Path $here -Force | Where-Object { $_.Name -notlike '_backup_*' } | ForEach-Object {
        $to = Join-Path $target $_.Name
        if (($keep -contains $_.Name -or $_.Name -match $keepPat) -and (Test-Path $to)) { return }
        Copy-Item $_.FullName -Destination $to -Recurse -Force
      }
      Make-Shortcuts $target $title
      if ($here -like '*\AppData\Local\LU4_Tools\*') { Start-Process cmd -WindowStyle Hidden -WorkingDirectory $env:TEMP -ArgumentList ('/c timeout /t 3 /nobreak >nul & rmdir /s /q "' + $here + '"') }
      $runDir = $target; $migrated = $true
    }
  } catch { $runDir = $here; $migErr = $_.Exception.Message }
  # 바탕화면 아이콘이 없으면 다시 만들기 (이동하지 않은 경우에도 확인)
  try {
    $deskLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) ($title + '.lnk')
    if (-not (Test-Path $deskLnk)) { Make-Shortcuts $runDir $title }
  } catch {}
  if ($FromApp) {
    if ($migrated) { Show-Msg ("업데이트 완료! 프로그램을 C:\LU4_Tools 폴더로 옮겼어요.`n앞으로는 바탕화면의 '" + $title + "' 아이콘으로 켜세요.`n확인을 누르면 새 위치에서 다시 켜져요.") }
    elseif ($migErr) { Show-Msg ("업데이트는 됐는데 C:\LU4_Tools 로 옮기지 못했어요(권한 문제일 수 있어요). 지금 위치에서 그대로 켤게요.`n" + $migErr) }
    elseif ($null -eq $changed) { Show-Msg '이미 최신 버전이에요.' }
    else { Show-Msg ("업데이트 완료! (파일 " + $changed + " 개 바꿈, 내 설정은 그대로)`n확인을 누르면 프로그램이 다시 켜져요.") }
    Launch $runDir
  } else { Read-Host '엔터를 누르면 닫힙니다. 프로그램을 다시 켜 주세요' }
}

Write-Host ("[$prog] 업데이트 확인 중...  (made by DoZ)")
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# 1) 제작자가 올려 둔 곳(GitHub)에서 최신 파일을 자동으로 받음
#    update_source.txt : 첫 줄에 "GitHub아이디/저장소이름" (예: DoZ/LU4-Tools) 또는 zip 파일의 직접 주소
$netZip = $null
$srcFile = Join-Path $here 'update_source.txt'
$src = ''; if (Test-Path $srcFile) { $src = ((Get-Content $srcFile -Encoding UTF8) | Where-Object { $_.Trim() -and -not $_.Trim().StartsWith('#') } | Select-Object -First 1); if ($src) { $src = $src.Trim() } }
if ($src) {
  $url = $(if ($src -match '^https?://') { $src -replace '\{prog\}', $prog } else { 'https://github.com/' + $src.Trim('/') + '/releases/latest/download/' + $prog + '.zip' })
  # GitHub 저장 사본(캐시) 때문에 예전 파일을 받지 않도록, 가장 최근 올린 버전 번호(커밋)를 물어서 그 버전 파일을 정확히 받음
  if ($url -match '^https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/main/(.+)$') {
    $gOwn = $Matches[1]; $gRepo = $Matches[2]; $gPath = $Matches[3]
    try {
      $wa = New-Object System.Net.WebClient; $wa.Headers.Add('User-Agent', 'LU4-Updater'); $wa.Headers.Add('Accept', 'application/vnd.github.sha')
      $sha = ($wa.DownloadString('https://api.github.com/repos/' + $gOwn + '/' + $gRepo + '/commits/main?t=' + [DateTime]::UtcNow.Ticks)).Trim(); $wa.Dispose()
      if ($sha -match '^[0-9a-f]{40}$') { $url = 'https://raw.githubusercontent.com/' + $gOwn + '/' + $gRepo + '/' + $sha + '/' + $gPath }
    } catch { Write-Host ('최신 버전 번호 확인 실패(그냥 받음): ' + $_.Exception.Message) }
  }
  $netZip = Join-Path $env:TEMP ($prog + '_update.zip')
  Write-Host ('받는 중: ' + $url)
  try {
    $url2 = $url + $(if ($url.Contains('?')) { '&' } else { '?' }) + 't=' + [DateTime]::UtcNow.Ticks   # GitHub 캐시를 피해서 방금 올린 최신 파일을 받음
    $wc = New-Object System.Net.WebClient; $wc.CachePolicy = New-Object System.Net.Cache.RequestCachePolicy ([System.Net.Cache.RequestCacheLevel]::NoCacheNoStore); $wc.Headers.Add('User-Agent', 'LU4-Updater'); $wc.Headers.Add('Cache-Control', 'no-cache'); $wc.DownloadFile($url2, $netZip); $wc.Dispose()
    Write-Host '받기 완료.'
  } catch { Write-Host ('인터넷에서 받기 실패: ' + $_.Exception.Message); $netZip = $null }
}
# 찾는 곳: 이 폴더, 다운로드 폴더, 바탕화면 (가장 최근 파일)
$dl = Join-Path $env:USERPROFILE 'Downloads'; $dt = [Environment]::GetFolderPath('Desktop')
$cands = @()
foreach ($d in @($here, $dl, $dt)) { if ($d -and (Test-Path $d)) { $cands += @(Get-ChildItem -Path $d -Filter ($prog + '*.zip') -File -ErrorAction SilentlyContinue) } }
$zip = $cands | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($netZip -and (Test-Path $netZip)) { $zip = Get-Item $netZip }
# 이미 최신인지 확인: 압축 안의 프로그램 파일이 지금 폴더의 파일과 모두 똑같으면 바꿀 필요 없음
$keep = @('deepl_key.txt', 'clan_members.txt', 'chat_glossary.txt', 'loot_alert.wav', 'chat_alert.wav')
$keepPat = '(_cfg\.json|_error\.log|_debug\.log)$'
if ($zip) {
  $same = $true
  try {
    $zz = [System.IO.Compression.ZipFile]::OpenRead($zip.FullName)
    try {
      $sha = [System.Security.Cryptography.SHA256]::Create()
      foreach ($en in $zz.Entries) {
        if (-not $en.Name) { continue }
        $lf = Split-Path ($en.FullName -replace '/', '\') -Leaf
        if ($keep -contains $lf -or $lf -match $keepPat) { continue }
        $cp = Join-Path $here ($en.FullName -replace '/', '\')
        if (-not (Test-Path $cp)) { $same = $false; break }
        $ms = New-Object System.IO.MemoryStream; $st0 = $en.Open(); $st0.CopyTo($ms); $st0.Dispose()
        $h1 = [BitConverter]::ToString($sha.ComputeHash($ms.ToArray())); $h2 = [BitConverter]::ToString($sha.ComputeHash([System.IO.File]::ReadAllBytes($cp)))
        if ($h1 -ne $h2) { $same = $false; break }
      }
    } finally { $zz.Dispose() }
  } catch { $same = $false }
  if ($same) {
    Write-Host ''; Write-Host '이미 최신 버전이에요.'
    if ($netZip) { Remove-Item $netZip -ErrorAction SilentlyContinue }
    Show-Msg '이미 최신 버전이에요.'
    Finish-Update $null
    exit
  }
}
if (-not $zip) {
  Write-Host ''
  Write-Host ("업데이트 파일($prog.zip)을 찾지 못했어요.")
  Write-Host '받은 압축 파일을 이 폴더나 다운로드 폴더, 바탕화면에 두고 다시 실행해 주세요.'
  if ($FromApp) { Show-Msg '업데이트 파일을 받지 못했어요. 인터넷 연결을 확인하고 다시 눌러 주세요.' } else { Read-Host '엔터를 누르면 닫힙니다' }
  $rb0 = Join-Path $here ($prog + '_run.bat'); if ($FromApp -and (Test-Path $rb0)) { Start-Prog }
  exit
}
Write-Host ("찾음: " + $zip.FullName + "  (" + $zip.LastWriteTime.ToString('yyyy-MM-dd HH:mm') + ")")
# 프로그램이 켜져 있으면 끄라고 안내
$running = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like ('*' + $prog + '.ps1*') })
if ($FromApp) { Start-Sleep -Seconds 2; $running = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like ('*' + $prog + '.ps1*') }) }
if ($running.Count) { Write-Host ''; Write-Host '프로그램이 켜져 있어요. 끈 뒤에 엔터를 눌러 주세요.'; Read-Host }
# 오래된 백업 폴더 정리: 기존 백업은 모두 지움 (이번 업데이트 백업 1개만 남음)
try { Get-ChildItem -Path $here -Directory -Filter '_backup_*' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | ForEach-Object { Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
$bk = Join-Path $here ('_backup_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
$z = [System.IO.Compression.ZipFile]::OpenRead($zip.FullName)
$n = 0; $skip = 0
try {
  foreach ($e in $z.Entries) {
    if (-not $e.Name) { continue }
    $nm = $e.FullName -replace '/', '\'
    $leaf = Split-Path $nm -Leaf
    $dst = Join-Path $here $nm
    if (($keep -contains $leaf -or $leaf -match $keepPat) -and (Test-Path $dst)) { $skip++; continue }
    if (Test-Path $dst) { New-Item -ItemType Directory -Path (Split-Path (Join-Path $bk $nm)) -Force | Out-Null; Copy-Item $dst (Join-Path $bk $nm) -Force }
    New-Item -ItemType Directory -Path (Split-Path $dst) -Force | Out-Null
    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dst, $true); $n++
  }
} finally { $z.Dispose() }
Write-Host ''
Write-Host ("완료: 파일 $n 개 바꿈, 내 설정 파일 $skip 개 그대로 둠.")
if (Test-Path $bk) { Write-Host ("이전 파일은 " + (Split-Path $bk -Leaf) + " 폴더에 보관했어요(문제 없으면 지워도 돼요).") }
if ($netZip) { Remove-Item $netZip -ErrorAction SilentlyContinue }
else { $del = Read-Host '받은 압축 파일을 지울까요? (y/n)'; if ($del -eq 'y') { Remove-Item $zip.FullName -Force; Write-Host '지웠어요.' } }
Finish-Update $n
