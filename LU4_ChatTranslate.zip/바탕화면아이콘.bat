@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0바탕화면아이콘.ps1"
